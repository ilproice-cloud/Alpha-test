# Build and test status

The source archive has been cleaned of the skill subsystem and its leftover assets/documentation. The retained RPG progression, stats, traits, perks, ranks, clan data, equipment bonuses, Sorcerer Killer armor, RPG book/HUD, and blocking system are intended to remain.

**This archive has not been compiled or launched in Minecraft in this environment.** Treat it as an edited source ZIP, not a tested JAR. Run the included GitHub Actions build and test the resulting JAR in Minecraft 1.21.1 with the matching NeoForge version.
