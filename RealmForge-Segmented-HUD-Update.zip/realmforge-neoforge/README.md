# RealmForge – NeoForge 1.21.1 source (skills removed)

This source archive contains the RealmForge RPG progression and equipment systems only. All skill-related gameplay, menus, keybinds, commands, animation hooks, combat skill assets, and unused skill dependencies have been removed.

## Retained systems
- RPG levels, experience, stats, energy, and progression
- Traits, perks, and ranks
- Clan data and clan progression bonuses
- Equipment bonuses and Sorcerer Killer armor
- RPG book and HUD
- Blocking system
- Existing RPG networking and save data

## Build
Use Java 21 and Gradle with the included `build.gradle` and `gradle.properties`:

```bash
gradle build --no-daemon
```

The resulting mod JAR is written to `build/libs/`.

## Important
This is an edited source archive, not a verified build. Compile it with GitHub Actions or a local Gradle environment and test it in Minecraft 1.21.1 with the matching NeoForge version before using it in a world.
