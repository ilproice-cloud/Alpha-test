No external rendering libraries are required.
