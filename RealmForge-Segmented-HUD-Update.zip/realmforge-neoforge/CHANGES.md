# RealmForge – skills subsystem removal

Removed all skill-related content from this source project:
- Skill implementations, registries, executors, schedulers, and skill context classes
- Skill book screen, skill HUD/keybinds, skill commands, and skill slot/save/sync handling
- Skill-specific network payloads, projectiles, entities, renderers, and animation hooks
- Uppercut and Electro skill icons and imported combat visuals
- Old combat-skill sounds, Photon effects, Prime Piece animation/effect assets, and related dependencies
- Unused skill-only damage bypass flag and skill-specific stat constant

Retained the RPG progression/stat systems, traits, perks, ranks, clans, equipment bonuses, Sorcerer Killer armor, RPG book/HUD, and blocking pose/system.


## Segmented HUD update (2026-11-09)
- Replaced the old solid HP, energy, and EXP bars with individually rendered image segments.
- Added the supplied 11-piece HP, 7-piece energy, 6-piece hunger, and 5-piece EXP textures.
- Each segment fills progressively from left to right; partial progress is clipped by darkening only the unfilled portion.
- Hunger reads Minecraft's player food level.
- The supplied full GUI and full-health-bar references are included under the GUI reference texture folder.
