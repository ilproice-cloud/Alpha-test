package com.realmforge.addon.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import com.realmforge.addon.data.Clan;
import com.realmforge.addon.logic.SetBonuses;
import com.realmforge.data.Passive;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import java.util.List;
import java.util.Locale;

public final class EffectsPage {
   private EffectsPage() {
   }

   private static MutableComponent t(String var0, Formatting... var1) {
      return Component.literal(var0).withStyle(var1);
   }

   private static String pct(double var0) {
      double var2 = var0 * 100.0;
      return (Math.abs(var2 - (double)Math.round(var2)) < 0.05 ? String.valueOf(Math.round(var2)) : String.format(Locale.ROOT, "%.1f", var2)) + "%";
   }

   private static String num(double var0) {
      return Math.abs(var0 - (double)Math.round(var0)) < 0.05 ? String.valueOf(Math.round(var0)) : String.format(Locale.ROOT, "%.1f", var0);
   }

   private static boolean tojiSet() {
      Minecraft var0 = Minecraft.getInstance();
      return var0 != null && var0.player != null && SetBonuses.hasTojiSet(var0.player);
   }

   public static Component build(RpgData var0) {
      boolean var1 = tojiSet();
      MutableComponent var2 = Component.empty();
      var2.append(t("STAT EFFECTS\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      var2.append(t("Per-point gains / current totals\n", ChatFormatting.GRAY));
      double var3 = (double)var0.stat(Stat.STR) * (var1 ? 1.75 : 1.0);
      var2.append(t("STR  +1 damage/pt" + (var1 ? " (x1.75 Killer set)" : "") + "; total +" + num(var3) + "\n", Stat.STR.bookColor));
      var2.append(t("AGI  +1% speed/pt; +0.5% dodge/pt\n", Stat.AGI.bookColor));
      var2.append(
         t(
            "     Current speed +" + pct(var0.speedBonus()) + ", dodge " + (var1 ? pct(Math.min(1.0, var0.dodge() + 0.2)) : pct(var0.dodge())) + "\n",
            Stat.AGI.bookColor
         )
      );
      var2.append(t("VIT  +2 max HP/pt; total +" + var0.maxHealthBonus() + " HP\n", Stat.VIT.bookColor));
      var2.append(t("INT  +3% magic damage/pt; total +" + pct(var0.intMagicMult() - 1.0) + "\n", Stat.INT.bookColor));
      var2.append(t("ENE  +2 max energy/pt; total " + (int)var0.maxEnergy() + "\n", Stat.ENE.bookColor));
      var2.append(t("     Energy regen: " + String.format(Locale.ROOT, "%.1f", var0.regenPerSecond()) + "/sec (+0.25/pt)\n\n", Stat.ENE.bookColor));
      var2.append(t("YOUR TRAITS + PERKS + CLANS\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      passive(var2, var0.trait());
      passive(var2, var0.perk());
      Clan var5 = var0 == null ? null : Clan.byId(var0.clan());
      if (var5 != null) {
         var2.append(t(var5.display + ": ", ChatFormatting.BOLD, var5.rarity.bookColor));
         var2.append(t("+ " + String.join(", ", var5.perks), ChatFormatting.DARK_GREEN));
         var2.append(Component.literal("\n"));
      }

      return var2;
   }

   private static void passive(MutableComponent var0, Passive var1) {
      if (var1 != null) {
         List var2 = var1.effects().buffs();
         List var3 = var1.effects().debuffs();
         var0.append(t(var1.displayName() + ": ", ChatFormatting.BOLD, var1.rarity().bookColor));
         var0.append(t(var2.isEmpty() ? "Buffs none" : "+ " + String.join(", ", var2), ChatFormatting.DARK_GREEN));
         if (!var3.isEmpty()) {
            var0.append(t(" / - " + String.join(", ", var3), ChatFormatting.DARK_RED));
         }

         var0.append(Component.literal("\n"));
      }
   }
}

