package com.realmforge.addon.mixin.client;

import com.realmforge.addon.client.BlockingClient;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies the raised-arms blocking pose. */
@Mixin(HumanoidModel.class)
public abstract class HumanoidModelMixin {
   @Shadow
   @Final
   public ModelPart rightArm;
   @Shadow
   @Final
   public ModelPart leftArm;

   @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
   private void realmforge$afterPose(LivingEntity entity, float f1, float f2, float f3, float f4, float f5, CallbackInfo ci) {
      // raised-arms blocking pose
      if (entity instanceof Player p && BlockingClient.isBlocking(p.getUUID())) {
         this.rightArm.xRot = -1.15F;
         this.rightArm.yRot = -0.85F;
         this.rightArm.zRot = 0.0F;
         this.leftArm.xRot = -1.15F;
         this.leftArm.yRot = 0.85F;
         this.leftArm.zRot = 0.0F;
      }
   }
}
