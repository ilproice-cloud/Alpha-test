package com.realmforge.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Effects {
   public final int[] stats = new int[Stat.values().length];
   public double dmgOut;
   public double dmgIn;
   public double exp;
   public double regen;
   public double energy;
   public double dodge;
   public double lifesteal;
   public int hp;

   public static Effects of() {
      return new Effects();
   }

   public Effects stat(Stat s, int v) {
      this.stats[s.ordinal()] += v;
      return this;
   }

   public Effects all(int v) {
      for (Stat s : Stat.values()) {
         this.stat(s, v);
      }

      return this;
   }

   public Effects dmgOut(double v) {
      this.dmgOut = v;
      return this;
   }

   public Effects dmgIn(double v) {
      this.dmgIn = v;
      return this;
   }

   public Effects exp(double v) {
      this.exp = v;
      return this;
   }

   public Effects regen(double v) {
      this.regen = v;
      return this;
   }

   public Effects energy(double v) {
      this.energy = v;
      return this;
   }

   public Effects dodge(double v) {
      this.dodge = v;
      return this;
   }

   public Effects lifesteal(double v) {
      this.lifesteal = v;
      return this;
   }



   public Effects hp(int v) {
      this.hp = v;
      return this;
   }

   public List<String> buffs() {
      return this.lines(true);
   }

   public List<String> debuffs() {
      return this.lines(false);
   }

   private List<String> lines(boolean good) {
      List<String> out = new ArrayList<>();

      for (Stat s : Stat.values()) {
         int v = this.stats[s.ordinal()];
         if (v != 0 && v > 0 == good) {
            out.add(String.format(Locale.ROOT, "%+d %s", v, s.abbr));
         }
      }

      if (this.hp != 0 && this.hp > 0 == good) {
         out.add(String.format(Locale.ROOT, "%+d max HP", this.hp));
      }

      pct(out, good, this.dmgOut, true, "dmg dealt");
      pct(out, good, this.dmgIn, false, "dmg taken");
      pct(out, good, this.exp, true, "EXP");
      pct(out, good, this.regen, true, "energy regen");
      pct(out, good, this.energy, true, "max energy");
      pct(out, good, this.dodge, true, "dodge");
      pct(out, good, this.lifesteal, true, "lifesteal");
      return out;
   }

   private static void pct(List<String> out, boolean good, double v, boolean higherIsBetter, String label) {
      if (v != 0.0) {
         if (v > 0.0 == higherIsBetter == good) {
            double p = v * 100.0;
            String num = Math.abs(p - (double)Math.round(p)) < 0.05 ? String.valueOf(Math.round(p)) : String.format(Locale.ROOT, "%.1f", p);
            out.add((p > 0.0 ? "+" : "") + num + "% " + label);
         }
      }
   }
}
