package com.realmforge.client;

import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.food.FoodData;

/**
 * Segmented RealmForge HUD.
 * Each bar is assembled from the supplied, individually numbered image pieces.
 */
public final class RpgHud {
   private static final int PIECE_W = 18;
   private static final int PIECE_H = 9;
   private static final int ROW_GAP = 14;

   private RpgHud() {
   }

   public static void render(GuiGraphics g, DeltaTracker tickCounter) {
      Minecraft mc = Minecraft.getInstance();
      RpgData d = ClientRpg.data;
      if (d == null || mc.player == null || mc.options.hideGui) {
         return;
      }

      int x = 8;
      int y = 8;
      int screenW = mc.getWindow().getGuiScaledWidth();
      int maxBarW = 11 * PIECE_W;
      int barX = x + 34;
      if (barX + maxBarW > screenW - 6) {
         barX = x;
      }

      Rank rank = d.rank();
      Component playerName = Component.literal("[" + rank.icon + "] " + mc.player.getName().getString())
            .withStyle(rank.color);
      g.drawString(mc.font, playerName, x, y, 0xFFFFFF);
      Component level = Component.literal("Lv." + d.level).withStyle(ChatFormatting.YELLOW);
      g.drawString(mc.font, level, x + maxBarW - mc.font.width(level), y, 0xFFFFFF);
      y += 13;

      float hpRatio = mc.player.getHealth() / Math.max(1.0F, mc.player.getMaxHealth());
      drawSegmentedBar(g, "hp", 11, barX, y, hpRatio);
      g.drawString(mc.font, "HP", x, y + 1, 0xFFFFFF);
      y += ROW_GAP;

      float energyRatio = (float)(d.energy / Math.max(1.0D, d.maxEnergy()));
      drawSegmentedBar(g, "ce", 7, barX, y, energyRatio);
      g.drawString(mc.font, "ENE", x, y + 1, 0x55CCFF);
      y += ROW_GAP;

      FoodData food = mc.player.getFoodData();
      float hungerRatio = food.getFoodLevel() / 20.0F;
      drawSegmentedBar(g, "hunger", 6, barX, y, hungerRatio);
      g.drawString(mc.font, "HUN", x, y + 1, 0xFFCC55);
      y += ROW_GAP;

      boolean atMaxLevel = d.level >= 100;
      float expRatio = atMaxLevel ? 1.0F : (float)d.exp / (float)Math.max(1L, d.expRequired());
      drawSegmentedBar(g, "exp", 5, barX, y, expRatio);
      g.drawString(mc.font, "EXP", x, y + 1, 0x55FF77);

      if (d.points > 0) {
         Component pts = Component.literal("+" + d.points + " pts [M]").withStyle(ChatFormatting.GOLD);
         g.drawString(mc.font, pts, x, y + ROW_GAP, 0xFFFFFF);
      }
   }

   private static void drawSegmentedBar(GuiGraphics g, String folder, int pieces,
                                        int x, int y, float ratio) {
      float clamped = Math.max(0.0F, Math.min(1.0F, ratio));
      float filled = clamped * pieces;
      for (int i = 0; i < pieces; i++) {
         String file = String.format("piece_%02d.png", i + 1);
         ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(
               "realmforge", "textures/gui/" + folder + "/" + file);
         int px = x + i * PIECE_W;
         g.blit(texture, px, y, PIECE_W, PIECE_H, 0.0F, 0.0F, 135, 65, 135, 65);

         float segmentFill = Math.max(0.0F, Math.min(1.0F, filled - i));
         if (segmentFill <= 0.0F) {
            g.fill(px, y, px + PIECE_W, y + PIECE_H, 0xB8000000);
         } else if (segmentFill < 1.0F) {
            int cut = px + Math.round(PIECE_W * segmentFill);
            g.fill(cut, y, px + PIECE_W, y + PIECE_H, 0xB8000000);
         }
      }
   }
}
