package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Registers every sound declared in sounds.json so skills can play them by name on the server. */
public final class ModSounds {
   public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, RealmForgeMod.MOD_ID);
   private static final Map<String, DeferredHolder<SoundEvent, SoundEvent>> BY_NAME = new HashMap<>();
   private static final String[] NAMES = new String[]{
      "bigslice2", "clothwhoosh", "el_thor", "floorskid", "gheavyslam", "groundslam", "knucklecrack", "lightpunch", "lightningboomy",
      "lightningboomy2", "longlightning", "omnikaboom", "raigoboom", "slishsloch", "smalllightningboomy", "swordslice2", "teleport",
      "countershock", "ursushockkaboooooommm"
   };

   static {
      for (String n : NAMES) {
         BY_NAME.put(n, SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(RealmForgeMod.id(n))));
      }
   }

   private ModSounds() {
   }

   public static SoundEvent get(String name) {
      DeferredHolder<SoundEvent, SoundEvent> h = BY_NAME.get(name);
      return h == null ? null : h.get();
   }
}
