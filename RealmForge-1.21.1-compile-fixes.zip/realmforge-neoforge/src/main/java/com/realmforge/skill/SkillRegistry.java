package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.Set;
import net.neoforged.neoforge.common.NeoForge;

/** Universal skill registry: skills register themselves via {@link SkillPack}s, never through a central switch. */
public final class SkillRegistry {
   private static final Map<String, SkillDefinition> SKILLS = new LinkedHashMap<>();
   private static final Set<String> PACKS = new HashSet<>();
   private static boolean booted;

   private SkillRegistry() {
   }

   /** Idempotent; called from the mod constructor on both sides. */
   public static synchronized void bootstrap() {
      if (booted) {
         return;
      }

      booted = true;
      try {
         for (SkillPack pack : ServiceLoader.load(SkillPack.class, SkillRegistry.class.getClassLoader())) {
            registerPack(pack);
         }
      } catch (Throwable t) {
         RealmForgeMod.LOGGER.warn("SkillPack service discovery failed ({}); falling back to built-in packs", t.toString());
      }

      // built-in pack, guaranteed even if ServiceLoader is unavailable in this environment
      registerPack(new com.realmforge.skill.skills.ElectroSkillPack());
      NeoForge.EVENT_BUS.post(new RegisterSkillsEvent(SkillRegistry::register));
      RealmForgeMod.LOGGER.info("RealmForge skills registered: {}", SKILLS.keySet());
   }

   private static void registerPack(SkillPack pack) {
      if (PACKS.add(pack.getClass().getName())) {
         pack.register(SkillRegistry::register);
      }
   }

   public static synchronized void register(SkillDefinition def) {
      String id = def.id().toLowerCase(Locale.ROOT);
      if (SKILLS.putIfAbsent(id, def) != null) {
         throw new IllegalStateException("Duplicate skill id: " + id);
      }
   }

   public static synchronized SkillDefinition get(String id) {
      return id == null ? null : SKILLS.get(id.toLowerCase(Locale.ROOT));
   }

   public static synchronized Collection<SkillDefinition> all() {
      return Collections.unmodifiableCollection(new ArrayList<>(SKILLS.values()));
   }

   public static synchronized List<String> ids() {
      return new ArrayList<>(SKILLS.keySet());
   }

   /** Maps the ids used by the old three-skill enum onto the Electro skills; other ids pass through. */
   public static String migrateLegacyId(String id) {
      if (id == null) {
         return "";
      }

      return switch (id) {
         case "strong_punch", "power_strike" -> "electro_barrage";
         case "uppercut", "dash" -> "electro_dropkick";
         case "barrage", "arcane_bolt", "mend" -> "electro_double_scratch";
         default -> id;
      };
   }
}
