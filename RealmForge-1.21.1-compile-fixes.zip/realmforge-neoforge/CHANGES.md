# RealmForge – Electro skill integration: change list

## Root causes found
1. **FX never played from a trustworthy path.** The earlier build (in your 1.12.5 JAR) ran `/photon fx ...` commands *on the server* – that needs Photon on the server and op permission, and silently does nothing otherwise. The ZIP source had no skill/FX code at all.
2. **FX textures were missing.** Every imported `.fx` references `trueprimepiecetwo:textures/particle/*.png`; that namespace did not exist in the source, so particles had no texture.
3. **Animations were limited.** Only 3 hard-coded clips (int ids), the `torso` bone used by 7 clips was ignored, clips were read from the classpath and any parse failure was swallowed (looks like "nothing loaded"). `countershock*.json` were not shipped.
4. **Skills were a no-op**: `SkillExecutor` delegated to an empty Ice Spikes stub.
5. The log line "0 entity animations loaded" is **not produced by RealmForge, Photon or LDLib2** (searched all supplied jars) – it comes from another mod in your pack and is unrelated to player animations.

## Architecture (no per-skill code in shared systems)
- `skill/SkillDefinition` – interface for one skill (id, name, description, cost, cooldown, `execute(ctx)`, optional `fxNames()`, `canUse`).
- `skill/SkillRegistry` – universal registry; discovers `SkillPack`s through `ServiceLoader` (`META-INF/services/com.realmforge.skill.SkillPack`), always registers the built-in pack as a fallback, and posts `RegisterSkillsEvent` so other mods can add skills.
- `skill/SkillContext` – shared helpers: timing, cone/area hit detection, damage (goes through `DamagePipeline`), knockback, dash/hold/no-fall, sounds, animation, Photon FX, claws, screen flash, model props.
- `logic/SkillExecutor` – universal: slot -> definition, unlocked check, busy, cooldown, energy, delegate. Knows no skill by name.
- `skill/SkillTasks` – server tick scheduler (cancelled when the caster dies/leaves).
- Networking: `SkillFxPayload` (S2C), `AnimPayload` (now clip name + speed), `EquipSkillPayload` (C2S, validated server-side).
- **Adding a skill later:** write one class implementing `SkillDefinition`, add it to a `SkillPack` (or a new pack listed in META-INF/services). Nothing else changes; the menu, `/realmforge skill ...`, HUD, save data and sync pick it up automatically.

## Skills (`skill/skills/`)
Electro Barrage, Electro Dropkick, Electro Double Scratch, Electric Field, Electro Fist – each ~100 lines of timeline using the shared context. Each plays its original player animation, original Photon FX, original sounds, hits with a real hitbox on the server, and syncs to all tracking players.

## Visuals
- `PhotonBridge` (only class touching Photon; compiled and signature-checked against photon-neoforge-1.21.1-2.2.10) plays FX client-side with `EntityEffectExecutor`, preloads FX at login, and logs once per missing FX file.
- `GeoModel` loads the original Bedrock `.geo.json` into vanilla `ModelPart`s; `SkillPropEntity` + `SkillPropRenderer` render the original **Gorobolt** bolt (5 textures) and the original **Ursus shock paw** with its original `idle` animation (position + scale keyframes).
- `ClawLayer` renders the original **Electro claw model** (cubes extracted cube-for-cube from `Modelelecclaw`, `elecclaw.png`) on both hands during Double Scratch and Electro Fist.
- `AnimClient` rewritten: any clip by name, resource-manager loading, `torso`/`body` alias, no accumulating body offsets, real error logging. `/rfanim <clip>` (client command) previews a clip on yourself.
- Electric Field plays the original `countershock*.png` screen flashes.

## Menu / unlock
- `SkillBookScreen` (key N): left page = **unlocked skills only**, right page = name, icon, description, cost, cooldown, **[ EQUIP ]** then **[ Z ] [ X ] [ C ]**; slots shown at the bottom and in the HUD; updates immediately and saves (server validates).
- `/realmforge skill unlock all` (also `unlock <id>`, `lock <id|all>`, `list`, `bind`). Permission: level 2 (same as `/realmforge admin`) **or** the owner of a single-player world. Data saved in `RpgState` with legacy-slot migration.

## Assets added
68 Photon FX (`assets/photon/fx`), 5 geo/anim files, 18 player animations, 5 skill icons, claw + gorobolt + ursus textures, 7 countershock overlays, sounds `countershock` and `ursushockkaboooooommm`, `assets/trueprimepiecetwo/` particle textures (see below).

## Build
`build.gradle` takes Photon + LDLib2 from `./libs`; `.github/workflows/build.yml` builds with Gradle 8.14.3 / Java 21 and uploads the JAR.

## Removed
The empty `IceSpikesSkill` placeholder and the 3-entry `Skill` enum (replaced by the registry). Its old GUI art is still in the resources.
