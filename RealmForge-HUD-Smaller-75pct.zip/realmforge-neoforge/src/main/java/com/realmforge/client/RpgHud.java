package com.realmforge.client;

import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.food.FoodData;

/**
 * RealmForge parchment HUD: the supplied panel is the main GUI background,
 * with live segmented bars and the player's skin portrait drawn over it.
 */
public final class RpgHud {
   private static final float GUI_SCALE = 0.75F;
   private static final int GUI_W = Math.round(384 * GUI_SCALE);
   private static final int GUI_H = Math.round(154 * GUI_SCALE);
   private static final ResourceLocation BACKGROUND =
         ResourceLocation.fromNamespaceAndPath("realmforge", "textures/gui/main_hud_background.png");

   private RpgHud() {
   }

   public static void render(GuiGraphics g, DeltaTracker tickCounter) {
      Minecraft mc = Minecraft.getInstance();
      RpgData d = ClientRpg.data;
      if (d == null || mc.player == null || mc.options.hideGui) {
         return;
      }

      // Anchor the complete panel at the top-left, as requested.
      int x = 8;
      int y = 8;
      // Keep it on-screen on narrow GUI sizes without moving it to the bottom.

      // Main panel artwork supplied by the user.
      g.blit(BACKGROUND, x, y, GUI_W, GUI_H, 0.0F, 0.0F, 1536, 614, 1536, 614);

      // All panel contents use the same 75% scale as the background.
      // Player portrait inside the framed square (skin face + hat layer).
      int faceX = x + Math.round(41 * GUI_SCALE);
      int faceY = y + Math.round(39 * GUI_SCALE);
      int faceSize = Math.round(42 * GUI_SCALE);
      ResourceLocation skin = mc.player.getSkin().texture();
      g.blit(skin, faceX, faceY, faceSize, faceSize, 8, 8, 8, 8, 64, 64);
      g.blit(skin, faceX, faceY, faceSize, faceSize, 40, 8, 8, 8, 64, 64);

      Rank rank = d.rank();
      Component name = Component.literal(mc.player.getName().getString())
            .withStyle(rank.color);
      g.drawString(mc.font, name, x + Math.round(116 * GUI_SCALE),
            y + Math.round(12 * GUI_SCALE), 0xFFFFFF, false);
      Component level = Component.literal("Lv. " + d.level + "  " + rank.icon)
            .withStyle(ChatFormatting.DARK_GRAY);
      g.drawString(mc.font, level, x + Math.round(184 * GUI_SCALE),
            y + Math.round(12 * GUI_SCALE), 0xFFFFFF, false);

      float hp = mc.player.getHealth() / Math.max(1.0F, mc.player.getMaxHealth());
      float energy = (float)(d.energy / Math.max(1.0D, d.maxEnergy()));
      FoodData food = mc.player.getFoodData();
      float hunger = food.getFoodLevel() / 20.0F;
      float exp = d.level >= 100 ? 1.0F :
            (float)d.exp / (float)Math.max(1L, d.expRequired());

      // Coordinates are scaled from the four empty tracks in the supplied 1536x614 panel.
      int hpX = x + Math.round(111 * GUI_SCALE);
      int hpY = y + Math.round(32 * GUI_SCALE);
      int energyX = x + Math.round(111 * GUI_SCALE);
      int energyY = y + Math.round(66 * GUI_SCALE);
      int expX = x + Math.round(111 * GUI_SCALE);
      int expY = y + Math.round(98 * GUI_SCALE);
      int hungerX = x + Math.round(231 * GUI_SCALE);
      int hungerY = y + Math.round(98 * GUI_SCALE);

      float hpPieceW = 22.2F * GUI_SCALE;
      float hpPieceH = 10.5F * GUI_SCALE;
      float energyPieceW = 22.35F * GUI_SCALE;
      float energyPieceH = 7.8F * GUI_SCALE;
      float expPieceW = 21.75F * GUI_SCALE;
      float expPieceH = 10.0F * GUI_SCALE;
      float hungerPieceW = 20.9F * GUI_SCALE;
      float hungerPieceH = 10.0F * GUI_SCALE;

      drawBar(g, "hp", 11, hpX, hpY, hpPieceW, hpPieceH, hp);
      drawBar(g, "ce", 7, energyX, energyY, energyPieceW, energyPieceH, energy);
      drawBar(g, "exp", 5, expX, expY, expPieceW, expPieceH, exp);
      drawBar(g, "hunger", 6, hungerX, hungerY, hungerPieceW, hungerPieceH, hunger);

      // Current / maximum indicators are centered over their respective bars.
      drawCenteredValue(g, mc, formatValue(mc.player.getHealth()) + " / " +
            formatValue(mc.player.getMaxHealth()), hpX, hpY, 11 * hpPieceW, hpPieceH);
      drawCenteredValue(g, mc, formatValue(d.energy) + " / " +
            formatValue(d.maxEnergy()), energyX, energyY, 7 * energyPieceW, energyPieceH);
      drawCenteredValue(g, mc, d.exp + " / " + d.expRequired(),
            expX, expY, 5 * expPieceW, expPieceH);
      drawCenteredValue(g, mc, food.getFoodLevel() + " / 20",
            hungerX, hungerY, 6 * hungerPieceW, hungerPieceH);

      if (d.points > 0) {
         Component points = Component.literal("+" + d.points + " STAT POINTS")
               .withStyle(ChatFormatting.GOLD);
         g.drawString(mc.font, points, x + Math.round(110 * GUI_SCALE),
               y + Math.round(121 * GUI_SCALE), 0xFFFFFF, false);
      }
   }

   private static String formatValue(double value) {
      if (Math.abs(value - Math.round(value)) < 0.01D) {
         return Long.toString(Math.round(value));
      }
      return String.format(java.util.Locale.ROOT, "%.1f", value);
   }

   private static void drawCenteredValue(GuiGraphics g, Minecraft mc, String value,
                                         int x, int y, float width, float height) {
      int textWidth = mc.font.width(value);
      int textX = x + Math.round((width - textWidth) / 2.0F);
      int textY = y + Math.max(0, Math.round((height - mc.font.lineHeight) / 2.0F));
      // A dark shadow keeps the indicator readable over both filled and empty segments.
      g.drawString(mc.font, value, textX, textY, 0xFFFFFF, true);
   }

   private static void drawBar(GuiGraphics g, String folder, int count,
                               int x, int y, float pieceW, float pieceH, float ratio) {
      float filled = Math.max(0.0F, Math.min(1.0F, ratio)) * count;
      for (int i = 0; i < count; i++) {
         ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(
               "realmforge", "textures/gui/" + folder + "/piece_" +
               String.format("%02d", i + 1) + ".png");
         int px = x + Math.round(i * pieceW);
         int right = x + Math.round((i + 1) * pieceW);
         int w = Math.max(1, right - px);
         int h = Math.max(1, Math.round(pieceH));
         g.blit(texture, px, y, w, h, 0.0F, 0.0F, 135, 65, 135, 65);

         float segment = Math.max(0.0F, Math.min(1.0F, filled - i));
         if (segment <= 0.0F) {
            g.fill(px, y, px + w, y + h, 0xB8000000);
         } else if (segment < 1.0F) {
            int cut = px + Math.round(w * segment);
            g.fill(cut, y, px + w, y + h, 0xB8000000);
         }
      }
   }
}
