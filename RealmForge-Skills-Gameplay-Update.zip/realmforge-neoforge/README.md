# RealmForge – NeoForge 1.21.1 source (skills removed)

This source archive contains the RealmForge RPG progression and equipment systems only. All skill-related gameplay, menus, keybinds, commands, animation hooks, combat skill assets, and unused skill dependencies have been removed.

## Retained systems
- RPG levels, experience, stats, energy, and progression
- Traits, perks, and ranks
- Clan data and clan progression bonuses
- Equipment bonuses and Sorcerer Killer armor
- RPG book and HUD
- Blocking system
- Existing RPG networking and save data

## Build
Use Java 21 and Gradle with the included `build.gradle` and `gradle.properties`:

```bash
gradle build --no-daemon
```

The resulting mod JAR is written to `build/libs/`.

## Important
This is an edited source archive, not a verified build. Compile it with GitHub Actions or a local Gradle environment and test it in Minecraft 1.21.1 with the matching NeoForge version before using it in a world.

## Skills (current gameplay-only pass)
- Open the skills menu with **N** or `/realmforge skills`.
- Unlock skills for testing with `/realmforge skills unlock barrage`, `/realmforge skills unlock heavy_punch`, or `/realmforge skills unlock uppercut`.
- Select an unlocked skill, press **Quit / Assign**, then choose **Z**, **X**, or **C**.
- Use the assigned key in-game. Unlocks and slot assignments are saved with the player's RealmForge data.
- Barrage: repeated close-range punches. Heavy Punch: a high-damage close-range hit. Uppercut: a hit that launches the target upward.
- This pass intentionally does not import or play any Prime Punch animations. Cooldowns, energy costs, range checks, and damage are handled server-side.
