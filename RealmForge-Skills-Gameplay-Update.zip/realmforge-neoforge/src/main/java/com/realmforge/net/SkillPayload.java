package com.realmforge.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record SkillPayload(String action, String value) implements CustomPacketPayload {
   public static final Type<SkillPayload> TYPE = new Type<>(RealmForgeMod.id("skill_action"));
   public static final StreamCodec<ByteBuf, SkillPayload> CODEC = StreamCodec.composite(ByteBufCodecs.STRING_UTF8, SkillPayload::action, ByteBufCodecs.STRING_UTF8, SkillPayload::value, SkillPayload::new);
   @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
