package com.realmforge.client;

import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Book pages that explain the rank system: how ranks are earned, what every rank-up
 * gives (buffs) and costs (debuff), per-rank totals and extra notes.
 * Page numbers must be opened through a catalogue-style {@link RpgBookScreen}
 * so the "[ BACK TO INFORMATION ]" line works.
 */
public final class RankPage {
   private RankPage() {
   }

   private static MutableComponent t(String text, ChatFormatting... formats) {
      return Component.literal(text).withStyle(formats);
   }

   private static MutableComponent head(String title) {
      return t(title + "\n", ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD)
         .append(t("[ BACK TO INFORMATION ]", ChatFormatting.DARK_GRAY, ChatFormatting.BOLD))
         .append(Component.literal("\n\n"));
   }

   /** Formats a percentage with at most one decimal (10 -> "10%", 7.5 -> "7.5%"). */
   private static String pct(double percent) {
      return (Math.abs(percent - Math.round(percent)) < 0.05
         ? String.valueOf(Math.round(percent))
         : String.format(Locale.ROOT, "%.1f", percent)) + "%";
   }

   public static List<Component> pages(RpgData d) {
      Rank current = d == null ? Rank.NOVICE : d.rank();
      int level = d == null ? 1 : d.level;
      int kills = d == null ? 0 : d.kills;
      List<Component> pages = new ArrayList<>();

      // 1) Overview + progress
      MutableComponent p1 = head("RANK UP");
      p1.append(t("Rank up as you grow stronger. Reach the level AND the kill count of the next rank and you rank up automatically.\n\n", ChatFormatting.DARK_GRAY));
      p1.append(t("Current rank\n", ChatFormatting.DARK_GRAY));
      p1.append(t("[" + current.icon + "] " + current.label + "\n\n", current.bookColor, ChatFormatting.BOLD));
      Rank next = current.next();
      if (next != null) {
         p1.append(t("Next rank\n", ChatFormatting.DARK_GRAY));
         p1.append(t("[" + next.icon + "] " + next.label + "\n", next.bookColor, ChatFormatting.BOLD));
         p1.append(t("Level " + level + " / " + next.minLevel + "\n", level >= next.minLevel ? ChatFormatting.DARK_GREEN : ChatFormatting.DARK_RED));
         p1.append(t("Kills " + kills + " / " + next.minKills, kills >= next.minKills ? ChatFormatting.DARK_GREEN : ChatFormatting.DARK_RED));
      } else {
         p1.append(t("MAX RANK reached.", ChatFormatting.GOLD, ChatFormatting.BOLD));
      }
      pages.add(p1);

      // 2) What every rank-up does + totals
      MutableComponent p2 = head("RANK BONUSES");
      p2.append(t("Every rank-up grants:\n", ChatFormatting.DARK_GRAY));
      p2.append(t("+ " + pct(Rank.EXP_BONUS_PER_RANK * 100.0) + " EXP gained\n", ChatFormatting.DARK_GREEN));
      p2.append(t("+ " + pct(Rank.STAT_BONUS_PER_RANK * 100.0) + " to ALL stats\n", ChatFormatting.DARK_GREEN));
      p2.append(t("- " + pct(Rank.DODGE_PENALTY_PER_RANK * 100.0) + " dodge chance\n\n", ChatFormatting.DARK_RED));
      p2.append(t("Total: EXP / Stats / Dodge\n", ChatFormatting.DARK_GRAY));
      for (Rank r : Rank.values()) {
         if (r.steps() == 0) {
            continue;
         }

         boolean mine = r == current;
         p2.append(t((mine ? ">" : "") + r.label + " ", r.bookColor, ChatFormatting.BOLD));
         p2.append(t("+" + pct(r.expBonus() * 100.0) + "/+" + pct(r.statBonus() * 100.0) + "/-" + pct(r.dodgePenalty() * 100.0) + "\n",
            mine ? ChatFormatting.BLACK : ChatFormatting.DARK_GRAY));
      }
      pages.add(p2);

      // 3) Buffs
      MutableComponent p3 = head("BUFFS");
      p3.append(t("EXP BOOST\n", ChatFormatting.DARK_GREEN, ChatFormatting.BOLD));
      p3.append(t("+" + pct(Rank.EXP_BONUS_PER_RANK * 100.0) + " EXP per rank. It adds to your trait and perk EXP bonuses; your clan multiplier is applied on top.\n\n", ChatFormatting.DARK_GRAY));
      p3.append(t("ALL STATS\n", ChatFormatting.DARK_GREEN, ChatFormatting.BOLD));
      p3.append(t("+" + pct(Rank.STAT_BONUS_PER_RANK * 100.0) + " per rank on the final total of every stat (points, gear, trait, perk), rounded to a whole number. This raises max HP, speed, damage, energy and AGI.", ChatFormatting.DARK_GRAY));
      pages.add(p3);

      // 4) Debuffs
      MutableComponent p4 = head("DEBUFFS");
      p4.append(t("DODGE CHANCE\n", ChatFormatting.DARK_RED, ChatFormatting.BOLD));
      p4.append(t("-" + pct(Rank.DODGE_PENALTY_PER_RANK * 100.0) + " per rank. Your final dodge chance is multiplied by (1 - " + pct(Rank.DODGE_PENALTY_PER_RANK * 100.0) + " x ranks).\n\n", ChatFormatting.DARK_GRAY));
      p4.append(t("Example: 20% dodge at Elite (4 ranks) becomes 14%.\n\n", ChatFormatting.DARK_GRAY));
      p4.append(t("Higher ranks are stronger and level faster, but get hit more often. Dodge never drops below 0%.", ChatFormatting.DARK_GRAY));
      pages.add(p4);

      // 5) Rank requirements
      MutableComponent p5 = head("RANKS");
      p5.append(t("Level and kills needed:\n", ChatFormatting.DARK_GRAY));
      for (Rank r : Rank.values()) {
         boolean mine = r == current;
         p5.append(t((mine ? ">" : "") + r.label + " ", r.bookColor, ChatFormatting.BOLD));
         p5.append(t("Lv" + r.minLevel + ", " + r.minKills + " kills\n", mine ? ChatFormatting.BLACK : ChatFormatting.DARK_GRAY));
      }
      pages.add(p5);

      // 6) More info
      Rank top = Rank.values()[Rank.values().length - 1];
      MutableComponent p6 = head("MORE INFO");
      p6.append(t("- Ranks are permanent; you never lose one.\n", ChatFormatting.DARK_GRAY));
      p6.append(t("- You need the level AND the kills.\n", ChatFormatting.DARK_GRAY));
      p6.append(t("- Rank-ups apply instantly, including max HP and speed.\n", ChatFormatting.DARK_GRAY));
      p6.append(t("- Bonuses stack for every rank you hold.\n\n", ChatFormatting.DARK_GRAY));
      p6.append(t(top.label + " (max): ", ChatFormatting.BOLD, top.bookColor));
      p6.append(t("+" + pct(top.expBonus() * 100.0) + " EXP, +" + pct(top.statBonus() * 100.0) + " stats, -" + pct(top.dodgePenalty() * 100.0) + " dodge.", ChatFormatting.DARK_GRAY));
      pages.add(p6);

      return pages;
   }
}
