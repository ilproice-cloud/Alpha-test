package com.realmforge.client;
import com.realmforge.net.SkillPayload;
import com.realmforge.skill.SkillId;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
public class SkillsScreen extends Screen {
 protected String selected=""; protected boolean assigning=false;
 public SkillsScreen(){this("",false);}
 private SkillsScreen(String selected,boolean assigning){super(Component.literal("RealmForge Skills"));this.selected=selected;this.assigning=assigning;}
 @Override protected void init(){ clearWidgets(); int cx=width/2; int y=38;
  if(ClientRpg.data!=null){ for(String id:ClientRpg.data.unlockedSkills){ final String skill=id; addRenderableWidget(Button.builder(Component.literal((selected.equals(skill)?"> ":"")+SkillId.display(skill)),b->{selected=skill;assigning=false;rebuild();}).bounds(cx-100,y,200,20).build()); y+=25; } }
  if(!selected.isEmpty()){ addRenderableWidget(Button.builder(Component.literal(assigning?"Choose a key below":"Quit / Assign"),b->{assigning=true;rebuild();}).bounds(cx-100,Math.min(height-85,y+4),200,20).build()); }
  if(assigning){ int by=Math.min(height-55,y+30); addRenderableWidget(Button.builder(Component.literal("Z"),b->assign("z")).bounds(cx-100,by,62,20).build()); addRenderableWidget(Button.builder(Component.literal("X"),b->assign("x")).bounds(cx-31,by,62,20).build()); addRenderableWidget(Button.builder(Component.literal("C"),b->assign("c")).bounds(cx+38,by,62,20).build()); }
  addRenderableWidget(Button.builder(Component.literal("Close"),b->onClose()).bounds(cx-40,height-28,80,20).build());
 }
 private void rebuild(){ Minecraft.getInstance().setScreen(new SkillsScreen(selected,assigning)); }
 private void assign(String key){ PacketDistributor.sendToServer(new SkillPayload("assign",key+":"+selected)); onClose(); }
 @Override public void render(GuiGraphics g,int mx,int my,float delta){ renderBackground(g,mx,my,delta); g.drawCenteredString(font,"REALM FORGE - SKILLS",width/2,18,0xFFFFFF); if(ClientRpg.data==null||ClientRpg.data.unlockedSkills.isEmpty()) g.drawCenteredString(font,"No skills unlocked yet",width/2,height/2-8,0xAAAAAA); else { int y=height-48; String z=ClientRpg.data.skillZ.isEmpty()?"Empty":SkillId.display(ClientRpg.data.skillZ); String x=ClientRpg.data.skillX.isEmpty()?"Empty":SkillId.display(ClientRpg.data.skillX); String c=ClientRpg.data.skillC.isEmpty()?"Empty":SkillId.display(ClientRpg.data.skillC); g.drawCenteredString(font,"Z: "+z+"   X: "+x+"   C: "+c,width/2,y,0xA0E8FF); } super.render(g,mx,my,delta); }
 @Override public boolean isPauseScreen(){return false;}

}
