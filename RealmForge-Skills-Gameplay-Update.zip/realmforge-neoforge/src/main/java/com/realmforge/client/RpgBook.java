package com.realmforge.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.client.gui.screens.Screen;

import com.realmforge.addon.client.BookPages;
import com.realmforge.addon.client.EffectsPage;
import com.realmforge.data.Passive;
import com.realmforge.data.Perk;
import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.data.Trait;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class RpgBook {
   private static final int PER_PAGE = 1;
   private static final int BAR_LEN = 22;

   private RpgBook() {
   }

   public static Screen screen(int startPage) {
      if (startPage == -2) {
         return catalogue(true);
      } else {
         return startPage == -3 ? catalogue(false) : main(startPage);
      }
   }

   public static Screen main(int startPage) {
      RpgData d = ClientRpg.data;
      List<Component> pages = new ArrayList<>();
      pages.add(BookPages.player(d, playerName()));
      pages.add(attributesPage(d));
      pages.add(EffectsPage.build(d));
      pages.add(BookPages.references(d));
      pages.add(statsBarsPage(d));
      pages.add(informationPage(d));
      return new RpgBookScreen(pages, startPage, false);
   }

   private static Screen catalogue(boolean traits) {
      RpgData d = ClientRpg.data;
      List<Component> pages = new ArrayList<>();
      passivePages(pages, traits ? "TRAITS" : "PERKS", (Passive[])(traits ? Trait.values() : Perk.values()), traits ? d.traitId : d.perkId);
      return new RpgBookScreen(pages, 0, true);
   }

   private static Component informationPage(RpgData d) {
      MutableComponent m = Component.empty();
      m.append(t("INFORMATION\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      m.append(t("View every trait and its effects.\n", ChatFormatting.GRAY));
      m.append(t("[ TRAITS ]", ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
      m.append(t("\n\n", ChatFormatting.WHITE));
      m.append(t("View every perk and its effects.\n", ChatFormatting.GRAY));
      m.append(t("[ PERKS ]", ChatFormatting.DARK_AQUA, ChatFormatting.BOLD));
      m.append(t("\n\nView your clan and its perks.\n", ChatFormatting.DARK_GRAY));
      m.append(Component.literal("[ CLAN ]").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
      m.append(t("\n\nHow ranks work, buffs and debuffs.\n", ChatFormatting.DARK_GRAY));
      m.append(t("[ RANK UP ]", ChatFormatting.DARK_RED, ChatFormatting.BOLD));
      m.append(Component.literal("\n\nYour assigned trait, perk and clan are permanent.").withStyle(ChatFormatting.DARK_GRAY));
      return m;
   }

   private static String playerName() {
      Minecraft mc = Minecraft.getInstance();
      return mc.player != null ? mc.player.getName().getString() : "Player";
   }

   private static Component playerPage(RpgData d, String name) {
      Rank r = d.rank();
      Trait tr = d.trait();
      Perk pk = d.perk();
      MutableComponent m = Component.empty();
      m.append(t("PLAYER\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      m.append(t("[" + r.icon + "] " + name + "\n", ChatFormatting.BOLD, ChatFormatting.WHITE));
      m.append(t("Rank: ", ChatFormatting.DARK_GRAY)).append(t(r.label + "\n", ChatFormatting.BOLD, r.bookColor));
      m.append(t("Level: ", ChatFormatting.DARK_GRAY)).append(t(d.level + "\n", ChatFormatting.WHITE));
      m.append(t("EXP: ", ChatFormatting.DARK_GRAY)).append(t(d.level >= 100 ? "MAX\n" : d.exp + " / " + d.expRequired() + "\n", ChatFormatting.WHITE));
      Rank nx = r.next();
      if (nx != null) {
         m.append(t("Next: " + nx.label + " (Lv" + nx.minLevel + ", " + nx.minKills + " kills; you: " + d.kills + ")\n", ChatFormatting.GRAY));
      }

      m.append(t("\nTrait: ", ChatFormatting.DARK_GRAY));
      if (tr != null) {
         m.append(t(tr.displayName(), tr.rarity().bookColor, ChatFormatting.BOLD))
            .append(t(" (" + tr.rarity().label + ")\n", tr.rarity().bookColor));
      }

      m.append(t("Perk: ", ChatFormatting.DARK_GRAY));
      if (pk != null) {
         m.append(t(pk.displayName(), pk.rarity().bookColor, ChatFormatting.BOLD))
            .append(t(" (" + pk.rarity().label + ")\n", pk.rarity().bookColor));
      }

      m.append(t("\nStat points: ", ChatFormatting.DARK_GRAY))
         .append(t(String.valueOf(d.points), d.points > 0 ? ChatFormatting.DARK_GREEN : ChatFormatting.WHITE, ChatFormatting.BOLD));
      return m;
   }

   private static Component attributesPage(RpgData d) {
      int cap = Math.max(10, 5 + 3 * (d.level - 1));
      MutableComponent m = Component.empty();
      m.append(t("ATTRIBUTES\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));

      for (Stat s : Stat.values()) {
         int v = d.stat(s);
         int bonus = d.bonusOf(s);
         m.append(t(s.abbr + " " + v + " ", ChatFormatting.BOLD, s.bookColor));
         m.append(t("[+1] [+5]", d.points > 0 ? s.bookColor : ChatFormatting.GRAY));
         m.append(Component.literal("\n"));
         int filled = Math.round(Math.min(1.0F, (float)v / (float)cap) * 22.0F);
         m.append(t("|".repeat(filled), s.bookColor));
         m.append(t("|".repeat(22 - filled), ChatFormatting.GRAY));
         if (bonus != 0) {
            m.append(t(" " + (bonus > 0 ? "+" : "") + bonus, bonus > 0 ? ChatFormatting.DARK_GREEN : ChatFormatting.DARK_RED));
         }

         m.append(Component.literal("\n"));
      }

      m.append(t("Points left: ", ChatFormatting.DARK_GRAY))
         .append(t(String.valueOf(d.points), d.points > 0 ? ChatFormatting.DARK_GREEN : ChatFormatting.WHITE, ChatFormatting.BOLD));
      return m;
   }

   private static Component effectsPage(RpgData d) {
      MutableComponent m = Component.empty();
      m.append(t("STAT EFFECTS\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      m.append(t("Per-point gains / current totals\n", ChatFormatting.GRAY));
      m.append(t("STR  +2% physical damage/pt / current +" + pct(d.physMult() - 1.0) + "\n", Stat.STR.bookColor));
      m.append(t("AGI  +1% speed/pt; +0.5% dodge/pt\n", Stat.AGI.bookColor));
      m.append(t("     Current speed +" + pct(d.speedBonus()) + ", dodge " + pct(d.dodge()) + "\n", Stat.AGI.bookColor));
      m.append(t("VIT  +4 max HP/pt; total +" + d.maxHealthBonus() + " HP\n", Stat.VIT.bookColor));
      m.append(t("INT  +3% magic damage/pt; total +" + pct(d.intMagicMult() - 1.0) + "\n", Stat.INT.bookColor));
      m.append(t("ENE  +10 max energy/pt; total " + (int)d.maxEnergy() + "\n", Stat.ENE.bookColor));
      m.append(t("     Energy regen: " + String.format(Locale.ROOT, "%.1f", d.regenPerSecond()) + "/sec\n\n", Stat.ENE.bookColor));
      m.append(t("YOUR TRAIT + PERK\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      appendPassiveEffects(m, d.trait());
      appendPassiveEffects(m, d.perk());
      return m;
   }

   private static void appendPassiveEffects(MutableComponent m, Passive passive) {
      if (passive != null) {
         List<String> buffs = passive.effects().buffs();
         List<String> debuffs = passive.effects().debuffs();
         m.append(t(passive.displayName() + ": ", ChatFormatting.BOLD, passive.rarity().bookColor));
         m.append(t(buffs.isEmpty() ? "Buffs none" : "+ " + String.join(", ", buffs), ChatFormatting.DARK_GREEN));
         if (!debuffs.isEmpty()) {
            m.append(t(" / - " + String.join(", ", debuffs), ChatFormatting.DARK_RED));
         }

         m.append(Component.literal("\n"));
      }
   }

   private static void head(MutableComponent m, Stat s, RpgData d) {
      m.append(t(s.abbr + " " + d.stat(s) + "\n", ChatFormatting.BOLD, s.bookColor));
   }

   private static void body(MutableComponent m, Stat s, String text) {
      m.append(t(text + "\n", s.bookColor));
   }

   private static Component referencesPage(RpgData d) {
      Trait tr = d.trait();
      Perk pk = d.perk();
      MutableComponent m = Component.empty();
      m.append(t("REFERENCES\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      m.append(t("Use the Information page to browse all traits and perks.\n\n", ChatFormatting.DARK_AQUA));
      m.append(t("Your trait:\n", ChatFormatting.DARK_GRAY));
      if (tr != null) {
         m.append(t(tr.displayName() + " (" + tr.rarity().label + ")\n\n", tr.rarity().bookColor, ChatFormatting.BOLD));
      }

      m.append(t("Your perk:\n", ChatFormatting.DARK_GRAY));
      if (pk != null) {
         m.append(t(pk.displayName() + " (" + pk.rarity().label + ")\n\n", pk.rarity().bookColor, ChatFormatting.BOLD));
      }

      m.append(t("Both are permanent.", ChatFormatting.GRAY));
      return m;
   }

   private static Component statsBarsPage(RpgData d) {
      MutableComponent m = Component.empty();
      m.append(t("STATS IN BARS\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      int maxHp = Math.max(1, 20 + d.maxHealthBonus());
      int hp = Minecraft.getInstance().player == null ? maxHp : Math.round(Minecraft.getInstance().player.getHealth());
      bar(m, "Health (HP)", (long)Math.max(0, hp), (long)maxHp, ChatFormatting.RED);
      float maxEnergy = d.maxEnergy();
      bar(m, "Energy (CE)", (long)Math.round(d.energy), (long)Math.max(1, Math.round(maxEnergy)), ChatFormatting.AQUA);
      long required = Math.max(1L, d.expRequired());
      bar(m, "EXP (EXP)", d.level >= 100 ? required : d.exp, required, ChatFormatting.YELLOW);
      m.append(t("\nLVL " + d.level + "   Points " + d.points, ChatFormatting.DARK_GRAY));
      return m;
   }

   private static void bar(MutableComponent m, String label, long current, long max, ChatFormatting color) {
      int safeMax = (int)Math.max(1L, Math.min(2147483647L, max));
      int safeCurrent = (int)Math.max(0L, Math.min((long)safeMax, current));
      int filled = Math.round((float)safeCurrent / (float)safeMax * 22.0F);
      m.append(t(label + ": " + safeCurrent + "/" + safeMax + "\n", ChatFormatting.BOLD, color));
      m.append(t("|".repeat(filled), color));
      m.append(t("|".repeat(22 - filled), ChatFormatting.GRAY));
      m.append(Component.literal("\n\n"));
   }

   private static void passivePages(List<Component> pages, String title, Passive[] all, String selectedId) {
      int count = (int)Math.ceil((double)all.length / 1.0);

      for (int pg = 0; pg < count; pg++) {
         MutableComponent m = Component.empty();
         m.append(t(title + " " + (pg + 1) + "/" + count + "\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
         m.append(t("[ BACK TO INFORMATION ]", ChatFormatting.BLUE, ChatFormatting.BOLD));
         m.append(t("\n\n", ChatFormatting.GRAY));

         for (int i = pg * 1; i < Math.min(all.length, (pg + 1) * 1); i++) {
            Passive p = all[i];
            boolean mine = p.id().equalsIgnoreCase(selectedId);
            MutableComponent head = t((mine ? "★ " : "") + p.displayName() + " (" + p.rarity().label + ")", p.rarity().bookColor, ChatFormatting.BOLD);
            if (mine) {
               head.withStyle(ChatFormatting.UNDERLINE);
            }

            m.append(head).append(Component.literal("\n"));
            m.append(t(p.description() + "\n", ChatFormatting.GRAY));
            List<String> buffs = p.effects().buffs();
            List<String> debuffs = p.effects().debuffs();
            if (!buffs.isEmpty()) {
               m.append(t(String.join(", ", buffs) + "\n", ChatFormatting.DARK_GREEN));
            }

            if (!debuffs.isEmpty()) {
               m.append(t(String.join(", ", debuffs) + "\n", ChatFormatting.DARK_RED));
            }

            if (mine) {
               m.append(t("<< YOURS (permanent)\n", ChatFormatting.GOLD, ChatFormatting.BOLD));
            }

            m.append(Component.literal("\n"));
         }

         pages.add(m);
      }
   }

   private static String pct(double v) {
      double p = v * 100.0;
      return (Math.abs(p - (double)Math.round(p)) < 0.05 ? String.valueOf(Math.round(p)) : String.format(Locale.ROOT, "%.1f", p)) + "%";
   }

   private static MutableComponent t(String s, ChatFormatting... f) {
      return Component.literal(s).withStyle(f);
   }

}

