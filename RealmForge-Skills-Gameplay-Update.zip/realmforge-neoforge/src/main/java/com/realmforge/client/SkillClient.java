package com.realmforge.client;
import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.net.SkillPayload;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.network.PacketDistributor;
public final class SkillClient {
 public static final KeyMapping OPEN = new KeyMapping("key.realmforge.skills", InputConstants.Type.KEYSYM, 78, "key.categories.realmforge");
 public static final KeyMapping Z = new KeyMapping("key.realmforge.skill_z", InputConstants.Type.KEYSYM, 90, "key.categories.realmforge");
 public static final KeyMapping X = new KeyMapping("key.realmforge.skill_x", InputConstants.Type.KEYSYM, 88, "key.categories.realmforge");
 public static final KeyMapping C = new KeyMapping("key.realmforge.skill_c", InputConstants.Type.KEYSYM, 67, "key.categories.realmforge");
 private SkillClient() {}
 public static void tick(Minecraft mc) {
  while(OPEN.consumeClick()) if(mc.player!=null && mc.screen==null) mc.setScreen(new SkillsScreen());
  if(mc.player==null || mc.screen!=null) return;
  if(Z.consumeClick()) PacketDistributor.sendToServer(new SkillPayload("use","z"));
  if(X.consumeClick()) PacketDistributor.sendToServer(new SkillPayload("use","x"));
  if(C.consumeClick()) PacketDistributor.sendToServer(new SkillPayload("use","c"));
 }
}
