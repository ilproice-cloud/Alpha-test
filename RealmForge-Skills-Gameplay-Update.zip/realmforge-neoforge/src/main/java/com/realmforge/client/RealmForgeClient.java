package com.realmforge.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.client.BlockingClient;

import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/** Client-only mod-bus registrations: keys, particles, HUD layer. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class RealmForgeClient {
   private static final String CAT = "key.categories.realmforge";
   public static final KeyMapping OPEN = new KeyMapping("key.realmforge.open", InputConstants.Type.KEYSYM, 77, CAT);

   private RealmForgeClient() {
   }

   @SubscribeEvent
   public static void registerKeys(RegisterKeyMappingsEvent event) {
      event.register(OPEN);
      event.register(BlockingClient.BLOCK);
      event.register(SkillClient.OPEN);
      event.register(SkillClient.Z);
      event.register(SkillClient.X);
      event.register(SkillClient.C);
   }



   @SubscribeEvent
   public static void registerHud(RegisterGuiLayersEvent event) {
      event.registerAboveAll(RealmForgeMod.id("hud"), RpgHud::render);
   }








}
