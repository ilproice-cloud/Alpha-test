package com.realmforge.skill;

public final class SkillId {
   private SkillId() {}
   public static boolean valid(String id) { return id != null && (id.equals("barrage") || id.equals("heavy_punch") || id.equals("uppercut")); }
   public static String display(String id) { return switch (id) { case "barrage" -> "Barrage"; case "heavy_punch" -> "Heavy Punch"; case "uppercut" -> "Uppercut"; default -> id; }; }
}
