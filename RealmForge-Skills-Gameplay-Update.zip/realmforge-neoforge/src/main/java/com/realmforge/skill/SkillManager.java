package com.realmforge.skill;

import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import com.realmforge.net.SkillPayload;
import java.util.*;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public final class SkillManager {
   private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();
   private static final Map<UUID, BarrageState> BARRAGES = new HashMap<>();
   private SkillManager() {}
   private record BarrageState(int ticksLeft, int tickDelay) {}

   public static void handle(ServerPlayer p, SkillPayload payload) {
      RpgData d = RpgManager.get(p);
      if (payload.action().equals("assign")) {
         String id = payload.value();
         // value format is key:id; only known key slots are accepted.
         String[] pair = payload.value().split(":", 2);
         if (pair.length != 2 || !SkillId.valid(pair[1]) || !d.unlockedSkills.contains(pair[1])) return;
         switch (pair[0]) { case "z" -> d.skillZ = pair[1]; case "x" -> d.skillX = pair[1]; case "c" -> d.skillC = pair[1]; default -> { return; } }
         d.syncDirty = true; RpgManager.state(p.getServer()).setDirty(); RpgManager.sync(p, -1);
         p.displayClientMessage(Component.literal(SkillId.display(pair[1]) + " assigned to " + pair[0].toUpperCase(Locale.ROOT)).withStyle(ChatFormatting.GREEN), true);
      } else if (payload.action().equals("use")) {
         String id = switch (payload.value()) { case "z" -> d.skillZ; case "x" -> d.skillX; case "c" -> d.skillC; default -> ""; };
         if (!id.isEmpty()) use(p, id);
      }
   }

   public static boolean unlock(ServerPlayer p, String id) {
      if (!SkillId.valid(id)) return false;
      RpgData d = RpgManager.get(p);
      boolean changed = d.unlockedSkills.add(id);
      if (changed) { d.syncDirty = true; RpgManager.state(p.getServer()).setDirty(); RpgManager.sync(p, -1); }
      return changed;
   }

   public static void clear(UUID id) { COOLDOWNS.remove(id); BARRAGES.remove(id); }

   public static void tick(MinecraftServer server) {
      if (BARRAGES.isEmpty()) return;
      Iterator<Map.Entry<UUID, BarrageState>> it = BARRAGES.entrySet().iterator();
      while (it.hasNext()) {
         var e = it.next(); ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
         if (p == null || !p.isAlive() || e.getValue().ticksLeft <= 0) { it.remove(); continue; }
         BarrageState st = e.getValue();
         if (st.ticksLeft % st.tickDelay == 0) hit(p, 2.4, 1.0, 0.0, false);
         e.setValue(new BarrageState(st.ticksLeft - 1, st.tickDelay));
      }
   }

   private static void use(ServerPlayer p, String id) {
      if (!p.isAlive() || p.isSpectator()) return;
      RpgData d = RpgManager.get(p); if (!d.unlockedSkills.contains(id)) return;
      long now = p.serverLevel().getGameTime(); long ready = COOLDOWNS.getOrDefault(p.getUUID(), Collections.emptyMap()).getOrDefault(id, 0L);
      if (ready > now) { p.displayClientMessage(Component.literal("Skill cooldown: " + ((ready-now+19)/20) + "s").withStyle(ChatFormatting.RED), true); return; }
      float cost = id.equals("barrage") ? 2.0F : id.equals("heavy_punch") ? 2.0F : 1.5F;
      if (d.energy < cost) { p.displayClientMessage(Component.literal("Not enough energy!").withStyle(ChatFormatting.RED), true); return; }
      d.energy -= cost; d.syncDirty = true;
      int cooldown = id.equals("barrage") ? 100 : id.equals("heavy_punch") ? 60 : 40;
      COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new HashMap<>()).put(id, now + cooldown);
      if (id.equals("barrage")) { BARRAGES.put(p.getUUID(), new BarrageState(12, 2)); p.swing(net.minecraft.world.InteractionHand.MAIN_HAND); }
      else if (id.equals("heavy_punch")) { p.swing(net.minecraft.world.InteractionHand.MAIN_HAND); hit(p, 3.4, 2.8, 0.0, true); }
      else { p.swing(net.minecraft.world.InteractionHand.MAIN_HAND); hit(p, 3.2, 1.7, 0.9, true); }
      RpgManager.sync(p, -1);
   }

   private static void hit(ServerPlayer p, double range, double multiplier, double launchY, boolean knockback) {
      ServerLevel level = p.serverLevel(); Vec3 look = p.getLookAngle(); Vec3 flat = new Vec3(look.x,0,look.z); if (flat.lengthSqr() > 1.0E-5) flat = flat.normalize();
      List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range, 1.5, range), t -> t != p && t.isAlive() && !t.isAlliedTo(p) && p.canAttack(t));
      float damage = (float)p.getAttributeValue(Attributes.ATTACK_DAMAGE) * (float)multiplier; int count = 0;
      for (LivingEntity target : targets) {
         Vec3 to = target.position().subtract(p.position()); Vec3 horizontal = new Vec3(to.x,0,to.z); double dist = horizontal.length();
         if (dist > range || (dist > 0.8 && flat.lengthSqr() > 0 && horizontal.normalize().dot(flat) < 0.45)) continue;
         if (target.hurt(p.damageSources().playerAttack(p), damage)) { count++; if (knockback) { Vec3 m=target.getDeltaMovement(); target.setDeltaMovement(m.x*0.35+flat.x*0.35, launchY > 0 ? launchY : m.y, m.z*0.35+flat.z*0.35); target.hurtMarked=true; target.fallDistance=0; } }
      }
      Vec3 pos=p.position().add(flat.scale(1.1)).add(0,1,0); level.playSound(null,p.blockPosition(),count>0?SoundEvents.PLAYER_ATTACK_STRONG:SoundEvents.PLAYER_ATTACK_SWEEP,SoundSource.PLAYERS,1.0F, multiplier>2?0.75F:1.0F);
      level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,pos.x,pos.y,pos.z,Math.max(2,count*3),0.25,0.2,0.25,0.05);
   }
}
