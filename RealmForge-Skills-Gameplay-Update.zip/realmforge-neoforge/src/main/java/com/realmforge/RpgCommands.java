package com.realmforge;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.realmforge.data.Perk;
import com.realmforge.data.Rank;
import com.realmforge.data.Rarity;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.data.Trait;
import com.realmforge.skill.SkillId;
import com.realmforge.skill.SkillManager;
import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class RpgCommands {
   private static final SuggestionProvider<CommandSourceStack> STAT_SUGGEST = (c, b) -> SharedSuggestionProvider.suggest(
      Arrays.stream(Stat.values()).map(Stat::id).toList(), b
   );
   private static final SuggestionProvider<CommandSourceStack> TRAIT_SUGGEST = (c, b) -> SharedSuggestionProvider.suggest(
      Arrays.stream(Trait.values()).map(Trait::id).toList(), b
   );
   private static final SuggestionProvider<CommandSourceStack> PERK_SUGGEST = (c, b) -> SharedSuggestionProvider.suggest(
      Arrays.stream(Perk.values()).map(Perk::id).toList(), b
   );

   private RpgCommands() {
   }

   private static LiteralArgumentBuilder<CommandSourceStack> lit(String s) {
      return Commands.literal(s);
   }

   private static <T> RequiredArgumentBuilder<CommandSourceStack, T> arg(String name, com.mojang.brigadier.arguments.ArgumentType<T> type) {
      return Commands.argument(name, type);
   }

   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      LiteralArgumentBuilder<CommandSourceStack> root = lit("realmforge").executes(c -> openBook(c.getSource()));

      root.then(lit("book").executes(c -> openBook(c.getSource())));
      root.then(lit("stats").executes(c -> stats(c.getSource())));
      root.then(lit("skills").executes(c -> openSkills(c.getSource())).then(lit("unlock").then(arg("skill", StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(Arrays.asList("barrage","heavy_punch","uppercut"),b)).executes(c -> { ServerPlayer p=c.getSource().getPlayer(); if(p==null)return 0; String id=StringArgumentType.getString(c,"skill"); if(!SkillId.valid(id)){c.getSource().sendFailure(Component.literal("Unknown skill."));return 0;} boolean added=SkillManager.unlock(p,id); msg(c.getSource(),Component.literal(added?"Unlocked "+SkillId.display(id)+".":"Skill already unlocked.").withStyle(added?ChatFormatting.GREEN:ChatFormatting.YELLOW)); return 1; }))));
      root.then(
         lit("exp").then(arg("amount", IntegerArgumentType.integer(1, 100000000)).executes(c -> {
            ServerPlayer p = c.getSource().getPlayer();
            if (p == null) {
               c.getSource().sendFailure(Component.literal("Players only."));
               return 0;
            }

            int amount = IntegerArgumentType.getInteger(c, "amount");
            RpgData d = RpgManager.get(p);
            RpgManager.award(p, d, (long)amount);
            msg(c.getSource(), Component.literal("Gained " + amount + " EXP.").withStyle(ChatFormatting.GREEN));
            RpgManager.sync(p, -1);
            return 1;
         }))
      );
      root.then(
         lit("stat")
            .then(
               arg("stat", StringArgumentType.word())
                  .suggests(STAT_SUGGEST)
                  .executes(c -> spend(c, 1, false))
                  .then(arg("amount", IntegerArgumentType.integer(1, 10000)).executes(c -> spend(c, IntegerArgumentType.getInteger(c, "amount"), false)))
            )
      );
      root.then(
         lit("ui")
            .then(
               lit("upgrade")
                  .then(
                     arg("stat", StringArgumentType.word())
                        .suggests(STAT_SUGGEST)
                        .executes(c -> spend(c, 1, true))
                        .then(arg("amount", IntegerArgumentType.integer(1, 10000)).executes(c -> spend(c, IntegerArgumentType.getInteger(c, "amount"), true)))
                  )
            )
            .then(lit("traits").executes(c -> openUiPage(c.getSource(), -2)))
            .then(lit("perks").executes(c -> openUiPage(c.getSource(), -3)))
            .then(lit("information").executes(c -> openUiPage(c.getSource(), 5)))
      );
      root.then(admin());
      dispatcher.register(root);
   }

   private static int openSkills(CommandSourceStack src) {
      ServerPlayer p=src.getPlayer(); if(p==null)return 0; RpgManager.sync(p,-10); return 1;
   }

   private static int openBook(CommandSourceStack src) {
      ServerPlayer p = src.getPlayer();
      if (p == null) {
         return 0;
      }

      RpgManager.sync(p, 0);
      return 1;
   }

   private static int openUiPage(CommandSourceStack src, int page) {
      ServerPlayer p = src.getPlayer();
      if (p == null) {
         return 0;
      }

      RpgManager.sync(p, page);
      return 1;
   }

   private static int spend(CommandContext<CommandSourceStack> c, int amount, boolean ui) {
      CommandSourceStack src = c.getSource();
      ServerPlayer p = src.getPlayer();
      if (p == null) {
         src.sendFailure(Component.literal("Players only."));
         return 0;
      }

      Stat s = Stat.byId(StringArgumentType.getString(c, "stat"));
      if (s == null) {
         src.sendFailure(Component.literal("Unknown stat. Use str, agi, vit, int or ene."));
         return 0;
      }

      RpgData d = RpgManager.get(p);
      if (!d.spend(s, amount)) {
         src.sendFailure(Component.literal("Not enough stat points (you have " + d.points + ")."));
         if (ui) {
            RpgManager.sync(p, 1);
         }

         return 0;
      }

      RpgManager.refresh(p, d, true, ui ? 1 : -1);
      if (!ui) {
         msg(src, Component.literal("+" + amount + " " + s.abbr + " (now " + d.stat(s) + "), " + d.points + " points left.").withStyle(ChatFormatting.GREEN));
      }

      return 1;
   }

   private static int stats(CommandSourceStack src) {
      ServerPlayer p = src.getPlayer();
      if (p == null) {
         return 0;
      }

      RpgData d = RpgManager.get(p);
      Rank r = d.rank();
      msg(src, Component.literal("== " + p.getName().getString() + " ==").withStyle(ChatFormatting.GOLD));
      msg(
         src,
         Component.literal(r.icon + " " + r.label + "  Lv." + d.level + "  EXP " + d.exp + "/" + d.expRequired() + "  Points " + d.points).withStyle(r.color)
      );
      Trait t = d.trait();
      Perk pk = d.perk();
      if (t != null) {
         msg(src, Component.literal("Trait: " + t.displayName() + " (" + t.rarity().label + ")").withStyle(t.rarity().color));
      }

      if (pk != null) {
         msg(src, Component.literal("Perk: " + pk.displayName() + " (" + pk.rarity().label + ")").withStyle(pk.rarity().color));
      }

      StringBuilder sb = new StringBuilder();
      for (Stat s : Stat.values()) {
         sb.append(s.abbr).append(' ').append(d.stat(s)).append("   ");
      }

      msg(src, Component.literal(sb.toString()).withStyle(ChatFormatting.YELLOW));
      msg(
         src,
         Component.literal(String.format("HP %.0f/%.0f   Energy %.0f/%.0f (+%.1f/s)", p.getHealth(), p.getMaxHealth(), d.energy, d.maxEnergy(), d.regenPerSecond()))
            .withStyle(ChatFormatting.AQUA)
      );
      return 1;
   }

   /** Same gate as the admin tree (permission level 2) plus the owner of a single-player world. */








   private static LiteralArgumentBuilder<CommandSourceStack> admin() {
      LiteralArgumentBuilder<CommandSourceStack> a = lit("admin").requires(s -> s.hasPermission(2));

      a.then(
         lit("setlevel")
            .then(
               arg("player", EntityArgument.player())
                  .then(arg("level", IntegerArgumentType.integer(1, 100)).executes(c -> {
                     ServerPlayer t = EntityArgument.getPlayer(c, "player");
                     RpgData d = RpgManager.get(t);
                     int lvl = IntegerArgumentType.getInteger(c, "level");
                     d.points = Math.max(0, d.points + 3 * (lvl - d.level));
                     d.level = lvl;
                     d.exp = 0L;
                     return done(c, t, d, "Set level to " + lvl);
                  }))
            )
      );
      a.then(
         lit("addexp")
            .then(
               arg("player", EntityArgument.player())
                  .then(arg("amount", IntegerArgumentType.integer(1)).executes(c -> {
                     ServerPlayer t = EntityArgument.getPlayer(c, "player");
                     RpgData d = RpgManager.get(t);
                     RpgManager.award(t, d, (long)IntegerArgumentType.getInteger(c, "amount"));
                     return done(c, t, d, "Added EXP");
                  }))
            )
      );
      a.then(
         lit("addpoints")
            .then(
               arg("player", EntityArgument.player())
                  .then(arg("amount", IntegerArgumentType.integer(1, 100000)).executes(c -> {
                     ServerPlayer t = EntityArgument.getPlayer(c, "player");
                     RpgData d = RpgManager.get(t);
                     d.points = d.points + IntegerArgumentType.getInteger(c, "amount");
                     return done(c, t, d, "Added points");
                  }))
            )
      );
      a.then(
         lit("respec").then(arg("player", EntityArgument.player()).executes(c -> {
            ServerPlayer t = EntityArgument.getPlayer(c, "player");
            RpgData d = RpgManager.get(t);
            Arrays.fill(d.base, 0);
            d.points = 5 + 3 * (d.level - 1);
            return done(c, t, d, "Respecced stats (trait/perk untouched)");
         }))
      );
      a.then(
         lit("settrait")
            .then(
               arg("player", EntityArgument.player())
                  .then(arg("trait", StringArgumentType.word()).suggests(TRAIT_SUGGEST).executes(c -> {
                     Trait tr = Trait.byId(StringArgumentType.getString(c, "trait"));
                     if (tr == null) {
                        c.getSource().sendFailure(Component.literal("Unknown trait."));
                        return 0;
                     }

                     ServerPlayer t = EntityArgument.getPlayer(c, "player");
                     RpgData d = RpgManager.get(t);
                     d.traitId = tr.id();
                     return done(c, t, d, "Trait set to " + tr.displayName());
                  }))
            )
      );
      a.then(
         lit("setperk")
            .then(
               arg("player", EntityArgument.player())
                  .then(arg("perk", StringArgumentType.word()).suggests(PERK_SUGGEST).executes(c -> {
                     Perk pk = Perk.byId(StringArgumentType.getString(c, "perk"));
                     if (pk == null) {
                        c.getSource().sendFailure(Component.literal("Unknown perk."));
                        return 0;
                     }

                     ServerPlayer t = EntityArgument.getPlayer(c, "player");
                     RpgData d = RpgManager.get(t);
                     d.perkId = pk.id();
                     return done(c, t, d, "Perk set to " + pk.displayName());
                  }))
            )
      );
      a.then(
         lit("reroll").then(arg("player", EntityArgument.player()).executes(c -> {
            ServerPlayer t = EntityArgument.getPlayer(c, "player");
            RpgData d = RpgManager.get(t);
            RpgManager.initialize(t, d);
            return done(c, t, d, "Rerolled trait + perk");
         }))
      );
      a.then(
         lit("wipe").then(arg("player", EntityArgument.player()).executes(c -> {
            ServerPlayer t = EntityArgument.getPlayer(c, "player");
            RpgManager.state(t.getServer()).remove(t.getUUID());
            RpgData d = RpgManager.get(t);
            RpgManager.initialize(t, d);
            return done(c, t, d, "Wiped all RPG data and rolled a new trait/perk");
         }))
      );
      a.then(
         lit("simulate").then(arg("count", IntegerArgumentType.integer(1000, 1000000)).executes(c -> {
            int n = IntegerArgumentType.getInteger(c, "count");
            Random rnd = ThreadLocalRandom.current();
            int[] traitHits = new int[Rarity.values().length];
            int[] perkHits = new int[Rarity.values().length];

            for (int i = 0; i < n; i++) {
               traitHits[Rarity.pick(Trait.values(), rnd).rarity().ordinal()]++;
               perkHits[Rarity.pick(Perk.values(), rnd).rarity().ordinal()]++;
            }

            for (Rarity r : Rarity.values()) {
               String line = String.format(
                  Locale.ROOT,
                  "%-10s expected %5.2f%%  trait %5.2f%%  perk %5.2f%%",
                  r.label,
                  r.chancePercent(),
                  100.0 * (double)traitHits[r.ordinal()] / (double)n,
                  100.0 * (double)perkHits[r.ordinal()] / (double)n
               );
               msg(c.getSource(), Component.literal(line).withStyle(r.color));
            }

            return 1;
         }))
      );
      return a;
   }

   private static int done(CommandContext<CommandSourceStack> c, ServerPlayer t, RpgData d, String what) throws CommandSyntaxException {
      RpgManager.refresh(t, d, false, -1);
      msg(c.getSource(), Component.literal(what + " for " + t.getName().getString() + ".").withStyle(ChatFormatting.GREEN));
      return 1;
   }

   private static void msg(CommandSourceStack src, Component t) {
      src.sendSuccess(() -> t, false);
   }
}
