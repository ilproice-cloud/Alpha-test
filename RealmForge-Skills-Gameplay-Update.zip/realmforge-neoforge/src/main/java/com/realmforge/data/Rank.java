package com.realmforge.data;

import net.minecraft.ChatFormatting;

public enum Rank {
   NOVICE("Novice", "o", 1, 0, ChatFormatting.GRAY, ChatFormatting.DARK_GRAY),
   APPRENTICE("Apprentice", "+", 5, 10, ChatFormatting.GREEN, ChatFormatting.DARK_GREEN),
   ADEPT("Adept", "*", 10, 50, ChatFormatting.AQUA, ChatFormatting.DARK_AQUA),
   VETERAN("Veteran", "#", 20, 150, ChatFormatting.BLUE, ChatFormatting.DARK_BLUE),
   ELITE("Elite", "@", 30, 400, ChatFormatting.LIGHT_PURPLE, ChatFormatting.DARK_PURPLE),
   MASTER("Master", "$", 45, 900, ChatFormatting.GOLD, ChatFormatting.GOLD),
   GRANDMASTER("Grandmaster", "&", 65, 2000, ChatFormatting.RED, ChatFormatting.DARK_RED),
   LEGEND("Legend", "%", 90, 5000, ChatFormatting.YELLOW, ChatFormatting.WHITE);

   public static final double EXP_BONUS_PER_RANK = 0.10;
   public static final double STAT_BONUS_PER_RANK = 0.10;
   public static final double DODGE_PENALTY_PER_RANK = 0.075;

   public final String label;
   public final String icon;
   public final int minLevel;
   public final int minKills;
   public final ChatFormatting color;
   public final ChatFormatting bookColor;

   private Rank(String label, String icon, int minLevel, int minKills, ChatFormatting color, ChatFormatting bookColor) {
      this.label = label;
      this.icon = icon;
      this.minLevel = minLevel;
      this.minKills = minKills;
      this.color = color;
      this.bookColor = bookColor;
   }

   public static Rank forProgress(int level, int kills) {
      Rank best = NOVICE;

      for (Rank r : values()) {
         if (level >= r.minLevel && kills >= r.minKills) {
            best = r;
         }
      }

      return best;
   }

   /** Number of rank-ups this rank represents (Novice = 0, Apprentice = 1, ... Legend = 7). */
   public int steps() {
      return this.ordinal();
   }

   /** Extra EXP gained: +10% per rank-up (additive, Legend = +70%). */
   public double expBonus() {
      return EXP_BONUS_PER_RANK * (double)this.steps();
   }

   /** Bonus to every stat: +10% per rank-up (additive, Legend = +70%). */
   public double statBonus() {
      return STAT_BONUS_PER_RANK * (double)this.steps();
   }

   /** Share of dodge chance lost: 7.5% per rank-up (additive, Legend = -52.5%). Never below 0 dodge. */
   public double dodgePenalty() {
      return Math.min(1.0, DODGE_PENALTY_PER_RANK * (double)this.steps());
   }

   public Rank next() {
      return this.ordinal() + 1 < values().length ? values()[this.ordinal() + 1] : null;
   }
}
