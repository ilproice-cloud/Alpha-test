package com.realmforge;

import com.realmforge.data.Perk;
import com.realmforge.data.Rank;
import com.realmforge.data.Rarity;
import com.realmforge.data.RpgData;
import com.realmforge.data.RpgState;
import com.realmforge.data.Trait;
import com.realmforge.logic.EquipmentBonuses;
import com.realmforge.logic.StatApplier;
import com.realmforge.net.SyncPayload;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.network.PacketDistributor;

public final class RpgManager {
   private RpgManager() {
   }

   public static RpgState state(MinecraftServer server) {
      return server.overworld().getDataStorage().computeIfAbsent(RpgState.FACTORY, "realmforge");
   }

   public static RpgData get(ServerPlayer p) {
      return state(p.getServer()).get(p.getUUID());
   }

   public static void initialize(ServerPlayer p, RpgData d) {
      Random rnd = ThreadLocalRandom.current();
      Trait t = Rarity.pick(Trait.values(), rnd);
      Perk perk = Rarity.pick(Perk.values(), rnd);
      d.traitId = t.id();
      d.perkId = perk.id();
      d.equip = EquipmentBonuses.compute(p);
      d.energy = d.maxEnergy();
      d.syncDirty = true;
   }

   public static void sync(ServerPlayer p, int openPage) {
      RpgData d = get(p);
      long now = p.serverLevel().getGameTime();
      PacketDistributor.sendToPlayer(p, new SyncPayload(d.toSync(now).toString(), openPage));
      d.syncDirty = false;
   }

   public static void refresh(ServerPlayer p, RpgData d, boolean healGain, int openPage) {
      StatApplier.apply(p, d, healGain);
      checkRank(p, d, true);
      sync(p, openPage);
   }

   public static void checkRank(ServerPlayer p, RpgData d, boolean announce) {
      Rank r = Rank.forProgress(d.level, d.kills);
      if (r.ordinal() > d.rankIdx) {
         d.rankIdx = r.ordinal();
         d.syncDirty = true;
         // Rank-ups raise every stat by 10%, so re-apply max HP / speed right away.
         StatApplier.apply(p, d, true);
         if (announce) {
            p.displayClientMessage(
               Component.literal("RANK UP! You are now ")
                  .withStyle(ChatFormatting.GOLD)
                  .append(Component.literal(r.icon + " " + r.label).withStyle(r.color, ChatFormatting.BOLD)),
               false
            );
            p.displayClientMessage(
               Component.literal("Rank bonus: +" + Math.round(r.expBonus() * 100.0) + "% EXP, +"
                     + Math.round(r.statBonus() * 100.0) + "% all stats, -"
                     + String.format(java.util.Locale.ROOT, "%.1f", r.dodgePenalty() * 100.0) + "% dodge")
                  .withStyle(ChatFormatting.GRAY),
               false
            );
            p.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0F, 1.0F);
         }
      }
   }

   public static void award(ServerPlayer p, RpgData d, long amount) {
      if (amount > 0L) {
         int gained = d.addExp(amount);
         if (gained > 0) {
            p.displayClientMessage(
               Component.literal("LEVEL UP! Level " + d.level + "  (+" + gained * 3 + " stat points, " + d.points + " available)")
                  .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
               false
            );
            p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
         } else if (d.level < 100) {
            p.displayClientMessage(Component.literal("+" + amount + " EXP  (" + d.exp + "/" + d.expRequired() + ")").withStyle(ChatFormatting.GREEN), true);
         }

         checkRank(p, d, true);
         d.syncDirty = true;
      }
   }
}
