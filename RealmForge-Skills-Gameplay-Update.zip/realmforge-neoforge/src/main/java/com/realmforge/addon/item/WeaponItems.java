package com.realmforge.addon.item;

import com.realmforge.RealmForgeMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Custom RPG weapons. */
public final class WeaponItems {
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RealmForgeMod.MOD_ID);

   /** Netherite tier (+4) with +4 base: 1 (fist) + 4 + 4 = 9 attack damage before RPG scaling. */
   public static final DeferredItem<SwordItem> SLAUGHTER_DEMON = ITEMS.register(
      "slaughter_demon",
      () -> new SwordItem(
         Tiers.NETHERITE,
         new Item.Properties().stacksTo(1).fireResistant().rarity(net.minecraft.world.item.Rarity.EPIC).attributes(SwordItem.createAttributes(Tiers.NETHERITE, 4, -2.4F))
      )
   );

   /** STR bonus granted while the weapon is held (goes through rank/trait/perk like every other stat). */
   public static final int HELD_STR_BONUS = 5;
   /** Flat damage per STR is multiplied by this while the weapon is held (1.0 = normal). */
   public static final double STR_SCALING = 1.5;

   private WeaponItems() {
   }
}
