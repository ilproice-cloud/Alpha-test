package com.realmforge.addon.mixin.client;
import com.realmforge.addon.client.BlockingClient;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(HumanoidModel.class) public abstract class HumanoidModelMixin {
 @Shadow @Final public ModelPart rightArm; @Shadow @Final public ModelPart leftArm;
 @Inject(method="setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at=@At("TAIL"))
 private void realmforge$afterPose(LivingEntity entity,float a,float b,float c,float d,float e,CallbackInfo ci) {
  if(entity instanceof Player p && BlockingClient.isBlocking(p.getUUID())) { rightArm.xRot=-1.15F; rightArm.yRot=-0.85F; rightArm.zRot=0; leftArm.xRot=-1.15F; leftArm.yRot=0.85F; leftArm.zRot=0; }
 }
}
