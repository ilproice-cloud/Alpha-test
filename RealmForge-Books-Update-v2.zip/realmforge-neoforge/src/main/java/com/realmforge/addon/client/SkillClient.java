package com.realmforge.addon.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.logic.SkillManager;
import com.realmforge.addon.net.SkillEffectPayload;
import com.realmforge.addon.net.SkillUsePayload;
import com.realmforge.addon.skill.Skill;
import com.realmforge.client.ClientRpg;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Client side of the skill system: Z / X / C activation keys, the Skills menu key, and the effect + render hooks. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, value = Dist.CLIENT)
public final class SkillClient {
   private static final String CAT = "key.categories.realmforge";
   public static final KeyMapping MENU = new KeyMapping("key.realmforge.skills", InputConstants.Type.KEYSYM, 74, CAT); // J
   public static final KeyMapping QUEST_BOOK = new KeyMapping("key.realmforge.quest_book", InputConstants.Type.KEYSYM, 78, CAT); // N
   public static final KeyMapping[] SLOTS = {
      new KeyMapping("key.realmforge.skill_z", InputConstants.Type.KEYSYM, 90, CAT), // Z
      new KeyMapping("key.realmforge.skill_x", InputConstants.Type.KEYSYM, 88, CAT), // X
      new KeyMapping("key.realmforge.skill_c", InputConstants.Type.KEYSYM, 67, CAT)  // C
   };

   /** skill id -> client game time at which its cooldown ends (started when the server confirms a use) */
   private static final java.util.Map<String, Long> COOLDOWN_END = new java.util.HashMap<>();

   private SkillClient() {
   }

   /** Remaining cooldown in ticks (0 = ready). */
   public static float cooldownLeft(Skill s, float partialTick) {
      Minecraft mc = Minecraft.getInstance();
      Long end = COOLDOWN_END.get(s.id);
      if (end == null || mc.level == null) {
         return 0.0F;
      }

      return Math.max(0.0F, end - (mc.level.getGameTime() + partialTick));
   }

   @SubscribeEvent
   public static void onClientTick(ClientTickEvent.Post event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null) {
         return;
      }

      while (MENU.consumeClick()) {
         if (mc.screen == null) {
            if (ClientRpg.data == null) {
               mc.player.displayClientMessage(Component.literal("RealmForge data not loaded yet.").withStyle(ChatFormatting.RED), true);
            } else {
               mc.setScreen(AddonBooks.skillBook(0));
            }
         }
      }

      while (QUEST_BOOK.consumeClick()) {
         if (mc.screen == null && ClientRpg.data != null) {
            mc.setScreen(AddonBooks.questBook(0));
         }
      }

      for (int i = 0; i < SLOTS.length; i++) {
         while (SLOTS[i].consumeClick()) {
            if (mc.screen != null) {
               continue;
            }

            if (ClientRpg.data != null && Skill.byId(ClientRpg.data.skillKeys[i]) == null) {
               mc.player.displayClientMessage(
                  Component.literal("No skill assigned to " + SkillManager.KEY_NAMES[i] + ". Open the Skill Book (J).").withStyle(ChatFormatting.GRAY), true
               );
            } else {
               PacketDistributor.sendToServer(new SkillUsePayload(i));
            }
         }
      }
   }

   /** Server told us a player started a skill: play the (optional) player-body animation. The VFX are real mobs now. */
   public static void onEffect(SkillEffectPayload p) {
      Skill s = Skill.byId(p.skill());
      if (s != null) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null && mc.level != null && mc.player.getUUID().equals(p.player())) {
            // the server accepted our own skill use: its cooldown starts now (drives the skill bar overlay)
            COOLDOWN_END.put(s.id, mc.level.getGameTime() + s.cooldownTicks);
         }

         SkillPlayerAnim.start(p.player(), s);
      }
   }

   public static void clear() {
      COOLDOWN_END.clear();
      SkillPlayerAnim.clear();
   }
}
