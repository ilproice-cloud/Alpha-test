package com.realmforge.addon.entity;

import com.realmforge.addon.skill.Skill;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * The Prime Punch VFX "mobs" (Barrage / Heavy Punch / Uppercut VFX). They are invisible-bodied mobs whose only job is to
 * play the original model + animation. When a skill spawns one it follows its owner for its short lifetime (the original
 * mounted it on the player); a spawn-egg one just plays in place. Drawn by PunchVfxRenderer.
 */
public abstract class PunchVfxMob extends Mob {
   private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(PunchVfxMob.class, EntityDataSerializers.INT);
   private final Skill skill;

   protected PunchVfxMob(EntityType<? extends Mob> type, Level level, Skill skill) {
      super(type, level);
      this.skill = skill;
      this.noPhysics = true;
      this.setNoGravity(true);
      this.setNoAi(true);
      this.setInvulnerable(true);
   }

   @Override
   protected void defineSynchedData(SynchedEntityData.Builder builder) {
      super.defineSynchedData(builder);
      builder.define(OWNER_ID, -1);
   }

   public Skill skill() {
      return this.skill;
   }

   public void setOwner(Player owner) {
      this.entityData.set(OWNER_ID, owner == null ? -1 : owner.getId());
   }

   /** the player this effect follows, or null */
   public Entity owner() {
      int id = this.entityData.get(OWNER_ID);
      return id < 0 ? null : this.level().getEntity(id);
   }

   @Override
   public void tick() {
      super.tick();
      if (!this.level().isClientSide) {
         Entity owner = this.owner();
         if (owner != null) {
            this.setPos(owner.getX(), owner.getY(), owner.getZ());
         }

         if (this.tickCount >= this.skill.vfxTicks) {
            this.discard();
         }
      }
   }

   @Override
   public boolean isPushable() {
      return false;
   }

   @Override
   public boolean isPickable() {
      return false;
   }

   @Override
   protected void pushEntities() {
   }

   @Override
   public boolean removeWhenFarAway(double distanceToClosestPlayer) {
      return true;
   }

   /** effects are never saved with the world */
   public boolean shouldBeSaved() {
      return false;
   }
}
