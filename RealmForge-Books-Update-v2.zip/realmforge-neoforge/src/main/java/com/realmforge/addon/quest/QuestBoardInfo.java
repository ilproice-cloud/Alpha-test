package com.realmforge.addon.quest;

/** The one quest on the Quest Board. Shared by server logic and the client screen (no server imports here). */
public final class QuestBoardInfo {
   /** iron ore blocks to mine */
   public static final int TARGET = 5;
   /** exact EXP granted on claim (no clan / perk multiplier) */
   public static final long REWARD_EXP = 273L;
   /** the quest resets for everyone on this fixed clock: every 2 minutes of world time */
   public static final int REFRESH_TICKS = 2400;
   public static final String TITLE = "Mine 5 Iron Ore";
   /** book code that reopens the Quest Book (see ClientActions / AddonBooks) */
   public static final int BOOK_CODE = -2000;

   private QuestBoardInfo() {
   }

   public static long epoch(long gameTime) {
      return gameTime / REFRESH_TICKS;
   }

   /**
    * A taken quest that is not claimed yet survives refreshes (it stays in the Quest Book until it is finished and
    * claimed). Only a claimed quest is cleared by the refresh, so a new one can be taken.
    */
   public static boolean isActive(boolean accepted, boolean claimed) {
      return accepted && !claimed;
   }

   /** The reward of this quest was claimed in the current refresh window (after the next refresh a new quest is offered). */
   public static boolean isClaimedNow(boolean claimed, long savedEpoch, long gameTime) {
      return claimed && savedEpoch == epoch(gameTime);
   }

   /** The quest is taken: either still unfinished (any window) or claimed in this window. */
   public static boolean isTaken(boolean accepted, boolean claimed, long savedEpoch, long gameTime) {
      return accepted && (!claimed || savedEpoch == epoch(gameTime));
   }

   public static int ticksLeft(long gameTime) {
      return REFRESH_TICKS - (int)(gameTime % REFRESH_TICKS);
   }
}
