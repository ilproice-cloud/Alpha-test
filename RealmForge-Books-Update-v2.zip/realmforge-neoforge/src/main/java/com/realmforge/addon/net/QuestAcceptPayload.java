package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: the quest on the Quest Board at {@code pos} was pressed (take the quest). */
public record QuestAcceptPayload(BlockPos pos) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<QuestAcceptPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("quest_accept"));
   public static final StreamCodec<ByteBuf, QuestAcceptPayload> CODEC = StreamCodec.composite(BlockPos.STREAM_CODEC, QuestAcceptPayload::pos, QuestAcceptPayload::new);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
