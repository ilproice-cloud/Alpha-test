package com.realmforge.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.entity.PunchVfxMob;
import com.realmforge.addon.skill.Skill;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Draws the Prime Punch VFX mobs with their original geo model, animation and texture (no GeckoLib: BedrockModel /
 * BedrockAnim). Follows its owner smoothly at chest height (the original rode the player, at 75% of its height).
 */
public class PunchVfxRenderer extends EntityRenderer<PunchVfxMob> {
   private static final double RIDE_HEIGHT = 1.35;
   private static final Map<Skill, BedrockModel> MODELS = new EnumMap<>(Skill.class);
   private static final Map<Skill, BedrockAnim> ANIMS = new EnumMap<>(Skill.class);

   public PunchVfxRenderer(EntityRendererProvider.Context context) {
      super(context);
      this.shadowRadius = 0.0F;
   }

   private static BedrockModel model(Skill s) {
      return MODELS.computeIfAbsent(s, k -> BedrockModel.load("/assets/realmforge/skills/geo/" + k.resource + ".geo.json"));
   }

   private static BedrockAnim anim(Skill s) {
      return ANIMS.computeIfAbsent(s, k -> BedrockAnim.load("/assets/realmforge/skills/anim/" + k.resource + ".animation.json"));
   }

   @Override
   public ResourceLocation getTextureLocation(PunchVfxMob mob) {
      return RealmForgeMod.id("textures/entities/" + mob.skill().texture + ".png");
   }

   @Override
   public boolean shouldRender(PunchVfxMob mob, net.minecraft.client.renderer.culling.Frustum frustum, double x, double y, double z) {
      return true; // the effect is bigger than the mob's tiny box
   }

   @Override
   public void render(PunchVfxMob mob, float entityYaw, float partialTick, PoseStack ps, MultiBufferSource buffer, int light) {
      Skill s = mob.skill();
      BedrockModel model = model(s);
      BedrockAnim anim = anim(s);
      if (model == null) {
         return;
      }

      float len = anim == null ? 0.5F : anim.length;
      float t = (mob.tickCount + partialTick) / 20.0F;
      if (t > len + 0.05F) {
         return;
      }

      ps.pushPose();
      Entity owner = mob.owner();
      if (owner != null) {
         // follow the owner's smooth (interpolated) position instead of the mob's once-per-tick position
         Vec3 op = owner.getPosition(partialTick);
         Vec3 mp = mob.getPosition(partialTick);
         ps.translate(op.x - mp.x, op.y - mp.y + RIDE_HEIGHT, op.z - mp.z);
      }

      float yaw = Mth.rotLerp(partialTick, mob.yRotO, mob.getYRot());
      ps.mulPose(Axis.YP.rotationDegrees(180.0F - yaw)); // model -Z points where it was spawned facing
      if (s == Skill.BARRAGE) {
         ps.mulPose(Axis.XP.rotationDegrees(-Mth.lerp(partialTick, mob.xRotO, mob.getXRot()))); // barrage aims up / down
      }

      model.render(ps, buffer.getBuffer(RenderType.entityTranslucentEmissive(this.getTextureLocation(mob))), anim, Math.min(t, len), LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, true);
      ps.popPose();
   }
}
