package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: assign {@code skill} (empty = clear) to key slot 0/1/2 (Z/X/C); {@code page} = book spread to reopen. */
public record SkillAssignPayload(int slot, String skill, int page) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<SkillAssignPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("skill_assign"));
   public static final StreamCodec<ByteBuf, SkillAssignPayload> CODEC = StreamCodec.composite(
      ByteBufCodecs.VAR_INT, SkillAssignPayload::slot,
      ByteBufCodecs.STRING_UTF8, SkillAssignPayload::skill,
      ByteBufCodecs.VAR_INT, SkillAssignPayload::page,
      SkillAssignPayload::new
   );

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
