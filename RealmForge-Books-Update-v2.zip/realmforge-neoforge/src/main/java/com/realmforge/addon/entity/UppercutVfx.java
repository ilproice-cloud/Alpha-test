package com.realmforge.addon.entity;

import com.realmforge.addon.skill.Skill;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class UppercutVfx extends PunchVfxMob {
   public UppercutVfx(EntityType<UppercutVfx> type, Level level) {
      super(type, level, Skill.UPPERCUT);
   }
}
