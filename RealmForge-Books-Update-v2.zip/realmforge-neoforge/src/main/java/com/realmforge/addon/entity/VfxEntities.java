package com.realmforge.addon.entity;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.skill.Skill;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Registry for the three VFX mobs and their spawn eggs (ids and egg names match the Prime Punch files). */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class VfxEntities {
   public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, RealmForgeMod.MOD_ID);
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RealmForgeMod.MOD_ID);

   public static final DeferredHolder<EntityType<?>, EntityType<BarrageVfx>> BARRAGE = ENTITIES.register(
      "barragevfx", () -> EntityType.Builder.<BarrageVfx>of(BarrageVfx::new, MobCategory.MISC).sized(0.6F, 1.8F).clientTrackingRange(64).updateInterval(1).fireImmune().build("barragevfx")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<HeavyPunchVfx>> HEAVY_PUNCH = ENTITIES.register(
      "heavypunchvfx", () -> EntityType.Builder.<HeavyPunchVfx>of(HeavyPunchVfx::new, MobCategory.MISC).sized(0.6F, 1.8F).clientTrackingRange(64).updateInterval(1).fireImmune().build("heavypunchvfx")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<UppercutVfx>> UPPERCUT = ENTITIES.register(
      "uppercutvfx", () -> EntityType.Builder.<UppercutVfx>of(UppercutVfx::new, MobCategory.MISC).sized(0.6F, 1.8F).clientTrackingRange(64).updateInterval(1).fireImmune().build("uppercutvfx")
   );

   public static final DeferredItem<DeferredSpawnEggItem> BARRAGE_EGG = ITEMS.register(
      "barragevfx_spawn_egg", () -> new DeferredSpawnEggItem(BARRAGE, 0xEDEDED, 0xFF5A5A, new Item.Properties())
   );
   public static final DeferredItem<DeferredSpawnEggItem> HEAVY_PUNCH_EGG = ITEMS.register(
      "heavypunchvfx_spawn_egg", () -> new DeferredSpawnEggItem(HEAVY_PUNCH, 0xC9A66B, 0x5A3514, new Item.Properties())
   );
   public static final DeferredItem<DeferredSpawnEggItem> UPPERCUT_EGG = ITEMS.register(
      "uppercutvfx_spawn_egg", () -> new DeferredSpawnEggItem(UPPERCUT, 0xE8CBA0, 0x3A6BD6, new Item.Properties())
   );

   private VfxEntities() {
   }

   @SubscribeEvent
   public static void attributes(EntityAttributeCreationEvent event) {
      event.put(BARRAGE.get(), Mob.createMobAttributes().build());
      event.put(HEAVY_PUNCH.get(), Mob.createMobAttributes().build());
      event.put(UPPERCUT.get(), Mob.createMobAttributes().build());
   }

   /** Spawns the VFX mob for a skill use at the player, following them for its lifetime. */
   public static void spawn(ServerPlayer p, Skill s) {
      EntityType<? extends PunchVfxMob> type = switch (s) {
         case BARRAGE -> BARRAGE.get();
         case HEAVY_PUNCH -> HEAVY_PUNCH.get();
         case UPPERCUT -> UPPERCUT.get();
      };
      PunchVfxMob e = type.create(p.serverLevel());
      if (e == null) {
         return;
      }

      e.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot());
      e.setOwner(p);
      p.serverLevel().addFreshEntity(e);
   }
}
