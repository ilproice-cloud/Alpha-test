package com.realmforge.addon.skill;

import net.minecraft.network.chat.Component;

/**
 * The skills a player can unlock, assign to Z / X / C and use. Resource names point at the files copied
 * from the Prime Punch zip (assets/realmforge/skills/...). Tune the numbers here.
 */
public enum Skill {
   BARRAGE(
      "barrage", "Barrage",
      "A rapid flurry of punches that hammers the closest enemy in front of you.",
      "FINISHER", "Land all 9 punches on one enemy: the last becomes a Finisher with double damage and big knockback.",
      "barrage", "barrage", 4.0F, 200, 4.0, 1.5F, 0.2, 9, 20, 20, true
   ),
   HEAVY_PUNCH(
      "heavy_punch", "Heavy Punch",
      "One crushing punch with huge impact that sends enemies flying back.",
      "SLAM", "Hit an enemy that is in the air (right after an Uppercut): +50% damage and it is slammed down.",
      "heavypunch", "heavypunch", 3.0F, 160, 3.5, 10.0F, 1.5, 1, 9, 9, false
   ),
   UPPERCUT(
      "uppercut", "Uppercut",
      "A powerful upward punch that launches enemies high into the air.",
      "RISING COMBO", "Hit an enemy you Heavy Punched in the last 3 seconds: +25% damage and a 40% higher launch.",
      "uppercut", "heavypunch", 2.0F, 120, 3.5, 8.0F, 1.0, 1, 15, 9, false
   );

   public final String id;
   public final String display;
   public final String description;
   /** name and explanation of the unique special effect, and how to trigger it */
   public final String specialName;
   public final String specialText;
   /** base name of the geo / animation / player-animation files */
   public final String resource;
   /** texture under assets/realmforge/textures/entities/ (Uppercut reuses heavypunch: it has no texture of its own) */
   public final String texture;
   public final float energy;
   public final int cooldownTicks;
   /** reach in blocks (horizontal, measured to the edge of the target) */
   public final double range;
   /** base damage per hit before Realm Forge scaling (trait / perk damage-out) */
   public final float damage;
   /** multiplier on the flat STR damage (see DamagePipeline). Multi-hit skills use a small value per hit. */
   public final double strFactor;
   /** how many hits one use deals */
   public final int hits;
   /** how long the skill locks the player, in ticks (matches the original animation length) */
   public final int durationTicks;
   /** how long the VFX mob lives, in ticks (matches the original VFX animation length) */
   public final int vfxTicks;
   /** true: needs an enemy in range to start (no energy spent / no cooldown otherwise) */
   public final boolean needsTarget;

   Skill(
      String id, String display, String description, String specialName, String specialText, String resource, String texture,
      float energy, int cooldownTicks, double range, float damage, double strFactor, int hits, int durationTicks, int vfxTicks, boolean needsTarget
   ) {
      this.id = id;
      this.display = display;
      this.description = description;
      this.specialName = specialName;
      this.specialText = specialText;
      this.resource = resource;
      this.texture = texture;
      this.energy = energy;
      this.cooldownTicks = cooldownTicks;
      this.range = range;
      this.damage = damage;
      this.strFactor = strFactor;
      this.hits = hits;
      this.durationTicks = durationTicks;
      this.vfxTicks = vfxTicks;
      this.needsTarget = needsTarget;
   }

   public Component title() {
      return Component.literal(this.display);
   }

   public double cooldownSeconds() {
      return this.cooldownTicks / 20.0;
   }

   public static Skill byId(String id) {
      if (id == null || id.isEmpty()) {
         return null;
      }

      for (Skill s : values()) {
         if (s.id.equals(id)) {
            return s;
         }
      }

      return null;
   }
}
