package com.realmforge.addon.client;

import com.realmforge.addon.logic.SkillManager;
import com.realmforge.addon.net.QuestClaimPayload;
import com.realmforge.addon.net.SkillAssignPayload;
import com.realmforge.addon.quest.QuestBoardInfo;
import com.realmforge.addon.skill.Skill;
import com.realmforge.addon.skill.SkillMath;
import com.realmforge.client.ClientRpg;
import com.realmforge.client.RpgBookScreen;
import com.realmforge.data.RpgData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.IntConsumer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The two books built on the Realm Forge stats-book UI: the Skill Book (J, one page per skill) and the Quest Book (N).
 * Server actions that change data reopen the book through a sync code: -1000 - page = Skill Book, -2000 - page = Quest Book.
 */
public final class AddonBooks {
   /** true: also show a page for skills that are still locked (name + "Locked"). false: only unlocked skills, like the original spec. */
   private static final boolean SHOW_LOCKED_SKILLS = false;

   private AddonBooks() {
   }

   private static MutableComponent t(String s, ChatFormatting... f) {
      return Component.literal(s).withStyle(f);
   }

   /** Screen for a sync code from the server (see ClientActions). */
   public static Screen fromCode(int code) {
      int c = -code;
      return c >= 2000 ? questBook(c - 2000) : skillBook(c - 1000);
   }

   // ------------------------------------------------------------------ Skill Book

   public static Screen skillBook(int startPage) {
      RpgData d = ClientRpg.data;
      List<Component> pages = new ArrayList<>();
      List<Map<String, IntConsumer>> links = new ArrayList<>();

      for (Skill s : Skill.values()) {
         boolean unlocked = d.skills.contains(s.id);
         if (unlocked) {
            pages.add(skillPage(s, d));
            Map<String, IntConsumer> m = new HashMap<>();
            for (int slot = 0; slot < SkillManager.KEY_NAMES.length; slot++) {
               final int sl = slot;
               m.put("[ " + SkillManager.KEY_NAMES[slot] + " ]", first -> PacketDistributor.sendToServer(new SkillAssignPayload(sl, s.id, first)));
            }

            links.add(m);
         } else if (SHOW_LOCKED_SKILLS) {
            pages.add(t(s.display.toUpperCase(Locale.ROOT) + "\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_GRAY).append(t("Locked", ChatFormatting.DARK_RED)));
            links.add(new HashMap<>());
         }
      }

      if (pages.isEmpty()) {
         pages.add(t("SKILL BOOK\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE).append(t("You haven't unlocked any skills yet.", ChatFormatting.DARK_GRAY)));
         links.add(new HashMap<>());
      }

      return new RpgBookScreen(pages, startPage, links);
   }

   private static Component skillPage(Skill s, RpgData d) {
      String key = null;
      for (int i = 0; i < d.skillKeys.length; i++) {
         if (s.id.equals(d.skillKeys[i])) {
            key = SkillManager.KEY_NAMES[i];
         }
      }

      double per = SkillMath.perHit(s, d);
      double total = SkillMath.total(s, d);
      MutableComponent m = Component.empty();
      m.append(t(s.display.toUpperCase(Locale.ROOT), ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      m.append(t("   Key: " + (key == null ? "none" : key) + "\n", key == null ? ChatFormatting.DARK_GRAY : ChatFormatting.DARK_GREEN));
      // plain (non bold) so the three markers can sit on one line and stay clickable
      m.append(t("Assign: ", ChatFormatting.DARK_GRAY));
      m.append(t("[ Z ]", ChatFormatting.DARK_AQUA));
      m.append(t(" ", ChatFormatting.DARK_GRAY));
      m.append(t("[ X ]", ChatFormatting.DARK_AQUA));
      m.append(t(" ", ChatFormatting.DARK_GRAY));
      m.append(t("[ C ]\n\n", ChatFormatting.DARK_AQUA));

      m.append(t("Basic damage: ", ChatFormatting.DARK_GRAY));
      m.append(t(s.hits > 1 ? fmt(s.damage) + " x " + s.hits + " hits\n" : fmt(s.damage) + "\n", ChatFormatting.BLACK));
      m.append(t("Total damage: ", ChatFormatting.DARK_GRAY));
      m.append(t(fmt(total) + (s.hits > 1 ? " (" + fmt(per) + " x " + s.hits + ")" : "") + "\n", ChatFormatting.DARK_RED, ChatFormatting.BOLD));
      m.append(t("Energy cost: ", ChatFormatting.DARK_GRAY));
      m.append(t(fmt(s.energy) + "\n", ChatFormatting.DARK_AQUA));
      m.append(t("Cooldown: ", ChatFormatting.DARK_GRAY));
      m.append(t(fmt(s.cooldownSeconds()) + "s", ChatFormatting.BLACK));
      m.append(t("   Range: ", ChatFormatting.DARK_GRAY));
      m.append(t(fmt(s.range) + "\n\n", ChatFormatting.BLACK));

      m.append(t(s.description + "\n\n", ChatFormatting.GRAY));
      m.append(t("SPECIAL: " + s.specialName + "\n", ChatFormatting.BOLD, ChatFormatting.GOLD));
      m.append(t(s.specialText, ChatFormatting.DARK_GRAY));
      return m;
   }

   private static String fmt(double v) {
      return Math.abs(v - Math.round(v)) < 0.05 ? String.valueOf(Math.round(v)) : String.format(Locale.ROOT, "%.1f", v);
   }

   // ------------------------------------------------------------------ Quest Book

   public static Screen questBook(int startPage) {
      RpgData d = ClientRpg.data;
      Minecraft mc = Minecraft.getInstance();
      long gt = mc.level == null ? 0L : mc.level.getGameTime();
      boolean accepted = d != null && QuestBoardInfo.isTaken(d.questAccepted, d.questClaimed, d.questEpoch, gt);
      boolean claimed = d != null && QuestBoardInfo.isClaimedNow(d.questClaimed, d.questEpoch, gt);
      int prog = accepted ? Math.min(QuestBoardInfo.TARGET, d.questProgress) : 0;
      boolean done = accepted && prog >= QuestBoardInfo.TARGET;

      MutableComponent a = Component.empty();
      a.append(t("QUEST BOOK\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      Map<String, IntConsumer> aLinks = new HashMap<>();
      if (!accepted) {
         a.append(t("No active quest.\n\n", ChatFormatting.DARK_GRAY));
         a.append(t("Right-click a Quest Board and press the quest to take it.", ChatFormatting.GRAY));
      } else {
         a.append(t(QuestBoardInfo.TITLE + "\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_AQUA));
         a.append(t("Progress: ", ChatFormatting.DARK_GRAY));
         a.append(t(prog + " / " + QuestBoardInfo.TARGET + "\n", done ? ChatFormatting.DARK_GREEN : ChatFormatting.BLACK, ChatFormatting.BOLD));
         int filled = Math.round((float)prog / (float)QuestBoardInfo.TARGET * 22.0F);
         a.append(t("|".repeat(filled), ChatFormatting.DARK_GREEN));
         a.append(t("|".repeat(22 - filled) + "\n\n", ChatFormatting.GRAY));
         a.append(t("Reward: ", ChatFormatting.DARK_GRAY));
         a.append(t(QuestBoardInfo.REWARD_EXP + " EXP\n\n", ChatFormatting.GOLD, ChatFormatting.BOLD));
         if (claimed) {
            a.append(t("Reward claimed.", ChatFormatting.DARK_GREEN, ChatFormatting.BOLD));
         } else if (done) {
            a.append(t("[ CLAIM REWARD ]", ChatFormatting.DARK_GREEN, ChatFormatting.BOLD));
            aLinks.put("[ CLAIM REWARD ]", first -> PacketDistributor.sendToServer(new QuestClaimPayload()));
         } else {
            a.append(t("Finish the quest to claim your reward.", ChatFormatting.GRAY));
         }
      }

      MutableComponent b = Component.empty();
      b.append(t("HOW IT WORKS\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      b.append(t("1. Right-click a Quest Board and press the quest to take it.\n\n", ChatFormatting.DARK_GRAY));
      b.append(t("2. Mine 5 iron ore. Progress only counts after you took the quest.\n\n", ChatFormatting.DARK_GRAY));
      b.append(t("3. Come back here and press Claim Reward for " + QuestBoardInfo.REWARD_EXP + " EXP.\n\n", ChatFormatting.DARK_GRAY));
      b.append(t("The board refreshes every 2 minutes, but your taken quest stays here until you finish and claim it. You can only take a new one after that.", ChatFormatting.GRAY));

      List<Component> pages = List.of(a, b);
      List<Map<String, IntConsumer>> links = List.of(aLinks, new HashMap<>());
      return new RpgBookScreen(pages, startPage, links);
   }
}
