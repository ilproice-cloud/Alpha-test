package com.realmforge.addon.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.net.QuestAcceptPayload;
import com.realmforge.addon.quest.QuestBoardInfo;
import com.realmforge.client.ClientRpg;
import com.realmforge.data.RpgData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Quest Board screen: the original chalkboard + parchment card artwork with the single quest on it. Press the quest card to
 * take it; progress and the reward claim then live in the Quest Book (N).
 */
public class QuestBoardScreen extends Screen {
   private static final ResourceLocation BOARD = RealmForgeMod.id("textures/screens/questboard2.png");
   private static final ResourceLocation CARD = RealmForgeMod.id("textures/screens/questbutton.png");
   private static final int BOARD_W = 427;
   private static final int BOARD_H = 298;
   private static final int CARD_W = 100;
   private static final int CARD_H = 132;
   private static final int CARD_X = (BOARD_W - CARD_W) / 2;
   private static final int CARD_Y = 46;
   private final BlockPos pos;

   public QuestBoardScreen(BlockPos pos) {
      super(Component.literal("Quest Board"));
      this.pos = pos;
   }

   private float scale() {
      return Math.min(1.0F, Math.min((this.width - 16) / (float)BOARD_W, (this.height - 16) / (float)BOARD_H));
   }

   private int boardLeft() {
      return (int)(this.width / 2 - BOARD_W * this.scale() / 2.0F);
   }

   private int boardTop() {
      return (int)(this.height / 2 - BOARD_H * this.scale() / 2.0F);
   }

   @Override
   protected void init() {
      int cx = this.width / 2;
      this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose()).bounds(cx - 30, this.boardTop() + (int)(200 * this.scale()), 60, 20).build());
   }

   private boolean overCard(double mouseX, double mouseY) {
      float s = this.scale();
      double lx = (mouseX - this.boardLeft()) / s;
      double ly = (mouseY - this.boardTop()) / s;
      return lx >= CARD_X && lx < CARD_X + CARD_W && ly >= CARD_Y && ly < CARD_Y + CARD_H;
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (super.mouseClicked(mouseX, mouseY, button)) {
         return true;
      }

      if (button == 0 && this.overCard(mouseX, mouseY)) {
         PacketDistributor.sendToServer(new QuestAcceptPayload(this.pos)); // take the quest
         return true;
      }

      return false;
   }

   @Override
   public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
      super.renderBackground(g, mouseX, mouseY, partialTick);
      Minecraft mc = Minecraft.getInstance();
      RpgData d = ClientRpg.data;
      long gt = mc.level == null ? 0L : mc.level.getGameTime();
      boolean accepted = d != null && QuestBoardInfo.isTaken(d.questAccepted, d.questClaimed, d.questEpoch, gt);
      boolean claimed = d != null && QuestBoardInfo.isClaimedNow(d.questClaimed, d.questEpoch, gt);
      int prog = accepted ? Math.min(QuestBoardInfo.TARGET, d.questProgress) : 0;
      int secs = QuestBoardInfo.ticksLeft(gt) / 20;
      boolean hover = this.overCard(mouseX, mouseY);

      float s = this.scale();
      g.pose().pushPose();
      g.pose().translate(this.boardLeft(), this.boardTop(), 0.0F);
      g.pose().scale(s, s, 1.0F);

      g.blit(BOARD, 0, 0, 0.0F, 0.0F, BOARD_W, BOARD_H, BOARD_W, BOARD_H);
      this.centered(g, "Quest Board", BOARD_W / 2, 14, 0xFFE8C0);
      this.centered(g, String.format("Refreshes in %d:%02d", secs / 60, secs % 60), BOARD_W / 2, 28, 0xBBBBBB);

      int mid = BOARD_W / 2;
      g.blit(CARD, CARD_X, CARD_Y, 0.0F, 0.0F, CARD_W, CARD_H, CARD_W, CARD_H);
      if (hover && !accepted && !claimed) {
         g.fill(CARD_X + 3, CARD_Y + 3, CARD_X + CARD_W - 3, CARD_Y + CARD_H - 3, 0x30FFFFFF);
      }

      int ink = 0x3B2A1A;
      this.centered(g, QuestBoardInfo.TITLE, mid, CARD_Y + 24, ink);

      g.pose().pushPose();
      g.pose().translate(mid - 16, CARD_Y + 40, 0.0F);
      g.pose().scale(2.0F, 2.0F, 1.0F);
      g.renderItem(new ItemStack(Items.IRON_ORE), 0, 0);
      g.pose().popPose();

      this.centered(g, "Reward: " + QuestBoardInfo.REWARD_EXP + " EXP", mid, CARD_Y + 84, 0x6B3F00);
      if (d == null) {
         this.centered(g, "Loading...", mid, CARD_Y + 102, ink);
      } else if (claimed) {
         this.centered(g, "Completed", mid, CARD_Y + 102, 0x1F6B1F);
      } else if (accepted) {
         this.centered(g, "Taken  " + prog + " / " + QuestBoardInfo.TARGET, mid, CARD_Y + 102, 0x1F4F8A);
         this.centered(g, "Open your Quest Book (N)", mid, CARD_Y + 114, ink);
      } else {
         this.centered(g, "Press to take quest", mid, CARD_Y + 102, hover ? 0x8A1F1F : 0x7A1F1F);
      }

      g.pose().popPose();
   }

   private void centered(GuiGraphics g, String text, int cx, int y, int color) {
      g.drawString(this.font, text, cx - this.font.width(text) / 2, y, color, false);
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
