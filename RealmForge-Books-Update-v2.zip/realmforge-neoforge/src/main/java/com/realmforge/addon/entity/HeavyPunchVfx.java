package com.realmforge.addon.entity;

import com.realmforge.addon.skill.Skill;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class HeavyPunchVfx extends PunchVfxMob {
   public HeavyPunchVfx(EntityType<HeavyPunchVfx> type, Level level) {
      super(type, level, Skill.HEAVY_PUNCH);
   }
}
