package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: claim the finished quest's reward (from the Quest Book). */
public record QuestClaimPayload() implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<QuestClaimPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("quest_claim"));
   public static final StreamCodec<ByteBuf, QuestClaimPayload> CODEC = StreamCodec.unit(new QuestClaimPayload());

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
