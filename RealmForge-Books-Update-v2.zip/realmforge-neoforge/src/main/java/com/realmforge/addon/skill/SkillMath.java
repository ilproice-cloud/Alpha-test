package com.realmforge.addon.skill;

import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.logic.DamagePipeline;

/** Mirrors the damage maths of {@link DamagePipeline} for a skill hit, so the book can show the real numbers. */
public final class SkillMath {
   private SkillMath() {
   }

   /** damage of ONE hit at the player's current stats (before the victim's own defences) */
   public static double perHit(Skill s, RpgData d) {
      return perHit(s, d, s.damage);
   }

   public static double perHit(Skill s, RpgData d, float base) {
      double mult = d.dmgOut() * d.physMult(); // trait / perk damage-out, STR physical multiplier
      double str = (double)d.stat(Stat.STR) * DamagePipeline.DMG_PER_STR * s.strFactor;
      if (d.toji()) {
         str *= 1.75;
      }

      return (double)base * mult + str;
   }

   /** damage of a full use (all hits) */
   public static double total(Skill s, RpgData d) {
      return perHit(s, d) * s.hits;
   }
}
