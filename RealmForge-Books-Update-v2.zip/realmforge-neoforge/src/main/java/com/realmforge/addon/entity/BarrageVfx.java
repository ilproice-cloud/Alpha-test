package com.realmforge.addon.entity;

import com.realmforge.addon.skill.Skill;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class BarrageVfx extends PunchVfxMob {
   public BarrageVfx(EntityType<BarrageVfx> type, Level level) {
      super(type, level, Skill.BARRAGE);
   }
}
