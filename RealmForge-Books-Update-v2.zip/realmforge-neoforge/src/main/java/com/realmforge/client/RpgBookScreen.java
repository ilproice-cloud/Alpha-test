package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.client.ClanPage;
import com.realmforge.data.Stat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.IntConsumer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

public final class RpgBookScreen extends Screen {
   private static final ResourceLocation BOOK_TEXTURE = RealmForgeMod.id("textures/gui/rpg_book_background.png");
   private static final ResourceLocation PREV = RealmForgeMod.id("textures/gui/previous_button.png");
   private static final ResourceLocation NEXT = RealmForgeMod.id("textures/gui/next_button.png");
   private static final ResourceLocation EXIT = RealmForgeMod.id("textures/gui/exit_button.png");
   private static final int ART_W = 463;
   private static final int ART_H = 301;
   private final List<Component> pages;
   private int firstPage;
   private int bookX;
   private int bookY;
   private int bookW;
   private int bookH;
   private float scale;
   private int closeButtonX;
   private int closeButtonY;
   private int closeButtonW;
   private int closeButtonH;
   private int leftButtonX;
   private int rightButtonX;
   private int navButtonY;
   private int navButtonW;
   private int navButtonH;
   private final boolean catalogueScreen;
   /** optional per-page clickable markers (marker text -> action receiving the first page of the current spread) */
   private final List<Map<String, IntConsumer>> pageLinks;

   public RpgBookScreen(List<Component> pages, int startPage, boolean catalogueScreen) {
      this(pages, startPage, catalogueScreen, null);
   }

   /** A custom book (Skill Book / Quest Book): pages plus, for every page, the marker lines that act as buttons. */
   public RpgBookScreen(List<Component> pages, int startPage, List<Map<String, IntConsumer>> pageLinks) {
      this(pages, startPage, false, pageLinks);
   }

   private RpgBookScreen(List<Component> pages, int startPage, boolean catalogueScreen, List<Map<String, IntConsumer>> pageLinks) {
      super(Component.literal("RealmForge"));
      this.pages = new ArrayList<>(pages);
      this.firstPage = this.clampFirstPage(startPage);
      this.catalogueScreen = catalogueScreen;
      this.pageLinks = pageLinks;
   }

   @Override
   protected void init() {
      this.clearWidgets();
      float sx = ((float)this.width - 116.0F) / 463.0F;
      float sy = ((float)this.height - 36.0F) / 301.0F;
      this.scale = Math.max(0.25F, Math.min(1.65F, Math.min(sx, sy)));
      this.bookW = Math.max(1, Math.round(463.0F * this.scale));
      this.bookH = Math.max(1, Math.round(301.0F * this.scale));
      this.bookX = (this.width - this.bookW) / 2;
      this.bookY = Math.max(4, (this.height - this.bookH) / 2);
      int buttonW = Math.max(22, Math.round(30.0F * this.scale));
      int buttonH = Math.max(22, Math.round(30.0F * this.scale));
      int closeX = Math.min(this.width - buttonW - 2, this.bookX + this.bookW - buttonW / 2);
      int closeY = Math.max(2, this.bookY - buttonH / 2);
      this.addRenderableWidget(Button.builder(Component.empty(), b -> this.onClose()).bounds(closeX, closeY, buttonW, buttonH).build());
      this.closeButtonX = closeX;
      this.closeButtonY = closeY;
      this.closeButtonW = buttonW;
      this.closeButtonH = buttonH;
      int sideGap = Math.max(4, Math.round(10.0F * this.scale));
      int leftX = Math.max(2, this.bookX - buttonW - sideGap);
      int rightX = Math.min(this.width - buttonW - 2, this.bookX + this.bookW + sideGap);
      if (leftX + buttonW > this.bookX) {
         leftX = Math.max(2, this.bookX + sideGap);
      }

      if (rightX < this.bookX + this.bookW) {
         rightX = Math.min(this.width - buttonW - 2, this.bookX + this.bookW - buttonW - sideGap);
      }

      int buttonY = Math.max(2, Math.min(this.height - buttonH - 2, this.bookY + this.bookH / 2 - buttonH / 2));
      this.leftButtonX = leftX;
      this.rightButtonX = rightX;
      this.navButtonY = buttonY;
      this.navButtonW = buttonW;
      this.navButtonH = buttonH;
      this.addRenderableWidget(Button.builder(Component.empty(), b -> this.changeSpread(-2)).bounds(leftX, buttonY, buttonW, buttonH).build());
      this.addRenderableWidget(Button.builder(Component.empty(), b -> this.changeSpread(2)).bounds(rightX, buttonY, buttonW, buttonH).build());
   }

   private void changeSpread(int amount) {
      int next = this.clampFirstPage(this.firstPage + amount);
      if (next != this.firstPage) {
         Minecraft.getInstance().setScreen(new RpgBookScreen(this.pages, next, this.catalogueScreen, this.pageLinks));
      }
   }

   private void sendCommand(String command) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.player.connection != null) {
         mc.player.connection.sendCommand(command);
      }
   }

   private int clampFirstPage(int requested) {
      int maxFirst = Math.max(0, (this.pages.size() - 1) / 2 * 2);
      return Math.max(0, Math.min(requested, maxFirst));
   }

   @Override
   public void render(GuiGraphics ctx, int mouseX, int mouseY, float delta) {
      ctx.pose().pushPose();
      ctx.pose().translate((float)this.bookX, (float)this.bookY, 0.0F);
      ctx.pose().scale(this.scale, this.scale, 1.0F);
      ctx.blit(BOOK_TEXTURE, 0, 0, 0.0F, 0.0F, 463, 301, 463, 301);
      this.drawPage(ctx, this.firstPage, 30, 38, 185, 10);
      this.drawPage(ctx, this.firstPage + 1, 258, 38, 185, 10);
      ctx.pose().popPose();
      super.render(ctx, mouseX, mouseY, delta);
      ctx.blit(PREV, this.leftButtonX, this.navButtonY, 0.0F, 0.0F, this.navButtonW, this.navButtonH, this.navButtonW, this.navButtonH);
      ctx.blit(NEXT, this.rightButtonX, this.navButtonY, 0.0F, 0.0F, this.navButtonW, this.navButtonH, this.navButtonW, this.navButtonH);
      ctx.blit(EXIT, this.closeButtonX, this.closeButtonY, 0.0F, 0.0F, this.closeButtonW, this.closeButtonH, this.closeButtonW, this.closeButtonH);
   }

   private void drawPage(GuiGraphics ctx, int index, int x, int y, int maxWidth, int lineHeight) {
      if (index >= 0 && index < this.pages.size()) {
         List<FormattedCharSequence> lines = this.font.split((FormattedText)this.pages.get(index), maxWidth);
         int maxLines = 17;
         int drawn = 0;
         ctx.pose().pushPose();
         ctx.pose().translate((float)x, (float)y, 0.0F);
         ctx.pose().scale(0.92F, 0.92F, 1.0F);

         for (FormattedCharSequence line : lines) {
            if (drawn >= maxLines) {
               break;
            }

            ctx.drawString(this.font, line, 0, drawn * lineHeight, -14082024, false);
            drawn++;
         }

         ctx.drawString(this.font, Component.literal(String.valueOf(index + 1)).withStyle(ChatFormatting.DARK_GRAY), maxWidth / 2 - 2, 238, -9739690, false);
         ctx.pose().popPose();
      }
   }

   @Override
   public void renderBackground(GuiGraphics context, int mouseX, int mouseY, float delta) {
      // no dimmed background, the book texture is the background
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button != 0) {
         return super.mouseClicked(mouseX, mouseY, button);
      }

      double lx = (mouseX - (double)this.bookX) / (double)this.scale;
      double ly = (mouseY - (double)this.bookY) / (double)this.scale;
      if (this.pageLinks != null) {
         // custom book: only its own markers are clickable
         for (int pg = this.firstPage; pg <= this.firstPage + 1 && pg < this.pages.size(); pg++) {
            Map<String, IntConsumer> links = pg < this.pageLinks.size() ? this.pageLinks.get(pg) : null;
            if (links == null) {
               continue;
            }

            int pageX = pg == this.firstPage ? 30 : 258;
            for (Map.Entry<String, IntConsumer> e : links.entrySet()) {
               int[] at = this.locate(this.pages.get(pg), e.getKey());
               if (at != null && at[0] < 17 && this.hitTextRange(lx, ly, pageX, 38, at[1], at[0], this.font.width(e.getKey()))) {
                  e.getValue().accept(this.firstPage);
                  return true;
               }
            }
         }

         return super.mouseClicked(mouseX, mouseY, button);
      }

      if (this.catalogueScreen) {
         if (this.hitText(lx, ly, 30, 38, 0, 1, "[ BACK TO INFORMATION ]")) {
            Minecraft.getInstance().setScreen(RpgBook.main(4));
            return true;
         }

         if (this.hitText(lx, ly, 258, 38, 0, 1, "[ BACK TO INFORMATION ]")) {
            Minecraft.getInstance().setScreen(RpgBook.main(4));
            return true;
         }
      } else if (this.firstPage == 0) {
         Stat[] stats = Stat.values();

         for (int i = 0; i < stats.length; i++) {
            Stat stat = stats[i];
            String label = stat.abbr + " " + ClientRpg.data.stat(stat) + " ";
            int labelWidth = this.font.width(label);
            int row = 1 + i * 2;
            if (this.hitTextRange(lx, ly, 258, 38, labelWidth, row, this.font.width("[+1]"))) {
               this.sendCommand("realmforge ui upgrade " + stat.name().toLowerCase(Locale.ROOT) + " 1");
               return true;
            }

            int x5 = labelWidth + this.font.width("[+1] ");
            if (this.hitTextRange(lx, ly, 258, 38, x5, row, this.font.width("[+5]"))) {
               this.sendCommand("realmforge ui upgrade " + stat.name().toLowerCase(Locale.ROOT) + " 5");
               return true;
            }
         }
      } else if (this.firstPage == 4 && this.firstPage + 1 < this.pages.size()) {
         // Button rows are located from the real wrapped text, so they stay correct if a line wraps.
         Component info = this.pages.get(this.firstPage + 1);
         if (this.hitButton(lx, ly, info, "[ TRAITS ]")) {
            Minecraft.getInstance().setScreen(RpgBook.screen(-2));
            return true;
         }

         if (this.hitButton(lx, ly, info, "[ PERKS ]")) {
            Minecraft.getInstance().setScreen(RpgBook.screen(-3));
            return true;
         }

         // fused addon: clan page button
         if (this.hitButton(lx, ly, info, "[ CLAN ]")) {
            Minecraft.getInstance().setScreen(new RpgBookScreen(ClanPage.pages(ClientRpg.data), 0, true));
            return true;
         }

         // rank system explanation
         if (this.hitButton(lx, ly, info, "[ RANK UP ]")) {
            Minecraft.getInstance().setScreen(new RpgBookScreen(RankPage.pages(ClientRpg.data), 0, true));
            return true;
         }
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   /** {wrapped line index, x offset in px of the marker on that line} for the marker text, or null. */
   private int[] locate(Component page, String marker) {
      List<FormattedCharSequence> lines = this.font.split((FormattedText)page, 185);
      for (int i = 0; i < lines.size(); i++) {
         StringBuilder sb = new StringBuilder();
         lines.get(i).accept((index, style, codePoint) -> {
            sb.appendCodePoint(codePoint);
            return true;
         });
         int at = sb.indexOf(marker);
         if (at >= 0) {
            return new int[] {i, this.font.width(sb.substring(0, at))};
         }
      }

      return null;
   }

   /** Index of the first wrapped line of the page that contains the marker text, or -1. */
   private int lineOf(Component page, String marker) {
      List<FormattedCharSequence> lines = this.font.split((FormattedText)page, 185);
      for (int i = 0; i < lines.size(); i++) {
         StringBuilder sb = new StringBuilder();
         lines.get(i).accept((index, style, codePoint) -> {
            sb.appendCodePoint(codePoint);
            return true;
         });
         if (sb.indexOf(marker) >= 0) {
            return i;
         }
      }

      return -1;
   }

   private boolean hitButton(double lx, double ly, Component page, String marker) {
      int line = this.lineOf(page, marker);
      return line >= 0 && line < 17 && this.hitText(lx, ly, 258, 38, 0, line, marker);
   }

   private boolean hitText(double lx, double ly, int pageX, int pageY, int textX, int line, String text) {
      return this.hitTextRange(lx, ly, pageX, pageY, textX, line, this.font.width(text));
   }

   private boolean hitTextRange(double lx, double ly, int pageX, int pageY, int textX, int line, int textWidth) {
      double x = (double)pageX + (double)textX * 0.92;
      double y = (double)pageY + (double)(line * 10) * 0.92;
      return lx >= x - 3.0 && lx <= x + (double)textWidth * 0.92 + 3.0 && ly >= y - 3.0 && ly <= y + 9.2 + 3.0;
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256) {
         this.onClose();
         return true;
      } else if (keyCode == 263) {
         this.changeSpread(-2);
         return true;
      } else if (keyCode == 262) {
         this.changeSpread(2);
         return true;
      } else {
         return super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
