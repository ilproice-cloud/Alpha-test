package com.realmforge.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.realmforge.addon.client.SkillClient;
import com.realmforge.addon.logic.SkillManager;
import com.realmforge.addon.skill.Skill;
import com.realmforge.data.RpgData;
import java.util.Locale;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/**
 * Skill bar at the top right of the screen: the supplied wooden frame (a column of round slots) with the skills
 * assigned to Z / X / C in its first three slots. While a skill is on cooldown its icon is darkened and the
 * cooldown clock with the remaining seconds is shown on top of it.
 */
public final class SkillBarHud {
   /** true = frame mirrored horizontally (slots on the right edge, the bracket opens to the left). */
   private static final boolean MIRRORED = true;
   private static final ResourceLocation FRAME = ResourceLocation.fromNamespaceAndPath(
         "realmforge", MIRRORED ? "textures/gui/skills/skill_bar_mirrored.png" : "textures/gui/skills/skill_bar_original.png");
   private static final ResourceLocation CLOCK = ResourceLocation.fromNamespaceAndPath("realmforge", "textures/gui/skills/cooldown.png");

   // measured in the pixels of the cropped 336x477 frame texture
   private static final int TEX_W = 336;
   private static final int TEX_H = 477;
   private static final float SLOT_CX = MIRRORED ? 248.5F : 87.5F;
   private static final float SLOT_FIRST_CY = 70.5F;
   private static final float SLOT_STEP = 62.5F;
   private static final float SLOT_DIAMETER = 52.0F;
   /** frame scale on screen (texture pixels -> GUI pixels) */
   private static final float S = 0.38F;
   private static final int MARGIN = 3;

   private SkillBarHud() {
   }

   private static int sc(float texturePixels) {
      return Math.round(texturePixels * S);
   }

   private static ResourceLocation icon(Skill s) {
      return ResourceLocation.fromNamespaceAndPath("realmforge", "textures/gui/skills/" + s.id + ".png");
   }

   public static void render(GuiGraphics g, DeltaTracker tickCounter, RpgData d) {
      Minecraft mc = Minecraft.getInstance();
      int w = sc(TEX_W);
      int h = sc(TEX_H);
      int x = g.guiWidth() - w - MARGIN;
      int y = MARGIN;
      float pt = tickCounter.getGameTimeDeltaPartialTick(false);

      g.blit(FRAME, x, y, w, h, 0.0F, 0.0F, TEX_W, TEX_H, TEX_W, TEX_H);

      int size = sc(SLOT_DIAMETER);
      for (int i = 0; i < d.skillKeys.length; i++) {
         Skill s = Skill.byId(d.skillKeys[i]);
         if (s == null || !d.skills.contains(s.id)) {
            continue;
         }

         int cx = x + sc(SLOT_CX);
         int cy = y + sc(SLOT_FIRST_CY + SLOT_STEP * i);
         int ix = cx - size / 2;
         int iy = cy - size / 2;

         float left = SkillClient.cooldownLeft(s, pt);
         boolean cooling = left > 0.0F;
         if (cooling) {
            RenderSystem.setShaderColor(0.35F, 0.35F, 0.35F, 1.0F);
         }

         g.blit(icon(s), ix, iy, size, size, 0.0F, 0.0F, 32, 32, 32, 32);
         if (cooling) {
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            int clock = Math.max(8, Math.round(size * 0.55F));
            g.blit(CLOCK, cx - clock / 2, cy - clock + 3, clock, clock, 0.0F, 0.0F, 32, 32, 32, 32);
            float secs = left / 20.0F;
            String t = secs >= 10.0F ? Integer.toString((int)Math.ceil(secs)) : String.format(Locale.ROOT, "%.1f", secs);
            g.pose().pushPose();
            g.pose().translate(cx, cy + 4, 0.0F);
            g.pose().scale(0.75F, 0.75F, 1.0F);
            g.drawString(mc.font, t, -mc.font.width(t) / 2, 0, 0xFFFFFF, true);
            g.pose().popPose();
         } else {
            // key hint in the lower-left corner of the slot
            String key = SkillManager.KEY_NAMES[i];
            g.pose().pushPose();
            g.pose().translate(ix + 1, iy + size - 6, 0.0F);
            g.pose().scale(0.7F, 0.7F, 1.0F);
            g.drawString(mc.font, key, 0, 0, 0xFFD27F, true);
            g.pose().popPose();
         }
      }
   }
}
