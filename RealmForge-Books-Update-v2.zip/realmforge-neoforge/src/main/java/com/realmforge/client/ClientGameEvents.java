package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.client.BlockingClient;
import com.realmforge.addon.client.SkillClient;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/** Client-only game-bus events: key handling each tick and disconnect cleanup. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, value = Dist.CLIENT)
public final class ClientGameEvents {
   private ClientGameEvents() {
   }



   /** The RealmForge HUD shows health and hunger, so the normal Minecraft hearts and food bar are not drawn. */
   @SubscribeEvent
   public static void onGuiLayerPre(RenderGuiLayerEvent.Pre event) {
      if (ClientRpg.data == null) {
         return; // custom HUD not loaded yet: keep the vanilla bars so the player is never left without any
      }

      if (event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH) || event.getName().equals(VanillaGuiLayers.FOOD_LEVEL)) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
      ClientRpg.data = null;
      BlockingClient.clear();
      SkillClient.clear();
   }

   @SubscribeEvent
   public static void onClientTick(ClientTickEvent.Post event) {
      Minecraft mc = Minecraft.getInstance();
      ClientRpg.tick++;
      BlockingClient.tick(mc);
      if (mc.player == null) {
         return;
      }



      while (RealmForgeClient.OPEN.consumeClick()) {
         if (mc.screen == null) {
            if (ClientRpg.data == null) {
               mc.player.displayClientMessage(Component.literal("RealmForge data not loaded yet.").withStyle(ChatFormatting.RED), true);
            } else {
               mc.setScreen(RpgBook.screen(0));
            }
         }
      }


   }
}
