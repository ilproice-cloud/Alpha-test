package com.realmforge.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.client.BlockingClient;
import com.realmforge.addon.client.RockParticle;
import com.realmforge.addon.client.SkillClient;
import com.realmforge.addon.skill.SkillParticles;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import com.realmforge.addon.client.PunchVfxRenderer;
import com.realmforge.addon.client.QuestBoardRenderer;
import com.realmforge.addon.entity.VfxEntities;
import com.realmforge.addon.quest.QuestBlocks;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/** Client-only mod-bus registrations: keys, particles, HUD layer. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class RealmForgeClient {
   private static final String CAT = "key.categories.realmforge";
   public static final KeyMapping OPEN = new KeyMapping("key.realmforge.open", InputConstants.Type.KEYSYM, 77, CAT);

   private RealmForgeClient() {
   }

   @SubscribeEvent
   public static void registerKeys(RegisterKeyMappingsEvent event) {
      event.register(OPEN);
      event.register(BlockingClient.BLOCK);
      event.register(SkillClient.MENU);
      event.register(SkillClient.QUEST_BOOK);
      for (net.minecraft.client.KeyMapping k : SkillClient.SLOTS) {
         event.register(k);
      }
   }

   @SubscribeEvent
   public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
      event.registerBlockEntityRenderer(QuestBlocks.QUEST_BOARD_BE.get(), QuestBoardRenderer::new);
      event.registerEntityRenderer(VfxEntities.BARRAGE.get(), PunchVfxRenderer::new);
      event.registerEntityRenderer(VfxEntities.HEAVY_PUNCH.get(), PunchVfxRenderer::new);
      event.registerEntityRenderer(VfxEntities.UPPERCUT.get(), PunchVfxRenderer::new);
   }

   @SubscribeEvent
   public static void registerParticles(RegisterParticleProvidersEvent event) {
      event.registerSpriteSet(SkillParticles.ROCK.get(), RockParticle::small);
      event.registerSpriteSet(SkillParticles.BIG_ROCK.get(), RockParticle::big);
   }



   @SubscribeEvent
   public static void registerHud(RegisterGuiLayersEvent event) {
      event.registerAboveAll(RealmForgeMod.id("hud"), RpgHud::render);
   }








}
