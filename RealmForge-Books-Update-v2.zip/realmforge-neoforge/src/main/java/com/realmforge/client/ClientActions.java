package com.realmforge.client;

import net.minecraft.client.Minecraft;

final class ClientActions {
   private ClientActions() {
   }

   static void sync(String snbt, int openPage) {
      ClientRpg.accept(snbt);
      if (openPage <= -1000 && ClientRpg.data != null) {
         // addon books: -1000 - page = Skill Book, -2000 - page = Quest Book
         Minecraft.getInstance().setScreen(com.realmforge.addon.client.AddonBooks.fromCode(openPage));
      } else if (openPage != -1 && ClientRpg.data != null) {
         Minecraft.getInstance().setScreen(RpgBook.screen(openPage));
      }
   }
}
