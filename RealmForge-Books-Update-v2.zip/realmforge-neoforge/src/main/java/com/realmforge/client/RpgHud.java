package com.realmforge.client;

import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.food.FoodData;

/**
 * RealmForge parchment HUD: the supplied panel (transparent PNG) is the main GUI background,
 * with live segmented bars and the player's skin portrait drawn over it.
 *
 * All layout numbers below are measured in the pixels of the 790x316 panel texture
 * and scaled down to the on-screen size with {@link #S}.
 */
public final class RpgHud {
   private static final int TEX_W = 790;
   private static final int TEX_H = 316;
   /** On-screen width of the panel in GUI pixels (same footprint as the previous 75% HUD). */
   private static final int GUI_W = 288;
   private static final float S = GUI_W / (float)TEX_W;
   private static final int GUI_H = Math.round(TEX_H * S);
   private static final ResourceLocation BACKGROUND =
         ResourceLocation.fromNamespaceAndPath("realmforge", "textures/gui/main_hud_background.png");

   private RpgHud() {
   }

   public static void render(GuiGraphics g, DeltaTracker tickCounter) {
      Minecraft mc = Minecraft.getInstance();
      RpgData d = ClientRpg.data;
      if (d == null || mc.player == null || mc.options.hideGui) {
         return;
      }

      // Anchor the complete panel at the top-left.
      int x = 8;
      int y = 8;

      // Main panel artwork supplied by the user (transparent background).
      g.blit(BACKGROUND, x, y, GUI_W, GUI_H, 0.0F, 0.0F, TEX_W, TEX_H, TEX_W, TEX_H);

      // Player portrait inside the framed square (skin face + hat layer).
      int faceX = x + sc(94);
      int faceY = y + sc(84);
      int faceSize = sc(76);
      ResourceLocation skin = mc.player.getSkin().texture();
      g.blit(skin, faceX, faceY, faceSize, faceSize, 8, 8, 8, 8, 64, 64);
      g.blit(skin, faceX, faceY, faceSize, faceSize, 40, 8, 8, 8, 64, 64);

      // Top strip: level + rank icon on the left of the emblem, player name on the right.
      Rank rank = d.rank();
      Component level = Component.literal("Lv. " + d.level + "  " + rank.icon)
            .withStyle(ChatFormatting.DARK_GRAY);
      g.drawString(mc.font, level, x + sc(227), y + sc(27), 0xFFFFFF, false);
      String playerName = mc.font.plainSubstrByWidth(mc.player.getName().getString(), sc(735 - 418));
      Component name = Component.literal(playerName).withStyle(rank.color);
      g.drawString(mc.font, name, x + sc(418), y + sc(27), 0xFFFFFF, false);

      float hp = mc.player.getHealth() / Math.max(1.0F, mc.player.getMaxHealth());
      float energy = (float)(d.energy / Math.max(1.0D, d.maxEnergy()));
      FoodData food = mc.player.getFoodData();
      float hunger = food.getFoodLevel() / 20.0F;
      float exp = d.level >= 100 ? 1.0F :
            (float)d.exp / (float)Math.max(1L, d.expRequired());

      // Track rectangles (x, y, width, height) measured from the empty slots in the 790x316 panel.
      Bar hpBar = new Bar("hp", 11, 227, 58, 508, 29);
      Bar energyBar = new Bar("ce", 7, 227, 134, 324, 20);
      Bar expBar = new Bar("exp", 5, 227, 200, 227, 22);
      Bar hungerBar = new Bar("hunger", 6, 472, 200, 263, 22);

      drawBar(g, x, y, hpBar, hp);
      drawBar(g, x, y, energyBar, energy);
      drawBar(g, x, y, expBar, exp);
      drawBar(g, x, y, hungerBar, hunger);

      // Current / maximum indicators are centered over their respective bars.
      drawCenteredValue(g, mc, formatValue(mc.player.getHealth()) + " / " +
            formatValue(mc.player.getMaxHealth()), x, y, hpBar);
      drawCenteredValue(g, mc, formatValue(d.energy) + " / " +
            formatValue(d.maxEnergy()), x, y, energyBar);
      String expText = d.level >= 100 ? "MAX" : compact(d.exp) + " / " + compact(d.expRequired());
      drawCenteredValue(g, mc, expText, x, y, expBar);
      drawCenteredValue(g, mc, food.getFoodLevel() + " / 20", x, y, hungerBar);

      if (d.points > 0) {
         Component points = Component.literal("+" + d.points + " STAT POINTS")
               .withStyle(ChatFormatting.GOLD);
         g.drawString(mc.font, points, x + sc(227), y + sc(233), 0xFFFFFF, false);
      }

      // Skill bar (Z / X / C) at the top right.
      SkillBarHud.render(g, tickCounter, d);
   }

   /**
    * Compact number for the EXP readout: values under 10,000 are shown in full,
    * larger values use one truncated decimal and a suffix (12450 -> "12.4k", 10000 -> "10k",
    * 1,250,000 -> "1.2m", 3,400,000,000 -> "3.4b").
    */
   public static String compact(long value) {
      if (value < 10000L) {
         return Long.toString(Math.max(0L, value));
      }

      long unit;
      String suffix;
      if (value >= 1_000_000_000L) {
         unit = 1_000_000_000L;
         suffix = "b";
      } else if (value >= 1_000_000L) {
         unit = 1_000_000L;
         suffix = "m";
      } else {
         unit = 1_000L;
         suffix = "k";
      }

      long tenths = value / (unit / 10L); // truncate, do not round: 12450 -> 124 -> 12.4k
      long whole = tenths / 10L;
      long frac = tenths % 10L;
      return frac == 0L ? whole + suffix : whole + "." + frac + suffix;
   }

   private static String formatValue(double value) {
      if (Math.abs(value - Math.round(value)) < 0.01D) {
         return Long.toString(Math.round(value));
      }
      return String.format(java.util.Locale.ROOT, "%.1f", value);
   }

   private static int sc(float texturePixels) {
      return Math.round(texturePixels * S);
   }

   private record Bar(String folder, int count, int tx, int ty, int tw, int th) {
   }

   private static void drawCenteredValue(GuiGraphics g, Minecraft mc, String value,
                                         int originX, int originY, Bar bar) {
      int left = originX + sc(bar.tx());
      int top = originY + sc(bar.ty());
      int width = sc(bar.tw());
      int height = sc(bar.th());
      int textWidth = mc.font.width(value);
      int textX = left + Math.round((width - textWidth) / 2.0F);
      int textY = top + Math.max(0, Math.round((height - mc.font.lineHeight) / 2.0F));
      // A dark shadow keeps the indicator readable over both filled and empty segments.
      g.drawString(mc.font, value, textX, textY, 0xFFFFFF, true);
   }

   /**
    * Draws only the filled part of the bar. Empty segments are left alone so the
    * empty slot artwork of the panel shows through; a partly filled segment is clipped.
    */
   private static void drawBar(GuiGraphics g, int originX, int originY, Bar bar, float ratio) {
      float filled = Math.max(0.0F, Math.min(1.0F, ratio)) * bar.count();
      float pieceW = (float)bar.tw() / bar.count();
      int top = originY + sc(bar.ty());
      int h = Math.max(1, sc(bar.th()));
      for (int i = 0; i < bar.count(); i++) {
         float segment = Math.max(0.0F, Math.min(1.0F, filled - i));
         if (segment <= 0.0F) {
            continue;
         }

         ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(
               "realmforge", "textures/gui/" + bar.folder() + "/piece_" +
               String.format("%02d", i + 1) + ".png");
         int px = originX + sc(bar.tx() + i * pieceW);
         int right = originX + sc(bar.tx() + (i + 1) * pieceW);
         int w = Math.max(1, right - px);
         if (segment >= 1.0F) {
            g.blit(texture, px, top, w, h, 0.0F, 0.0F, 135, 65, 135, 65);
         } else {
            int cutW = Math.max(1, Math.round(w * segment));
            int cutU = Math.max(1, Math.round(135 * segment));
            g.blit(texture, px, top, cutW, h, 0.0F, 0.0F, cutU, 65, 135, 65);
         }
      }
   }
}
