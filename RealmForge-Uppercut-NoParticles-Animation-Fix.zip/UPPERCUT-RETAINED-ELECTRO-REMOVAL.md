# RealmForge Uppercut follow-up fix

- Kept the Uppercut skill and its hit/knockback logic.
- Removed every Uppercut particle spawn and its Photon `baseuppercut` effect resource.
- Fixed player animation application to use per-bone offsets from the first source keyframe, layered on top of the vanilla player pose. This avoids forcing Prime Piece model-space absolute rotations and pivots onto Minecraft's humanoid rig.
- The original Prime Piece animation clip remains included.

Build/runtime status: ZIP integrity and source-level checks only; not compiled or tested in Minecraft. The exact appearance still needs an in-game check because the source animation was authored for a different rig.
