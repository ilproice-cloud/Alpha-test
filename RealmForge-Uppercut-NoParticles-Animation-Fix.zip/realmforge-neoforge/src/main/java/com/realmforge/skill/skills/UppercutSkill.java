package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** A short-range rising punch. Uses the original Prime Piece uppercut player clip. */
public final class UppercutSkill implements SkillDefinition {
   @Override public String id() { return "uppercut"; }
   @Override public String displayName() { return "Uppercut"; }
   @Override public String description() { return "Strike upward with a powerful rising punch, launching one nearby enemy into the air."; }
   @Override public int energyCost() { return 8; }
   @Override public int cooldownTicks() { return 60; }
   @Override public int durationTicks() { return 18; }

   @Override public void execute(SkillContext c) {
      Vec3 forward = c.flatLook();
      c.animate("uppercut");
      c.sound("clothwhoosh", 1.0F, 1.15F);
      c.busy(18);
      c.later(5, () -> {
         LivingEntity target = null;
         double nearest = Double.MAX_VALUE;
         for (LivingEntity candidate : c.cone(3.1, 42.0)) {
            double d = candidate.position().distanceToSqr(c.player.position());
            if (d < nearest) { nearest = d; target = candidate; }
         }
         if (target != null && c.hit(target, 7.0)) {
            c.shove(target, forward, 0.25, 1.05);
            c.soundAt(target.position(), "groundslam", 0.65F, 1.35F);
         }
      });
   }
}
