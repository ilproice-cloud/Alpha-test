# RealmForge Uppercut retained / Electro pack removed

- Replaced the built-in Electro skill pack with an Uppercut-only pack.
- Removed the Electro ServiceLoader registration so the five Electro skills are no longer registered.
- Added an Uppercut skill using the Prime Piece `uppercut.json` player animation and `baseuppercut.fx`.
- Uppercut uses a short-range single-target hit, 7 base skill damage, 8 energy, 60-tick cooldown, and upward knockback.
- Replaced legacy skill migration so old uppercut/punch aliases resolve to Uppercut; Electro IDs no longer resolve to a registered skill.
- Fixed player animation position application to use deterministic model-space offsets instead of accumulating position changes each rendered frame.

This source patch has not yet been compiled or tested in a live Minecraft client.
