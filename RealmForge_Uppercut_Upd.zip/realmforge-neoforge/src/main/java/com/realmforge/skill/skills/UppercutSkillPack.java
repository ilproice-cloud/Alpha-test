package com.realmforge.skill.skills;

import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillPack;
import java.util.function.Consumer;

/** Registers the retained Prime Piece Uppercut move. */
public final class UppercutSkillPack implements SkillPack {
   @Override
   public void register(Consumer<SkillDefinition> registry) {
      registry.accept(new UppercutSkill());
   }
}
