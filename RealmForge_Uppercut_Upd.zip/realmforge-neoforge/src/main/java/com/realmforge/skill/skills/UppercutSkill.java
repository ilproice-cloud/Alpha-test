package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** A short-range rising punch. Uses the original Prime Piece uppercut player clip. */
public final class UppercutSkill implements SkillDefinition {
   @Override public String id() { return "uppercut"; }
   @Override public String displayName() { return "Uppercut"; }
   @Override public String description() { return "Strike upward with a powerful rising punch, launching one nearby enemy into the air."; }
   @Override public int energyCost() { return 8; }
   @Override public int cooldownTicks() { return 60; }
   @Override public int durationTicks() { return 18; }
   @Override public List<String> fxNames() { return List.of("baseuppercut"); }

   @Override public void execute(SkillContext c) {
      Vec3 forward = c.flatLook();
      c.animate("uppercut");
      c.sound("clothwhoosh", 1.0F, 1.15F);
      c.busy(18);
      c.later(5, () -> {
         LivingEntity target = null;
         double nearest = Double.MAX_VALUE;
         for (LivingEntity candidate : c.cone(3.1, 42.0)) {
            double d = candidate.position().distanceToSqr(c.player.position());
            if (d < nearest) { nearest = d; target = candidate; }
         }
         Vec3 impact = c.player.position().add(forward.scale(1.15)).add(0.0, 0.9, 0.0);
         c.level().sendParticles(ParticleTypes.CRIT, impact.x, impact.y, impact.z, 18, 0.28, 0.25, 0.28, 0.18);
         c.level().sendParticles(ParticleTypes.SWEEP_ATTACK, impact.x, impact.y, impact.z, 5, 0.2, 0.2, 0.2, 0.0);
         if (target != null && c.hit(target, 7.0)) {
            c.shove(target, forward, 0.25, 1.05);
            c.level().sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + target.getBbHeight() * 0.55, target.getZ(), 22, 0.35, 0.35, 0.35, 0.2);
            c.soundAt(target.position(), "groundslam", 0.65F, 1.35F);
         }
      });
   }
}
