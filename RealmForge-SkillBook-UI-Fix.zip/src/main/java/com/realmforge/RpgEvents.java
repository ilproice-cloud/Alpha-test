package com.realmforge;

import com.realmforge.addon.data.Clan;
import com.realmforge.addon.logic.BlockingManager;
import com.realmforge.addon.logic.SetBonuses;
import com.realmforge.data.RpgData;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.EquipmentBonuses;
import com.realmforge.logic.StatApplier;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** All gameplay event hooks (the Fabric build used Fabric API callbacks + mixins for these). */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID)
public final class RpgEvents {
   private RpgEvents() {
   }

   @SubscribeEvent
   public static void onCommands(RegisterCommandsEvent event) {
      RpgCommands.register(event.getDispatcher());
   }

   @SubscribeEvent
   public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer p) {
         onJoin(p);
         BlockingManager.sendAllTo(p);
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
      if (event.getEntity() instanceof ServerPlayer p) {
         BlockingManager.set(p, false);
      }
   }

   @SubscribeEvent
   public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
      if (event.getEntity() instanceof ServerPlayer p) {
         RpgData d = RpgManager.get(p);
         d.equip = EquipmentBonuses.compute(p);
         StatApplier.apply(p, d, false);
         if (!event.isEndConquered()) {
            p.setHealth(p.getMaxHealth());
         }

         RpgManager.sync(p, -1);
      }
   }

   /** Fall cancel (Toji set), dodge, then damage scaling (previously a LivingEntity#damage mixin). */
   @SubscribeEvent
   public static void onIncomingDamage(LivingIncomingDamageEvent event) {
      LivingEntity entity = event.getEntity();
      DamageSource source = event.getSource();
      if (entity instanceof Player pl && SetBonuses.cancelsFall(pl, source)) {
         event.setCanceled(true);
         return;
      }

      if (entity instanceof ServerPlayer vp
         && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
         && !(source.getEntity() == null && !source.is(DamageTypeTags.IS_PROJECTILE))) {
         double chance = RpgManager.get(vp).dodge();
         if (chance > 0.0 && ThreadLocalRandom.current().nextDouble() < chance) {
            vp.displayClientMessage(Component.literal("Dodged!").withStyle(ChatFormatting.AQUA), true);
            vp.serverLevel().sendParticles(ParticleTypes.CLOUD, vp.getX(), vp.getY() + 1.0, vp.getZ(), 6, 0.3, 0.4, 0.3, 0.02);
            event.setCanceled(true);
            return;
         }
      }

      event.setAmount(DamagePipeline.modify(entity, source, event.getAmount()));
   }

   @SubscribeEvent
   public static void onDeath(LivingDeathEvent event) {
      LivingEntity entity = event.getEntity();
      if (entity instanceof Player) {
         return;
      }

      if (event.getSource().getEntity() instanceof ServerPlayer p) {
         RpgData d = RpgManager.get(p);
         double base = (double)entity.getMaxHealth() * 0.6;
         base *= entity instanceof Monster ? 1.5 : 0.5;
         d.kills++;
         RpgManager.award(p, d, Math.max(1L, Math.round(base * d.expMult())));
      }
   }

   @SubscribeEvent
   public static void onBlockBreak(BlockEvent.BreakEvent event) {
      if (event.getPlayer() instanceof ServerPlayer p) {
         String path = BuiltInRegistries.BLOCK.getKey(event.getState().getBlock()).getPath();
         long exp = 0L;
         if (path.endsWith("_ore") || path.equals("ancient_debris")) {
            exp = 4L;
         } else if (event.getState().is(BlockTags.LOGS)) {
            exp = 1L;
         }

         if (exp > 0L) {
            RpgData d = RpgManager.get(p);
            RpgManager.award(p, d, Math.max(1L, Math.round((double)exp * d.expMult())));
         }
      }
   }

   @SubscribeEvent
   public static void onServerTick(ServerTickEvent.Post event) {
      MinecraftServer server = event.getServer();
      BlockingManager.tick(server.getPlayerList().getPlayers());
      int t = server.getTickCount();
      if (t % 10 != 0) {
         return;
      }

      for (ServerPlayer p : server.getPlayerList().getPlayers()) {
         RpgData d = RpgManager.get(p);
         if (d.initialized()) {
            int[] eq = EquipmentBonuses.compute(p);
            if (!Arrays.equals(eq, d.equip)) {
               d.equip = eq;
               StatApplier.apply(p, d, false);
            }

            float max = d.maxEnergy();
            if (d.energy < max) {
               d.energy = Math.min(max, d.energy + (float)(d.regenPerSecond() * 0.5));
               d.syncDirty = true;
            } else if (d.energy > max) {
               d.energy = max;
               d.syncDirty = true;
            }

            RpgManager.checkRank(p, d, true);
            if (d.syncDirty) {
               RpgManager.sync(p, -1);
            }

            // fused addon: Toji set bonuses + clan roll
            SetBonuses.update(p, d);
            rollClan(p, d);
         }
      }

      if (t % 200 == 0) {
         RpgManager.state(server).setDirty();
      }
   }

   private static void rollClan(ServerPlayer p, RpgData d) {
      if ((d.clan() == null || d.clan().isEmpty()) && d.rolledLevel() != d.level) {
         d.setRolledLevel(d.level);
         Clan c = Clan.roll(new Random());
         if (c != null) {
            d.setClan(c.id);
            d.syncDirty = true;
            p.displayClientMessage(
               Component.literal("You were born into the " + c.display + " clan! [" + c.rarity.label + "]").withStyle(c.rarity.color, ChatFormatting.BOLD),
               false
            );
         }
      }
   }

   private static void onJoin(ServerPlayer p) {
      RpgData d = RpgManager.get(p);
      boolean fresh = !d.initialized();
      if (fresh) {
         RpgManager.initialize(p, d);
      }

      d.equip = EquipmentBonuses.compute(p);
      StatApplier.apply(p, d, false);
      RpgManager.checkRank(p, d, false);
      RpgManager.sync(p, -1);
      if (fresh) {
         p.displayClientMessage(
            Component.literal("Welcome to RealmForge! Your permanent Trait and Perk have been chosen.").withStyle(ChatFormatting.GOLD), false
         );
         p.displayClientMessage(
            Component.literal("Press K (or /realmforge book) to open your RPG book. Skills: Z X C V.").withStyle(ChatFormatting.YELLOW), false
         );
      }
   }
}
