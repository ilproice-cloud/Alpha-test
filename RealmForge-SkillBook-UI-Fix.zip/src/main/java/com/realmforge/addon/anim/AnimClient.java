package com.realmforge.addon.anim;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;

/**
 * Plays Blockbench-style skill animation clips on player models.
 * Clips are loaded from assets/realmforge/player_animation/<name>.json
 */
public final class AnimClient {
   /** Stable indices kept for network compatibility with AnimPayload (int anim id). */
   public static final String[] FILES = new String[]{
         "rushdownbarrage",   // 0 - Electro Barrage
         "violentthrash",     // 1 - Electro Double Scratch / thrash
         "pawswipetp",        // 2 - scratch / swipe
         "toridash",          // 3 - Dropkick dash
         "twosdash",          // 4 - alt dash
         "dash",              // 5 - generic dash
         "pawdash",           // 6
         "countershock",      // 7 - Electric Field / Fist
         "countershockow",    // 8
         "mirrorkick",        // 9
         "elthorcast",        // 10
         "goroskill2",        // 11
         "kariskill"          // 12
   };

   private static final float[] SPEED;
   static {
      SPEED = new float[FILES.length];
      for (int i = 0; i < SPEED.length; i++) SPEED[i] = 1.0F;
      // slightly faster barrage feel
      SPEED[0] = 1.15F;
      SPEED[1] = 1.1F;
   }

   private static final float[] ROT_SIGN = new float[]{1.0F, 1.0F, 1.0F};
   private static final float[] POS_SIGN = new float[]{1.0F, 1.0F, 1.0F};
   private static final Map<UUID, Active> ACTIVE = new ConcurrentHashMap<>();
   private static final Clip[] CLIPS = new Clip[FILES.length];
   private static final Map<String, Integer> BY_NAME = new HashMap<>();
   private static final String[] BONES = new String[]{"head", "body", "right_arm", "left_arm", "right_leg", "left_leg"};

   static {
      for (int i = 0; i < FILES.length; i++) {
         BY_NAME.put(FILES[i], i);
      }
   }

   private AnimClient() {}

   public static void clear() {
      ACTIVE.clear();
   }

   public static int idOf(String name) {
      Integer i = BY_NAME.get(name);
      return i == null ? -1 : i;
   }

   public static void play(UUID player, int anim) {
      if (anim < 0 || anim >= FILES.length) return;
      Clip clip = CLIPS[anim];
      if (clip == null) {
         clip = Clip.load(FILES[anim]);
         CLIPS[anim] = clip;
      }
      if (clip != null) {
         ACTIVE.put(player, new Active(clip, System.nanoTime(), SPEED[anim]));
      }
   }

   public static void playNamed(UUID player, String name) {
      int id = idOf(name);
      if (id >= 0) play(player, id);
   }

   private static ModelPart part(HumanoidModel<?> m, int i) {
      return switch (i) {
         case 0 -> m.head;
         case 1 -> m.body;
         case 2 -> m.rightArm;
         case 3 -> m.leftArm;
         case 4 -> m.rightLeg;
         default -> m.leftLeg;
      };
   }

   public static void apply(HumanoidModel<?> model, UUID player) {
      if (ACTIVE.isEmpty() || player == null) return;
      Active a = ACTIVE.get(player);
      if (a == null) return;

      float t = (float)(System.nanoTime() - a.start) / 1.0E9F * a.speed;
      if (t > a.clip.length) {
         ACTIVE.remove(player, a);
         return;
      }

      float[] v = new float[3];
      for (int i = 0; i < BONES.length; i++) {
         ModelPart p = part(model, i);
         Clip.Track rot = a.clip.rot.get(BONES[i]);
         if (rot != null) {
            rot.sample(t, v);
            p.xRot = (float)Math.toRadians((double)(v[0] * ROT_SIGN[0]));
            p.yRot = (float)Math.toRadians((double)(v[1] * ROT_SIGN[1]));
            p.zRot = (float)Math.toRadians((double)(v[2] * ROT_SIGN[2]));
         }
         Clip.Track pos = a.clip.pos.get(BONES[i]);
         if (pos != null) {
            pos.sample(t, v);
            p.x += v[0] * POS_SIGN[0];
            p.y += v[1] * POS_SIGN[1];
            p.z += v[2] * POS_SIGN[2];
         }
      }
   }

   private static final class Active {
      final Clip clip;
      final long start;
      final float speed;
      Active(Clip clip, long start, float speed) {
         this.clip = clip;
         this.start = start;
         this.speed = speed;
      }
   }
}
