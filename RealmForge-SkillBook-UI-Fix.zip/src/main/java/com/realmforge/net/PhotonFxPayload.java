package com.realmforge.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client: play a Photon FX attached to an entity.
 * fxPath is the short effect name (e.g. "kaidolightning"); Photon maps it to
 * assets/&lt;ns&gt;/fx/&lt;name&gt;.fx via FXHelper.
 */
public record PhotonFxPayload(UUID entityId, String fxPath, int autoRotate) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<PhotonFxPayload> TYPE =
            new CustomPacketPayload.Type<>(RealmForgeMod.id("photon_fx"));

    public static final StreamCodec<ByteBuf, PhotonFxPayload> CODEC = StreamCodec.composite(
            UUIDUtil.STREAM_CODEC, PhotonFxPayload::entityId,
            ByteBufCodecs.STRING_UTF8, PhotonFxPayload::fxPath,
            ByteBufCodecs.VAR_INT, PhotonFxPayload::autoRotate,
            PhotonFxPayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public ResourceLocation fxLocation() {
        String name = fxPath;
        if (name.startsWith("fx/")) name = name.substring(3);
        if (name.endsWith(".fx")) name = name.substring(0, name.length() - 3);
        if (name.contains(":")) {
            return ResourceLocation.parse(name);
        }
        return RealmForgeMod.id(name);
    }
}
