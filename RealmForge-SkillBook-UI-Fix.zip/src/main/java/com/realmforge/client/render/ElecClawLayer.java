package com.realmforge.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.realmforge.RealmForgeMod;
import com.realmforge.client.ClawClient;
import com.realmforge.client.model.ElecClawModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Renders electrified claws on the player's arms while ClawClient marks them visible.
 */
public class ElecClawLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation TEXTURE = RealmForgeMod.id("textures/entity/elecclaw.png");
    private final ElecClawModel<AbstractClientPlayer> model;

    public ElecClawLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
        super(parent);
        this.model = new ElecClawModel<>(models.bakeLayer(ElecClawModel.LAYER));
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                       AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!ClawClient.isVisible(player.getUUID())) return;

        PlayerModel<AbstractClientPlayer> playerModel = this.getParentModel();
        // copy arm poses so claws follow the animated arms
        this.model.rightClaw().copyFrom(playerModel.rightArm);
        this.model.leftClaw().copyFrom(playerModel.leftArm);

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        this.model.renderToBuffer(poseStack, vc, packedLight, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
    }
}
