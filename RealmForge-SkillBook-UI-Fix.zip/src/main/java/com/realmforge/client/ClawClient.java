package com.realmforge.client;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Tracks temporary claw overlay visibility per player (client-side). */
public final class ClawClient {
    private static final Map<UUID, Long> UNTIL = new ConcurrentHashMap<>();

    private ClawClient() {}

    public static void show(UUID player, int ticks) {
        long until = System.currentTimeMillis() + ticks * 50L;
        UNTIL.put(player, until);
    }

    public static boolean isVisible(UUID player) {
        Long until = UNTIL.get(player);
        if (until == null) return false;
        if (System.currentTimeMillis() > until) {
            UNTIL.remove(player, until);
            return false;
        }
        return true;
    }

    public static void clear() {
        UNTIL.clear();
    }
}
