package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/**
 * Client-only bridge to Photon's FX API via reflection so the mod compiles
 * even when Photon is not on the compile classpath. At runtime, Photon must
 * be installed for effects to play.
 */
public final class PhotonFxClient {
    private static final boolean PHOTON_PRESENT;
    private static final Method GET_FX;
    private static final Method GET_FX_BOOL;
    private static final Constructor<?> EXEC_CTOR;
    private static final Method SET_ALLOW_MULTI;
    private static final Method START;
    private static final Object[] AUTO_ROTATE_VALUES;

    static {
        boolean present = false;
        Method getFx = null, getFxBool = null, setAllow = null, start = null;
        Constructor<?> ctor = null;
        Object[] rotVals = new Object[0];
        try {
            Class<?> fxHelper = Class.forName("com.lowdragmc.photon.client.fx.FXHelper");
            Class<?> fxClass = Class.forName("com.lowdragmc.photon.client.fx.FX");
            Class<?> execClass = Class.forName("com.lowdragmc.photon.client.fx.EntityEffectExecutor");
            Class<?> rotClass = Class.forName("com.lowdragmc.photon.client.fx.EntityEffectExecutor$AutoRotate");
            getFx = fxHelper.getMethod("getFX", ResourceLocation.class);
            try {
                getFxBool = fxHelper.getMethod("getFX", ResourceLocation.class, boolean.class);
            } catch (NoSuchMethodException ignored) {}
            ctor = execClass.getConstructor(fxClass, Level.class, Entity.class, rotClass);
            setAllow = execClass.getMethod("setAllowMulti", boolean.class);
            start = execClass.getMethod("start");
            rotVals = rotClass.getEnumConstants();
            present = true;
        } catch (Throwable t) {
            RealmForgeMod.LOGGER.info("Photon not present — skill FX will be skipped ({})", t.toString());
        }
        PHOTON_PRESENT = present;
        GET_FX = getFx;
        GET_FX_BOOL = getFxBool;
        EXEC_CTOR = ctor;
        SET_ALLOW_MULTI = setAllow;
        START = start;
        AUTO_ROTATE_VALUES = rotVals;
    }

    private PhotonFxClient() {}

    public static void playOnEntity(Entity entity, ResourceLocation fxLoc, int autoRotateOrdinal) {
        if (!PHOTON_PRESENT || entity == null || fxLoc == null) return;
        Level level = entity.level();
        if (level == null || !level.isClientSide) return;

        try {
            Object fx = GET_FX.invoke(null, fxLoc);
            if (fx == null && GET_FX_BOOL != null) {
                fx = GET_FX_BOOL.invoke(null, fxLoc, true);
            }
            if (fx == null) {
                RealmForgeMod.LOGGER.warn("Photon FX not found: {}", fxLoc);
                return;
            }
            Object rot = AUTO_ROTATE_VALUES.length > 0 ? AUTO_ROTATE_VALUES[0] : null;
            if (autoRotateOrdinal >= 0 && autoRotateOrdinal < AUTO_ROTATE_VALUES.length) {
                rot = AUTO_ROTATE_VALUES[autoRotateOrdinal];
            }
            Object exec = EXEC_CTOR.newInstance(fx, level, entity, rot);
            SET_ALLOW_MULTI.invoke(exec, true);
            START.invoke(exec);
        } catch (Throwable t) {
            RealmForgeMod.LOGGER.warn("Failed to play Photon FX {}: {}", fxLoc, t.toString());
        }
    }

    public static void playByUuid(UUID entityId, ResourceLocation fxLoc, int autoRotate) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || entityId == null) return;
        Entity e = null;
        for (Entity ent : mc.level.entitiesForRendering()) {
            if (entityId.equals(ent.getUUID())) {
                e = ent;
                break;
            }
        }
        if (e == null && mc.player != null && entityId.equals(mc.player.getUUID())) {
            e = mc.player;
        }
        playOnEntity(e, fxLoc, autoRotate);
    }
}
