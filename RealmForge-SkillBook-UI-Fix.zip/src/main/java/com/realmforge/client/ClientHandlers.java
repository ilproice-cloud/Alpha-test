package com.realmforge.client;

import com.realmforge.addon.anim.AnimPayload;
import com.realmforge.addon.net.BlockStatePayload;
import com.realmforge.net.PhotonFxPayload;
import com.realmforge.net.SyncPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client-side payload handlers. Kept thin: real work is in client-only classes loaded lazily. */
public final class ClientHandlers {
   private ClientHandlers() {
   }

   public static void onSync(SyncPayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> ClientActions.sync(payload.snbt(), payload.openPage()));
   }

   public static void onAnim(AnimPayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> {
         com.realmforge.addon.anim.AnimClient.play(payload.player(), payload.anim());
         // Show claw overlay for scratch / fist style anims
         int a = payload.anim();
         if (a == 1 || a == 2 || a == 7 || a == 8) {
            ClawClient.show(payload.player(), 25);
         }
      });
   }

   public static void onBlockState(BlockStatePayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> com.realmforge.addon.client.BlockingClient.set(payload.player(), payload.active()));
   }

   public static void onPhotonFx(PhotonFxPayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> PhotonFxClient.playByUuid(
            payload.entityId(),
            payload.fxLocation(),
            payload.autoRotate()
      ));
   }
}
