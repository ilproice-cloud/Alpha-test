package com.realmforge.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.realmforge.RealmForgeMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.entity.Entity;

/**
 * Electrified claw overlay model adapted from the original Modelelecclaw
 * (trueprimepiecetwo). Attaches to player arms for Electro Fist / Double Scratch.
 */
public class ElecClawModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(RealmForgeMod.id("elec_claw"), "main");

    private final ModelPart rightClaw;
    private final ModelPart leftClaw;

    public ElecClawModel(ModelPart root) {
        this.rightClaw = root.getChild("right_claw");
        this.leftClaw = root.getChild("left_claw");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Right hand claws (relative to right arm pose applied externally)
        PartDefinition right = root.addOrReplaceChild("right_claw",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-2.0F, 8.0F, -1.5F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.1F))
                        .texOffs(4, 0).addBox(-0.5F, 8.5F, -1.8F, 1.0F, 5.5F, 1.0F, new CubeDeformation(0.1F))
                        .texOffs(8, 0).addBox(1.0F, 8.0F, -1.5F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.1F)),
                PartPose.offset(-5.0F, 2.0F, 0.0F));

        // Left hand claws
        root.addOrReplaceChild("left_claw",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-2.0F, 8.0F, -1.5F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.1F))
                        .texOffs(4, 0).addBox(-0.5F, 8.5F, -1.8F, 1.0F, 5.5F, 1.0F, new CubeDeformation(0.1F))
                        .texOffs(8, 0).addBox(1.0F, 8.0F, -1.5F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.1F)),
                PartPose.offset(5.0F, 2.0F, 0.0F));

        return LayerDefinition.create(mesh, 16, 16);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        // poses applied from player model in the render layer
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        rightClaw.render(poseStack, buffer, packedLight, packedOverlay, color);
        leftClaw.render(poseStack, buffer, packedLight, packedOverlay, color);
    }

    public ModelPart rightClaw() { return rightClaw; }
    public ModelPart leftClaw() { return leftClaw; }
}
