package com.realmforge.data;

import java.util.Locale;

/**
 * Legacy enum kept for backward compatibility with existing save data and
 * older UI code. New skills live in SkillRegistry / SkillDefinition.
 */
public enum Skill {
   STRONG_PUNCH("Electro Barrage", "Rapid electrified strikes in a cone in front of you. Hotkey: Z", 1, 15, 80, Stat.STR),
   UPPERCUT("Electro Dropkick", "A charged flying dropkick that blasts targets away. Hotkey: X", 1, 22, 120, Stat.STR),
   BARRAGE("Electro Double Scratch", "Two fast electric claw swipes that hit a cone and knock enemies back. Hotkey: C", 1, 12, 60, Stat.STR);

   public static final int SLOTS = 3;
   public final String label;
   public final String desc;
   public final int unlockLevel;
   public final int energyCost;
   public final int cooldownTicks;
   public final Stat stat;

   private Skill(String label, String desc, int unlockLevel, int energyCost, int cooldownTicks, Stat stat) {
      this.label = label;
      this.desc = desc;
      this.unlockLevel = unlockLevel;
      this.energyCost = energyCost;
      this.cooldownTicks = cooldownTicks;
      this.stat = stat;
   }

   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   /** Maps legacy ids to the new SkillRegistry ids. */
   public String modernId() {
      return switch (this) {
         case STRONG_PUNCH -> "electro_barrage";
         case UPPERCUT -> "electro_dropkick";
         case BARRAGE -> "electro_double_scratch";
      };
   }

   public static Skill byId(String id) {
      if (id == null) {
         return null;
      } else {
         for (Skill s : values()) {
            if (s.id().equalsIgnoreCase(id) || s.modernId().equalsIgnoreCase(id)) {
               return s;
            }
         }

         String var5 = id.toLowerCase(Locale.ROOT);

         return switch (var5) {
            case "power_strike", "electro_barrage" -> STRONG_PUNCH;
            case "dash", "electro_dropkick" -> UPPERCUT;
            case "arcane_bolt", "mend", "electro_double_scratch" -> BARRAGE;
            default -> null;
         };
      }
   }
}
