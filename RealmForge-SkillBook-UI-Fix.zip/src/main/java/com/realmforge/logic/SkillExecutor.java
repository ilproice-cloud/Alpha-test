package com.realmforge.logic;

import com.realmforge.data.RpgData;
import com.realmforge.RpgManager;
import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillRegistry;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Universal skill execution. Looks up the skill assigned to the given slot
 * from player data and delegates to the registered SkillDefinition.
 * Never hardcodes individual skills.
 */
public final class SkillExecutor {
    private SkillExecutor() {}

    public static void use(ServerPlayer player, int slot) {
        if (slot < 0 || slot > 2) return;

        RpgData data = RpgManager.get(player);
        if (data == null) return;

        String skillId = data.getSlotSkill(slot);
        if (skillId == null || skillId.isEmpty()) {
            player.displayClientMessage(Component.literal("No skill equipped in that slot."), true);
            return;
        }

        SkillDefinition skill = SkillRegistry.get(skillId);
        if (skill == null) {
            player.displayClientMessage(Component.literal("Unknown skill: " + skillId), true);
            return;
        }

        if (!skill.isUnlocked(data)) {
            player.displayClientMessage(Component.literal("Skill not unlocked."), true);
            return;
        }

        long now = player.level().getGameTime();
        if (data.isOnCooldown(skillId, now)) {
            long remain = data.cooldownRemaining(skillId, now);
            player.displayClientMessage(Component.literal("Skill on cooldown (" + (remain / 20) + "s)"), true);
            return;
        }

        int cost = skill.energyCost();
        if (data.energy < cost) {
            player.displayClientMessage(Component.literal("Not enough energy."), true);
            return;
        }

        data.energy -= cost;
        data.startCooldown(skillId, skill.cooldownTicks(), now);
        data.markDirty();

        skill.execute(player, data);

        RpgManager.sync(player, -1);
    }
}
