package com.realmforge.logic;

import com.realmforge.net.PhotonFxPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/** Server-side helper to broadcast Photon FX to tracking clients. */
public final class PhotonFxNet {
    private PhotonFxNet() {}

    /**
     * @param fxName short name under assets/realmforge/fx/ (without .fx), e.g. "kaidolightning"
     * @param autoRotate ordinal of EntityEffectExecutor.AutoRotate (0=NONE, 1=FORWARD, 2=LOOK, 3=XROT)
     */
    public static void broadcast(ServerPlayer player, String fxName, int autoRotate) {
        if (player == null || fxName == null || fxName.isEmpty()) return;
        String name = fxName;
        if (name.startsWith("fx/")) name = name.substring(3);
        if (name.endsWith(".fx")) name = name.substring(0, name.length() - 3);
        PhotonFxPayload payload = new PhotonFxPayload(player.getUUID(), name, autoRotate);
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, payload);
    }

    public static void broadcast(ServerPlayer player, String fxName) {
        broadcast(player, fxName, 0);
    }
}
