package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.PhotonFxNet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Electro Fist — heavy electrified strike with claw overlay + countershock / impact FX.
 */
public final class ElectroFistSkill implements SkillDefinition {
    public static final String ID = "electro_fist";
    private static final ElectroFistSkill INSTANCE = new ElectroFistSkill();
    static { SkillRegistry.register(INSTANCE); }
    public static void init() {}
    private ElectroFistSkill() {}

    @Override public String id() { return ID; }
    @Override public String label() { return "Electro Fist"; }
    @Override public String description() {
        return "A heavy electrified fist strike that stuns and deals high single-target damage.";
    }
    @Override public int energyCost() { return 25; }
    @Override public int cooldownTicks() { return 100; }
    @Override public boolean isUnlocked(RpgData data) { return data.isSkillUnlocked(ID); }

    @Override
    public void execute(ServerPlayer player, RpgData data) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        Vec3 origin = player.getEyePosition();

        AnimNet.broadcast(player, 7); // countershock (shows claws)
        PhotonFxNet.broadcast(player, "countershock", 2);
        PhotonFxNet.broadcast(player, "bigimpact", 0);
        PhotonFxNet.broadcast(player, "hakishock", 0);

        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT,
                SoundSource.PLAYERS, 1.0f, 0.7f);
        level.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT,
                SoundSource.PLAYERS, 0.75f, 1.0f);

        float baseDmg = 11.0f + data.stat(Stat.STR) * 0.7f;
        double range = 3.2;

        for (int i = 0; i < 14; i++) {
            Vec3 p = origin.add(look.scale(i * 0.22));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 3, 0.08, 0.08, 0.08, 0.02);
            level.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.01);
        }

        AABB box = player.getBoundingBox().expandTowards(look.scale(range)).inflate(0.9);
        LivingEntity closest = null;
        double closestDist = range + 0.5;
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
            double d = player.distanceTo(target);
            if (d < closestDist) {
                closestDist = d;
                closest = target;
            }
        }

        if (closest != null) {
            DamagePipeline.dealSkillDamage(player, closest, baseDmg, data);
            closest.knockback(0.9, -look.x, -look.z);
            closest.setDeltaMovement(closest.getDeltaMovement().add(0, 0.35, 0).multiply(0.2, 1.0, 0.2));

            level.sendParticles(ParticleTypes.FLASH,
                    closest.getX(), closest.getY() + closest.getBbHeight() * 0.5, closest.getZ(),
                    1, 0, 0, 0, 0);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    closest.getX(), closest.getY() + 0.8, closest.getZ(),
                    30, 0.4, 0.5, 0.4, 0.15);
            level.sendParticles(ParticleTypes.EXPLOSION,
                    closest.getX(), closest.getY() + 0.6, closest.getZ(),
                    1, 0, 0, 0, 0);
        }
    }
}
