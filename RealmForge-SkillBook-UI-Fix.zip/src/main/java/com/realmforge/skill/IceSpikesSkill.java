package com.realmforge.skill;

import com.realmforge.data.RpgData;
import net.minecraft.server.level.ServerPlayer;

/**
 * Legacy stub kept so any remaining call sites compile.
 * All real skill logic lives in SkillRegistry implementations.
 */
public final class IceSpikesSkill {
   private IceSpikesSkill() {}

   public static void handle(ServerPlayer player, int slot) {
      // no-op; SkillExecutor now routes through SkillRegistry
   }

   public static boolean isUnlocked(RpgData data) {
      return false;
   }

   public static int boundSlot(RpgData data) {
      return 0;
   }

   public static double damage(RpgData data) {
      return 0.0;
   }
}
