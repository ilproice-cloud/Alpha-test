package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.PhotonFxNet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Electro Barrage — rapid electrified strikes (rushdownbarrage + kaidolightning FX). */
public final class ElectroBarrageSkill implements SkillDefinition {
    public static final String ID = "electro_barrage";
    private static final ElectroBarrageSkill INSTANCE = new ElectroBarrageSkill();
    static { SkillRegistry.register(INSTANCE); }
    public static void init() {}
    private ElectroBarrageSkill() {}

    @Override public String id() { return ID; }
    @Override public String label() { return "Electro Barrage"; }
    @Override public String description() {
        return "Rapid electrified strikes in a cone in front of you.";
    }
    @Override public int energyCost() { return 15; }
    @Override public int cooldownTicks() { return 80; }
    @Override public boolean isUnlocked(RpgData data) { return data.isSkillUnlocked(ID); }

    @Override
    public void execute(ServerPlayer player, RpgData data) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        Vec3 origin = player.getEyePosition();

        AnimNet.broadcast(player, 0); // rushdownbarrage
        PhotonFxNet.broadcast(player, "kaidolightning", 2); // LOOK
        PhotonFxNet.broadcast(player, "enelburst", 0);

        level.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER,
                SoundSource.PLAYERS, 0.45f, 1.55f);
        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP,
                SoundSource.PLAYERS, 0.9f, 1.3f);

        double range = 4.5;
        double coneCos = Math.cos(Math.toRadians(50));
        float baseDmg = 4.0f + data.stat(Stat.STR) * 0.35f;

        AABB box = player.getBoundingBox().inflate(range);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
            Vec3 to = target.getEyePosition().subtract(origin).normalize();
            if (look.dot(to) >= coneCos && origin.distanceTo(target.position()) <= range) {
                DamagePipeline.dealSkillDamage(player, target, baseDmg, data);
                target.knockback(0.25, -look.x, -look.z);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        target.getX(), target.getY() + target.getBbHeight() * 0.6, target.getZ(),
                        14, 0.3, 0.4, 0.3, 0.08);
            }
        }

        for (int i = 0; i < 18; i++) {
            double t = i / 18.0;
            Vec3 p = origin.add(look.scale(t * range));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 0.15, 0.15, 0.15, 0.02);
        }
    }
}
