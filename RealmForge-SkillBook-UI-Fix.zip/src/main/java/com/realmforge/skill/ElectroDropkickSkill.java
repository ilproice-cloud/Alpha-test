package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.PhotonFxNet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Electro Dropkick — flying dropkick (toridash + dash trails + impact FX). */
public final class ElectroDropkickSkill implements SkillDefinition {
    public static final String ID = "electro_dropkick";
    private static final ElectroDropkickSkill INSTANCE = new ElectroDropkickSkill();
    static { SkillRegistry.register(INSTANCE); }
    public static void init() {}
    private ElectroDropkickSkill() {}

    @Override public String id() { return ID; }
    @Override public String label() { return "Electro Dropkick"; }
    @Override public String description() {
        return "A charged flying dropkick that blasts targets away.";
    }
    @Override public int energyCost() { return 22; }
    @Override public int cooldownTicks() { return 120; }
    @Override public boolean isUnlocked(RpgData data) { return data.isSkillUnlocked(ID); }

    @Override
    public void execute(ServerPlayer player, RpgData data) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();

        AnimNet.broadcast(player, 3); // toridash
        PhotonFxNet.broadcast(player, "toridashwhoo", 1); // FORWARD
        PhotonFxNet.broadcast(player, "gorodash", 1);
        PhotonFxNet.broadcast(player, "groundedimpact", 0);

        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG,
                SoundSource.PLAYERS, 1.0f, 0.8f);
        level.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT,
                SoundSource.PLAYERS, 0.55f, 1.35f);

        Vec3 boost = look.scale(1.65).add(0, 0.38, 0);
        player.setDeltaMovement(boost);
        player.hurtMarked = true;

        float baseDmg = 8.0f + data.stat(Stat.STR) * 0.55f;
        AABB box = player.getBoundingBox().expandTowards(look.scale(3.5)).inflate(1.2);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
            DamagePipeline.dealSkillDamage(player, target, baseDmg, data);
            target.knockback(1.1, -look.x, -look.z);
            target.setDeltaMovement(target.getDeltaMovement().add(look.scale(0.9).add(0, 0.45, 0)));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    target.getX(), target.getY() + 0.8, target.getZ(),
                    28, 0.4, 0.5, 0.4, 0.12);
            level.sendParticles(ParticleTypes.FLASH,
                    target.getX(), target.getY() + 0.6, target.getZ(), 1, 0, 0, 0, 0);
        }

        for (int i = 0; i < 12; i++) {
            Vec3 p = player.position().add(look.scale(i * 0.3)).add(0, 0.6, 0);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 3, 0.1, 0.1, 0.1, 0.03);
        }
    }
}
