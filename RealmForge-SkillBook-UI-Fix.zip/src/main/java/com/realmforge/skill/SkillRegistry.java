package com.realmforge.skill;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Central registry for all skills. Skills register themselves at class-load
 * or via a static block. Adding a new skill never requires changing the
 * executor or the menu logic.
 */
public final class SkillRegistry {
    private static final Map<String, SkillDefinition> SKILLS = new LinkedHashMap<>();

    private SkillRegistry() {}

    public static void register(SkillDefinition skill) {
        if (skill == null || skill.id() == null || skill.id().isEmpty()) {
            throw new IllegalArgumentException("Skill must have a non-empty id");
        }
        String id = skill.id().toLowerCase();
        if (SKILLS.containsKey(id)) {
            throw new IllegalStateException("Duplicate skill id: " + id);
        }
        SKILLS.put(id, skill);
    }

    public static SkillDefinition get(String id) {
        if (id == null) return null;
        return SKILLS.get(id.toLowerCase());
    }

    public static Collection<SkillDefinition> all() {
        return Collections.unmodifiableCollection(SKILLS.values());
    }

    public static boolean exists(String id) {
        return id != null && SKILLS.containsKey(id.toLowerCase());
    }

    /** Called once during mod init to force-load skill classes so they register. */
    public static void bootstrap() {
        // Force class loading so static blocks run
        ElectroBarrageSkill.init();
        ElectroDropkickSkill.init();
        ElectroDoubleScratchSkill.init();
        ElectricFieldSkill.init();
        ElectroFistSkill.init();
    }
}
