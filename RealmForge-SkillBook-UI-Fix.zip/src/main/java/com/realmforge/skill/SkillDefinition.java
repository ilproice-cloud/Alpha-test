package com.realmforge.skill;

import com.realmforge.data.RpgData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Universal skill definition. New skills implement this and register themselves
 * with SkillRegistry. The central executor never hardcodes individual skills.
 */
public interface SkillDefinition {
    /** Unique id used in save data and slots (lowercase, no spaces). */
    String id();

    /** Display name shown in the skill menu. */
    String label();

    /** Short description shown in the skill menu. */
    String description();

    /** Energy cost to use. */
    int energyCost();

    /** Cooldown in ticks. */
    int cooldownTicks();

    /** Whether this skill is unlocked for the given player data. */
    boolean isUnlocked(RpgData data);

    /** Called on the server when the player activates the skill. */
    void execute(ServerPlayer player, RpgData data);

    /** Optional client-side preview or first-person FX. Default no-op. */
    default void clientPredict(Player player) {}
}
