package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.PhotonFxNet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Electric Field — pulsing field (countershock anim + countershock / bigexplode FX). */
public final class ElectricFieldSkill implements SkillDefinition {
    public static final String ID = "electric_field";
    private static final ElectricFieldSkill INSTANCE = new ElectricFieldSkill();
    static { SkillRegistry.register(INSTANCE); }
    public static void init() {}
    private ElectricFieldSkill() {}

    @Override public String id() { return ID; }
    @Override public String label() { return "Electric Field"; }
    @Override public String description() {
        return "Unleash a pulsing electric field that damages and slows nearby enemies.";
    }
    @Override public int energyCost() { return 28; }
    @Override public int cooldownTicks() { return 160; }
    @Override public boolean isUnlocked(RpgData data) { return data.isSkillUnlocked(ID); }

    @Override
    public void execute(ServerPlayer player, RpgData data) {
        ServerLevel level = player.serverLevel();

        AnimNet.broadcast(player, 7); // countershock
        PhotonFxNet.broadcast(player, "countershock", 0);
        PhotonFxNet.broadcast(player, "bigexplode", 0);
        PhotonFxNet.broadcast(player, "gurashocks", 0);

        level.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER,
                SoundSource.PLAYERS, 0.65f, 1.05f);
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE,
                SoundSource.PLAYERS, 0.5f, 1.8f);

        float baseDmg = 3.5f + data.stat(Stat.STR) * 0.25f + data.stat(Stat.INT) * 0.2f;
        double radius = 5.5;

        for (int i = 0; i < 48; i++) {
            double a = (i / 48.0) * Math.PI * 2;
            double x = player.getX() + Math.cos(a) * radius;
            double z = player.getZ() + Math.sin(a) * radius;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, player.getY() + 0.2, z, 2, 0.05, 0.3, 0.05, 0.02);
            level.sendParticles(ParticleTypes.END_ROD, x, player.getY() + 0.1, z, 1, 0, 0.1, 0, 0.01);
        }

        level.sendParticles(ParticleTypes.FLASH, player.getX(), player.getY() + 1.0, player.getZ(), 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                player.getX(), player.getY() + 0.8, player.getZ(),
                40, 1.5, 1.0, 1.5, 0.15);

        AABB box = player.getBoundingBox().inflate(radius);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
            if (player.distanceTo(target) <= radius) {
                DamagePipeline.dealSkillDamage(player, target, baseDmg, data);
                Vec3 away = target.position().subtract(player.position()).normalize().scale(0.4).add(0, 0.25, 0);
                target.setDeltaMovement(target.getDeltaMovement().add(away));
                target.hurtMarked = true;
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        target.getX(), target.getY() + 0.7, target.getZ(),
                        10, 0.25, 0.3, 0.25, 0.05);
            }
        }
    }
}
