package com.realmforge;

import com.realmforge.addon.item.TojiItems;
import com.realmforge.addon.item.WeaponItems;
import com.realmforge.addon.logic.SkillManager;
import com.realmforge.addon.net.SkillAssignPayload;
import com.realmforge.addon.net.SkillEffectPayload;
import com.realmforge.addon.net.SkillUsePayload;
import com.realmforge.addon.net.QuestBoardOpenPayload;
import com.realmforge.addon.net.QuestAcceptPayload;
import com.realmforge.addon.net.QuestClaimPayload;
import com.realmforge.addon.entity.VfxEntities;
import com.realmforge.addon.quest.QuestBlocks;
import com.realmforge.addon.quest.QuestManager;
import com.realmforge.addon.skill.SkillParticles;
import com.realmforge.addon.skill.SkillSounds;
import com.realmforge.addon.logic.BlockingManager;
import com.realmforge.addon.net.BlockPayload;
import com.realmforge.addon.net.BlockStatePayload;
import com.realmforge.data.Perk;
import com.realmforge.data.Rarity;
import com.realmforge.data.Trait;
import com.realmforge.net.SyncPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(RealmForgeMod.MOD_ID)
public class RealmForgeMod {
   public static final String MOD_ID = "realmforge";
   public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

   public RealmForgeMod(IEventBus modBus) {
      Rarity.validate(Trait.values(), "Trait");
      Rarity.validate(Perk.values(), "Perk");
      TojiItems.ARMOR_MATERIALS.register(modBus);
      TojiItems.ITEMS.register(modBus);
      WeaponItems.ITEMS.register(modBus);
      SkillSounds.SOUNDS.register(modBus);
      SkillParticles.PARTICLES.register(modBus);
      QuestBlocks.BLOCKS.register(modBus);
      QuestBlocks.ITEMS.register(modBus);
      QuestBlocks.BLOCK_ENTITIES.register(modBus);
      VfxEntities.ENTITIES.register(modBus);
      VfxEntities.ITEMS.register(modBus);
      LOGGER.info("RealmForge loaded.");
   }

   public static ResourceLocation id(String path) {
      return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
   }

   @EventBusSubscriber(modid = MOD_ID, bus = EventBusSubscriber.Bus.MOD)
   public static final class ModEvents {
      private ModEvents() {}

      @SubscribeEvent
      public static void registerPayloads(RegisterPayloadHandlersEvent event) {
         PayloadRegistrar r = event.registrar("1");
         r.playToClient(SyncPayload.TYPE, SyncPayload.CODEC, com.realmforge.client.ClientHandlers::onSync);
         r.playToClient(BlockStatePayload.TYPE, BlockStatePayload.CODEC, com.realmforge.client.ClientHandlers::onBlockState);
         r.playToClient(SkillEffectPayload.TYPE, SkillEffectPayload.CODEC, com.realmforge.client.ClientHandlers::onSkillEffect);
         r.playToClient(QuestBoardOpenPayload.TYPE, QuestBoardOpenPayload.CODEC, com.realmforge.client.ClientHandlers::onQuestBoardOpen);
         r.playToServer(QuestClaimPayload.TYPE, QuestClaimPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
               QuestManager.claim(sp);
            }
         }));
         r.playToServer(QuestAcceptPayload.TYPE, QuestAcceptPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
               QuestManager.accept(sp, payload.pos());
            }
         }));
         r.playToServer(SkillUsePayload.TYPE, SkillUsePayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
               SkillManager.use(sp, payload.slot());
            }
         }));
         r.playToServer(SkillAssignPayload.TYPE, SkillAssignPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
               SkillManager.assign(sp, payload.slot(), payload.skill(), payload.page());
            }
         }));
         r.playToServer(BlockPayload.TYPE, BlockPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
               BlockingManager.set(sp, payload.active());
            }
         }));
      }

      @SubscribeEvent
      public static void creativeTabs(BuildCreativeModeTabContentsEvent event) {
         if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(QuestBlocks.QUEST_BOARD_ITEM.get());
         }

         if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(VfxEntities.BARRAGE_EGG.get());
            event.accept(VfxEntities.HEAVY_PUNCH_EGG.get());
            event.accept(VfxEntities.UPPERCUT_EGG.get());
         }

         if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(TojiItems.SHIRT.get());
            event.accept(TojiItems.PANTS.get());
            event.accept(TojiItems.BOOTS.get());
            event.accept(TojiItems.CLOTH.get());
            event.accept(WeaponItems.SLAUGHTER_DEMON.get());
         }
      }
   }
}
