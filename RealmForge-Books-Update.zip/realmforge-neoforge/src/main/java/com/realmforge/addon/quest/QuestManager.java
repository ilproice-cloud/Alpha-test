package com.realmforge.addon.quest;

import com.realmforge.RealmForgeMod;
import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;

/**
 * Server logic for the Quest Board's single quest: mine {@link QuestBoardInfo#TARGET} iron ore, claim
 * {@link QuestBoardInfo#REWARD_EXP} EXP. Progress lives in the player's RpgData. The quest resets for everyone every
 * {@link QuestBoardInfo#REFRESH_TICKS} ticks of world time (the player's saved epoch no longer matches the current one).
 */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID)
public final class QuestManager {
   private static final TagKey<Block> IRON_ORES = TagKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath("c", "ores/iron"));

   private QuestManager() {
   }

   private static boolean isIronOre(BlockState s) {
      return s.is(Blocks.IRON_ORE) || s.is(Blocks.DEEPSLATE_IRON_ORE) || s.is(IRON_ORES);
   }

   /** Applies the 2-minute reset if it is due. Returns true if the quest was reset. */
   private static boolean normalize(ServerPlayer p, RpgData d) {
      long epoch = QuestBoardInfo.epoch(p.serverLevel().getGameTime());
      if (d.questEpoch == epoch) {
         return false;
      }

      // a new 2-minute window: the old quest is removed and has to be taken from the board again
      d.questEpoch = epoch;
      d.questProgress = 0;
      d.questClaimed = false;
      d.questAccepted = false;
      d.syncDirty = true;
      return true;
   }

   /** Called when a player opens the board: reset if due, then send fresh data. */
   public static void refresh(ServerPlayer p) {
      RpgData d = RpgManager.get(p);
      normalize(p, d);
      RpgManager.sync(p, -1);
   }

   /** The quest was pressed on the board at {@code boardPos}: take it. */
   public static void accept(ServerPlayer p, BlockPos boardPos) {
      // must actually be standing at a Quest Board
      if (!p.serverLevel().getBlockState(boardPos).is(QuestBlocks.QUEST_BOARD.get()) || p.distanceToSqr(boardPos.getCenter()) > 64.0) {
         return;
      }

      RpgData d = RpgManager.get(p);
      normalize(p, d);
      if (d.questClaimed) {
         p.displayClientMessage(Component.literal("You already completed this quest. A new one is posted when the board refreshes.").withStyle(ChatFormatting.RED), true);
      } else if (d.questAccepted) {
         p.displayClientMessage(Component.literal("You already took this quest. Check your Quest Book (N).").withStyle(ChatFormatting.YELLOW), true);
      } else {
         d.questAccepted = true;
         d.questProgress = 0;
         d.syncDirty = true;
         p.displayClientMessage(Component.literal("Quest taken: " + QuestBoardInfo.TITLE + ". Track it in your Quest Book (N).").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), false);
         p.playNotifySound(SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0F, 1.0F);
      }

      RpgManager.sync(p, -1);
   }

   @SubscribeEvent(priority = EventPriority.LOWEST)
   public static void onBreak(BlockEvent.BreakEvent event) {
      if (event.isCanceled() || !(event.getPlayer() instanceof ServerPlayer sp) || sp.isCreative() || sp.isSpectator()) {
         return;
      }

      if (!isIronOre(event.getState())) {
         return;
      }

      RpgData d = RpgManager.get(sp);
      normalize(sp, d);
      if (!d.questAccepted || d.questClaimed || d.questProgress >= QuestBoardInfo.TARGET) {
         return; // progress only counts once the quest was taken from the board
      }

      d.questProgress++;
      d.syncDirty = true;
      if (d.questProgress >= QuestBoardInfo.TARGET) {
         sp.displayClientMessage(
            Component.literal("Quest complete: " + QuestBoardInfo.TITLE + "! Open your Quest Book (N) to claim the reward.").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false
         );
         sp.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 1.0F);
      } else {
         sp.displayClientMessage(
            Component.literal("Quest: " + QuestBoardInfo.TITLE + " (" + d.questProgress + "/" + QuestBoardInfo.TARGET + ")").withStyle(ChatFormatting.YELLOW), true
         );
      }

      RpgManager.sync(sp, -1);
   }

   /** Claim Reward pressed in the Quest Book. */
   public static void claim(ServerPlayer p) {
      RpgData d = RpgManager.get(p);
      boolean refreshed = normalize(p, d);
      if (refreshed) {
         p.displayClientMessage(Component.literal("The Quest Board refreshed: that quest is gone.").withStyle(ChatFormatting.RED), true);
      } else if (!d.questAccepted) {
         p.displayClientMessage(Component.literal("You haven't taken a quest. Right-click a Quest Board.").withStyle(ChatFormatting.RED), true);
      } else if (d.questClaimed) {
         p.displayClientMessage(Component.literal("You already claimed this reward.").withStyle(ChatFormatting.RED), true);
      } else if (d.questProgress < QuestBoardInfo.TARGET) {
         p.displayClientMessage(Component.literal("Quest not finished yet (" + d.questProgress + "/" + QuestBoardInfo.TARGET + ").").withStyle(ChatFormatting.RED), true);
      } else {
         d.questClaimed = true;
         d.syncDirty = true;
         RpgManager.award(p, d, QuestBoardInfo.REWARD_EXP);
         p.displayClientMessage(Component.literal("Quest reward: +" + QuestBoardInfo.REWARD_EXP + " EXP").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), false);
         p.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0F, 1.0F);
      }

      RpgManager.sync(p, QuestBoardInfo.BOOK_CODE); // reopen the Quest Book with fresh data
   }
}
