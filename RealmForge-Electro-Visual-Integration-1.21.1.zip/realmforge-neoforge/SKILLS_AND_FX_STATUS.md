# RealmForge – Electro skills, unlocks and effects

## Command
    /realmforge skill unlock all        gives every skill (anyone; set ALLOW_ANYONE_UNLOCK=false in RpgCommands for ops-only)
    /realmforge skill unlock <skill>    one skill
    /realmforge skill list | progress   shows lock state + quest progress
    /realmforge skill bind <1-3> <skill> equip (Skill Book does this for you; swaps if already on another key)
    /realmforge skill lock all          (op) re-lock everything to test the quests

## Skills and their unique unlock quest (all start locked)
| Skill (key default) | Unlock quest | Cost / CD | Animation | Main Photon fx |
|---|---|---|---|---|
| Electro Barrage (Z) | 100 empty-hand punches | 2 / 5s | rushdownbarrage | gorotrail, pgoroimpact1 |
| Electro Dropkick (X) | Survive 5 falls of 12+ blocks | 3 / 10s | electro_dropkick_pawdash | dash3, gorodash3, bigimpact |
| Electro Double Scratch (C) | 15 kills while sprinting | 2 / 7.5s | electro_double_scratch_violentthrash (3.5x speed) | violentthrash, clawshit |
| Electric Field | 8 s in the open during a thunderstorm | 5 / 15s | electric_field_countershock | countershock, goroaura, pgorolightinggroundlight1 |
| Electro Fist | Survive a lightning strike at <= 6 hearts | 4 / 12.5s | electro_fist_countershockow | kaidolightning, bigimpact |
Five skills, three keys: choose what sits on Z / X / C in the Skill Book (N): [ EQUIP ] -> [ Z ] [ X ] [ C ] (text buttons).

## How effects are played
* Built-in particles (JjkParticles spark/blue_spark + vanilla electric spark) and sounds: always.
* Photon .fx: server runs `/photon fx photon:NAME entity <uuid> 0 Y 0 0 0 0 0 false true` (the exact command the original mod used).
  Needs the Photon mod on server AND client. If missing, only the built-in particles show. Startup log says which.
* All .fx files are now in assets/photon/fx (35 were only in electro_original/photon_fx_source before -> never loaded, e.g. countershock).
* The .fx files point at textures `trueprimepiecetwo:textures/particle/*.png`. Only 4 exist in your zips (lightning1, gorolightningtest,
  hakilightning, hakilightningtest = original). The other 25 are generated white stand-ins (see PLACEHOLDERS.txt in that folder).
  Drop the original mod's PNGs over them for the real look.

## Not verified (no compiler / no Minecraft here)
Nothing was compiled or run in-game. Brace/import/file-name checks passed; API names are from NeoForge 21.1 / MC 1.21.1 memory.
