package com.realmforge.logic;

import com.realmforge.RealmForgeMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class JjkParticles {
   public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, RealmForgeMod.MOD_ID);
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> BLOOM = register("bloom");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> SPARK = register("spark");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> BF_SPARK = register("bf_spark");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> RED_BOOM = register("red_boom");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> PURPLE_BOOM = register("purple_boom");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> BLUE_SPARK = register("blue_spark");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> RED_SPARK = register("red_spark");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> PURPLE_SPARK = register("purple_spark");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> CE_SPARK = register("ce_spark");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> BLOOD_SPLASH = register("blood_splash");

   private JjkParticles() {
   }

   private static DeferredHolder<ParticleType<?>, SimpleParticleType> register(String name) {
      return PARTICLES.register(name, () -> new SimpleParticleType(true));
   }
}
