package com.realmforge.logic;

import com.realmforge.data.Stat;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class EquipmentBonuses {
   private EquipmentBonuses() {
   }

   public static int[] compute(ServerPlayer p) {
      int[] r = new int[Stat.values().length];
      armor(r, p.getItemBySlot(EquipmentSlot.HEAD), "_helmet");
      armor(r, p.getItemBySlot(EquipmentSlot.CHEST), "_chestplate");
      armor(r, p.getItemBySlot(EquipmentSlot.LEGS), "_leggings");
      armor(r, p.getItemBySlot(EquipmentSlot.FEET), "_boots");
      mainHand(r, path(p.getItemBySlot(EquipmentSlot.MAINHAND)));
      offHand(r, path(p.getItemBySlot(EquipmentSlot.OFFHAND)));
      return r;
   }

   private static String path(ItemStack s) {
      return s.isEmpty() ? "" : BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
   }

   private static void add(int[] r, Stat s, int v) {
      r[s.ordinal()] += v;
   }

   private static void armor(int[] r, ItemStack st, String suffix) {
      String p = path(st);
      if (p.endsWith(suffix)) {
         if (p.startsWith("leather_")) {
            add(r, Stat.AGI, 1);
         } else if (p.startsWith("chainmail_")) {
            add(r, Stat.AGI, 1);
            add(r, Stat.VIT, 1);
         } else if (p.startsWith("iron_")) {
            add(r, Stat.VIT, 1);
         } else if (p.startsWith("golden_")) {
            add(r, Stat.ENE, 1);
            add(r, Stat.INT, 1);
         } else if (p.startsWith("diamond_")) {
            add(r, Stat.VIT, 2);
         } else if (p.startsWith("netherite_")) {
            add(r, Stat.VIT, 2);
            add(r, Stat.STR, 1);
         } else if (p.startsWith("turtle_")) {
            add(r, Stat.ENE, 1);
         }
      }
   }

   private static int tier(String p) {
      if (p.startsWith("netherite_")) {
         return 4;
      } else if (p.startsWith("diamond_")) {
         return 3;
      } else {
         return p.startsWith("iron_") ? 2 : 1;
      }
   }

   private static void mainHand(int[] r, String p) {
      if (p.isEmpty()) {
         return;
      }

      if (p.endsWith("_sword") || p.endsWith("_axe")) {
         add(r, Stat.STR, tier(p));
         return;
      }

      switch (p) {
         case "bow", "crossbow" -> {
            add(r, Stat.AGI, 2);
            add(r, Stat.STR, 1);
         }
         case "trident" -> add(r, Stat.STR, 3);
         case "mace" -> add(r, Stat.STR, 4);
         case "blaze_rod" -> {
            add(r, Stat.INT, 3);
            add(r, Stat.ENE, 1);
         }
         case "breeze_rod" -> {
            add(r, Stat.INT, 4);
            add(r, Stat.AGI, 1);
         }
         default -> {
         }
      }
   }

   private static void offHand(int[] r, String p) {
      switch (p) {
         case "shield" -> add(r, Stat.VIT, 2);
         case "totem_of_undying" -> {
            add(r, Stat.ENE, 2);
            add(r, Stat.VIT, 1);
         }
         case "enchanted_book" -> add(r, Stat.INT, 1);
         default -> {
         }
      }
   }
}
