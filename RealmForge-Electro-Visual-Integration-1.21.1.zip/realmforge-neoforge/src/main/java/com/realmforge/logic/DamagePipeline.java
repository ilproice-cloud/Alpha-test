package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.addon.logic.BlockingManager;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Outgoing/incoming damage scaling. The Fabric build patched this class with a
 * mixin (flat STR damage, Toji set bonus, blocking reduction); that logic is
 * merged in here.
 */
public final class DamagePipeline {
   public static final ThreadLocal<Boolean> SKILL = ThreadLocal.withInitial(() -> false);
   private static final double DMG_PER_STR = 1.0;

   private DamagePipeline() {
   }

   public static float modify(LivingEntity victim, DamageSource src, float amount) {
      if (victim.level().isClientSide || amount <= 0.0F) {
         return amount;
      }

      float a = amount;
      Entity attacker = src.getEntity();
      if (attacker instanceof ServerPlayer ap && attacker != victim && !SKILL.get()) {
         RpgData d = RpgManager.get(ap);
         double m = d.dmgOut();
         boolean physical = src.getDirectEntity() == attacker || src.is(DamageTypeTags.IS_PROJECTILE);
         if (physical) {
            m *= d.physMult();
         }

         a = amount * (float)m;
         double ls = d.lifesteal();
         if (ls > 0.0) {
            ap.heal((float)((double)a * ls));
         }
      }

      if (victim instanceof ServerPlayer vp) {
         a *= (float)RpgManager.get(vp).dmgIn();
      }

      // --- fused addon pass: flat STR damage on melee hits, then blocking reduction ---
      float r = a;
      if (attacker instanceof ServerPlayer sp && attacker != victim && src.getDirectEntity() == attacker && !SKILL.get()) {
         RpgData d = RpgManager.get(sp);
         double str = (double)d.stat(Stat.STR) * DMG_PER_STR;
         if (d.toji()) {
            str *= 1.75;
         }

         r += (float)str;
      }

      return BlockingManager.apply(victim, src, r);
   }
}
