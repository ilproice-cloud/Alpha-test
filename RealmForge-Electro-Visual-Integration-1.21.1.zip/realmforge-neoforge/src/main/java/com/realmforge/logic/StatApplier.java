package com.realmforge.logic;

import com.realmforge.RealmForgeMod;
import com.realmforge.data.RpgData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public final class StatApplier {
   private static final ResourceLocation HP_ID = RealmForgeMod.id("vit_health");
   private static final ResourceLocation SPEED_ID = RealmForgeMod.id("agi_speed");

   private StatApplier() {
   }

   public static void apply(ServerPlayer p, RpgData d, boolean healGain) {
      float oldMax = p.getMaxHealth();
      float oldMaxEnergy = d.maxEnergy();
      set(p.getAttribute(Attributes.MAX_HEALTH), HP_ID, (double)d.maxHealthBonus(), AttributeModifier.Operation.ADD_VALUE);
      set(p.getAttribute(Attributes.MOVEMENT_SPEED), SPEED_ID, d.speedBonus(), AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
      float newMax = p.getMaxHealth();
      if (healGain && newMax > oldMax) {
         p.heal(newMax - oldMax);
      }

      float newMaxEnergy = d.maxEnergy();
      if (healGain && newMaxEnergy > oldMaxEnergy) {
         d.energy = Math.min(newMaxEnergy, d.energy + (newMaxEnergy - oldMaxEnergy));
      }

      if (p.getHealth() > newMax) {
         p.setHealth(newMax);
      }

      d.energy = Math.min(d.energy, d.maxEnergy());
      d.syncDirty = true;
   }

   private static void set(AttributeInstance inst, ResourceLocation id, double value, AttributeModifier.Operation op) {
      if (inst != null) {
         inst.removeModifier(id);
         if (value != 0.0) {
            inst.addTransientModifier(new AttributeModifier(id, value, op));
         }
      }
   }
}
