package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import com.realmforge.data.Skill;
import com.realmforge.skill.ElectroSkills;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** Entry point for Z / X / C (slot 0..2). Checks unlock, cooldown and energy, then runs the skill. */
public final class SkillExecutor {
   private SkillExecutor() {
   }

   public static void use(ServerPlayer p, int slot) {
      if (slot < 0 || slot >= Skill.SLOTS) {
         return;
      }

      RpgData d = RpgManager.get(p);
      Skill s = Skill.byId(d.slots[slot]);
      if (s == null) {
         return;
      }

      if (!d.isUnlocked(s)) {
         msg(p, s.label + " is locked: " + s.hint + " (" + d.progress(s) + "/" + s.goal + ")", ChatFormatting.RED);
         return;
      }

      long now = p.serverLevel().getGameTime();
      long cd = d.cdEnd[s.ordinal()];
      if (cd > now) {
         msg(p, s.label + " cooldown: " + String.format("%.1f", (double)(cd - now) / 20.0) + "s", ChatFormatting.GRAY);
         return;
      }

      if (d.energy < (float)s.energyCost) {
         msg(p, "Not enough energy for " + s.label + " (" + s.energyCost + " needed).", ChatFormatting.AQUA);
         return;
      }

      d.energy -= (float)s.energyCost;
      d.cdEnd[s.ordinal()] = now + (long)s.cooldownTicks;
      d.skillUses[s.ordinal()]++;
      d.syncDirty = true;
      ElectroSkills.cast(p, d, s);
      RpgManager.sync(p, -1);
   }

   private static void msg(ServerPlayer p, String text, ChatFormatting color) {
      p.displayClientMessage(Component.literal(text).withStyle(color), true);
   }
}
