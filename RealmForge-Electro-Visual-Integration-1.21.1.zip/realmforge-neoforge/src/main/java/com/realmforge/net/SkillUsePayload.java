package com.realmforge.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record SkillUsePayload(int slot) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<SkillUsePayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("skill_use"));
   public static final StreamCodec<ByteBuf, SkillUsePayload> CODEC = ByteBufCodecs.INT.map(SkillUsePayload::new, SkillUsePayload::slot);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
