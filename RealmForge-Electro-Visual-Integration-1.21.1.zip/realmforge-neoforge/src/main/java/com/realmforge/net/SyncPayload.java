package com.realmforge.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record SyncPayload(String snbt, int openPage) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<SyncPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("sync"));
   public static final StreamCodec<ByteBuf, SyncPayload> CODEC = StreamCodec.composite(
      ByteBufCodecs.STRING_UTF8, SyncPayload::snbt, ByteBufCodecs.INT, SyncPayload::openPage, SyncPayload::new
   );

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
