package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.data.RpgData;
import com.realmforge.data.Stat;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.PhotonFxNet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Electro Double Scratch — dual claw swipes (violentthrash + clawshit FX + claw model). */
public final class ElectroDoubleScratchSkill implements SkillDefinition {
    public static final String ID = "electro_double_scratch";
    private static final ElectroDoubleScratchSkill INSTANCE = new ElectroDoubleScratchSkill();
    static { SkillRegistry.register(INSTANCE); }
    public static void init() {}
    private ElectroDoubleScratchSkill() {}

    @Override public String id() { return ID; }
    @Override public String label() { return "Electro Double Scratch"; }
    @Override public String description() {
        return "Two fast electric claw swipes that hit a cone and knock enemies back.";
    }
    @Override public int energyCost() { return 12; }
    @Override public int cooldownTicks() { return 60; }
    @Override public boolean isUnlocked(RpgData data) { return data.isSkillUnlocked(ID); }

    @Override
    public void execute(ServerPlayer player, RpgData data) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        Vec3 origin = player.getEyePosition();

        AnimNet.broadcast(player, 1); // violentthrash (also shows claws)
        PhotonFxNet.broadcast(player, "clawshit", 2);
        PhotonFxNet.broadcast(player, "violentthrash", 0);

        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP,
                SoundSource.PLAYERS, 1.0f, 1.25f);
        level.playSound(null, player.blockPosition(), SoundEvents.TRIDENT_THROW,
                SoundSource.PLAYERS, 0.5f, 1.6f);

        float baseDmg = 5.5f + data.stat(Stat.STR) * 0.4f;
        double range = 3.8;
        double coneCos = Math.cos(Math.toRadians(55));

        AABB box = player.getBoundingBox().inflate(range);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
            Vec3 to = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(origin).normalize();
            if (look.dot(to) >= coneCos && origin.distanceTo(target.position()) <= range) {
                DamagePipeline.dealSkillDamage(player, target, baseDmg * 0.55f, data);
                DamagePipeline.dealSkillDamage(player, target, baseDmg * 0.55f, data);
                target.knockback(0.55, -look.x, -look.z);
                level.sendParticles(ParticleTypes.SWEEP_ATTACK,
                        target.getX(), target.getY() + 1.0, target.getZ(), 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        target.getX(), target.getY() + 0.9, target.getZ(),
                        16, 0.35, 0.3, 0.35, 0.06);
            }
        }

        for (int i = 0; i < 10; i++) {
            double a = (i / 10.0 - 0.5) * Math.PI * 0.7;
            Vec3 side = new Vec3(-look.z, 0, look.x).normalize().scale(Math.sin(a) * 1.2);
            Vec3 p = origin.add(look.scale(1.5 + Math.cos(a) * 0.8)).add(side);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.01);
        }
    }
}
