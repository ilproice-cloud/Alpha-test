package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Registers every .ogg in assets/realmforge/sounds (declared in sounds.json) as a real sound event. */
public final class ModSounds {
   public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, RealmForgeMod.MOD_ID);
   private static final String[] NAMES = new String[]{
      "bigslice2", "clothwhoosh", "el_thor", "floorskid", "gheavyslam", "groundslam", "ice_spike_emerge", "knucklecrack", "lightningboomy",
      "lightningboomy2", "lightpunch", "longlightning", "omnikaboom", "raigoboom", "slishsloch", "smalllightningboomy", "swordslice2", "teleport"
   };
   private static final Map<String, DeferredHolder<SoundEvent, SoundEvent>> MAP = new HashMap<>();

   static {
      for (String n : NAMES) {
         MAP.put(n, SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(RealmForgeMod.id(n))));
      }
   }

   private ModSounds() {
   }

   public static void play(ServerLevel level, double x, double y, double z, String name, float volume, float pitch) {
      DeferredHolder<SoundEvent, SoundEvent> h = MAP.get(name);
      if (h != null) {
         level.playSound(null, x, y, z, h.get(), SoundSource.PLAYERS, volume, pitch);
      }
   }
}
