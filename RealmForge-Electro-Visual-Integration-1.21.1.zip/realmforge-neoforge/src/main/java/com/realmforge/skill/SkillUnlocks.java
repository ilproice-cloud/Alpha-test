package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import com.realmforge.data.Skill;
import com.realmforge.logic.DamagePipeline;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityStruckByLightningEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * The unique way to earn each skill (all skills start locked):
 *  Electro Barrage        - 100 punches with an empty hand
 *  Electro Dropkick       - survive 5 falls of 12+ blocks
 *  Electro Double Scratch - 15 kills while sprinting
 *  Electric Field         - stand in the open during a thunderstorm for 8 seconds
 *  Electro Fist           - survive a lightning strike at 6 hearts or less
 * Or run /realmforge skill unlock all.
 */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID)
public final class SkillUnlocks {
   private SkillUnlocks() {
   }

   public static void progress(ServerPlayer p, Skill s, int amount) {
      RpgData d = RpgManager.get(p);
      if (d.isUnlocked(s)) {
         return;
      }

      boolean done = d.addProgress(s, amount);
      if (done) {
         celebrate(p, s);
      } else {
         int have = d.progress(s);
         if (s != Skill.STRONG_PUNCH || have % 10 == 0) {
            p.displayClientMessage(Component.literal(s.label + " quest: " + have + "/" + s.goal + " " + s.unit).withStyle(ChatFormatting.AQUA), true);
         }
      }

      if (done || s != Skill.STRONG_PUNCH || d.progress(s) % 5 == 0) {
         RpgManager.sync(p, -1);
      }
   }

   /** Announcement + effects for one newly unlocked skill. */
   public static void celebrate(ServerPlayer p, Skill s) {
      p.displayClientMessage(
         Component.literal("SKILL UNLOCKED: ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
            .append(Component.literal(s.label).withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD))
            .append(Component.literal("  - open the Skill Book (N) and press [ EQUIP ]").withStyle(ChatFormatting.GRAY)),
         false
      );
      p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.2F);
      effects(p);
      RpgManager.state(p.getServer()).setDirty();
   }

   /** Electric burst around the player (used on unlock and on unlock all). */
   public static void effects(ServerPlayer p) {
      SkillFx.sparks(p.serverLevel(), p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.8);
      SkillFx.ring(p.serverLevel(), p.position(), 2.0, 24);
      SkillFx.fx(p, "goroburst");
      ModSounds.play(p.serverLevel(), p.getX(), p.getY(), p.getZ(), "lightningboomy2", 1.0F, 1.2F);
   }

   // ---- Electro Barrage: empty-hand punches
   @SubscribeEvent
   public static void onPunch(LivingIncomingDamageEvent e) {
      if (e.getSource().getEntity() instanceof ServerPlayer p
         && e.getSource().getDirectEntity() == p
         && e.getEntity() != p
         && !DamagePipeline.SKILL.get()
         && p.getMainHandItem().isEmpty()) {
         progress(p, Skill.STRONG_PUNCH, 1);
      }
   }

   // ---- Electro Dropkick: survive big falls
   @SubscribeEvent
   public static void onFall(LivingFallEvent e) {
      if (e.getEntity() instanceof ServerPlayer p && e.getDistance() >= 12.0F) {
         float dmg = (e.getDistance() - 3.0F) * e.getDamageMultiplier();
         if (p.getHealth() > dmg) {
            progress(p, Skill.UPPERCUT, 1);
         }
      }
   }

   // ---- Electro Double Scratch: sprint kills
   @SubscribeEvent
   public static void onKill(LivingDeathEvent e) {
      LivingEntity dead = e.getEntity();
      if (!(dead instanceof Player) && e.getSource().getEntity() instanceof ServerPlayer p && p.isSprinting()) {
         progress(p, Skill.BARRAGE, 1);
      }
   }

   // ---- Electro Fist: survive lightning at low health
   @SubscribeEvent
   public static void onLightning(EntityStruckByLightningEvent e) {
      if (e.getEntity() instanceof ServerPlayer p && p.getHealth() <= 12.0F && p.getHealth() > 5.0F) {
         SkillTasks.later(5, p, () -> {
            if (p.isAlive()) {
               progress(p, Skill.ELECTRO_FIST, 1);
            }
         });
      }
   }

   // ---- Electric Field: seconds spent in the open during a thunderstorm
   @SubscribeEvent
   public static void onTick(ServerTickEvent.Post e) {
      if (e.getServer().getTickCount() % 20 != 0) {
         return;
      }

      for (ServerPlayer p : e.getServer().getPlayerList().getPlayers()) {
         if (!p.isSpectator() && p.serverLevel().isThundering() && p.serverLevel().canSeeSky(p.blockPosition())) {
            progress(p, Skill.ELECTRIC_FIELD, 1);
         }
      }
   }
}
