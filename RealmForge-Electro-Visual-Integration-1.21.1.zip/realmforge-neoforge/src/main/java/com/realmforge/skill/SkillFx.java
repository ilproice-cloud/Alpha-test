package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import com.realmforge.logic.JjkParticles;
import java.util.Locale;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.Vec3;
import net.neoforged.fml.ModList;

/**
 * Visual layer for the skills.
 * 1) RealmForge's own registered particles (always work, no extra mod needed).
 * 2) Photon .fx effects, started with the same command the ORIGINAL mod used:
 *    /photon fx photon:NAME entity UUID 0 Y 0 0 0 0 0 false true
 *    This needs the Photon mod on server AND client; without it the call is silently skipped.
 */
public final class SkillFx {
   /** Every fx the skills ask for (checked at startup so a missing file is logged, not silent). */
   private static final String[] USED = new String[]{
      "gorotrail", "pgoroimpact1", "dash3", "gorodash3", "bigimpact", "violentthrash", "clawshit", "countershock", "goroaura",
      "pgorolightinggroundlight1", "pgorolightinggrounde5", "pgororaigostorm149", "kaidolightning", "goroburst"
   };
   private static Boolean photon;

   private SkillFx() {
   }

   public static boolean photonLoaded() {
      if (photon == null) {
         photon = ModList.get().isLoaded("photon");
      }

      return photon;
   }

   /** Logs the Photon state and any skill fx file that is missing from assets/photon/fx. */
   public static void verify() {
      int missing = 0;
      for (String n : USED) {
         if (SkillFx.class.getResource("/assets/photon/fx/" + n + ".fx") == null) {
            RealmForgeMod.LOGGER.warn("Skill FX file missing: assets/photon/fx/{}.fx", n);
            missing++;
         }
      }

      RealmForgeMod.LOGGER.info("RealmForge skill FX: photon {} / {} fx files present.", photonLoaded() ? "LOADED" : "not installed (using built-in particles only)", USED.length - missing);
   }

   /** Plays a Photon fx attached to {@code e}, {@code yOffset} blocks above its feet. */
   public static void fx(Entity e, String name, double yOffset) {
      if (!photonLoaded() || !(e.level() instanceof ServerLevel sl)) {
         return;
      }

      MinecraftServer server = sl.getServer();
      String cmd = String.format(Locale.ROOT, "photon fx photon:%s entity %s 0 %s 0 0 0 0 0 false true", name, e.getStringUUID(), yOffset);
      try {
         server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), cmd);
      } catch (Throwable t) {
         RealmForgeMod.LOGGER.debug("Photon fx '{}' failed: {}", name, t.toString());
      }
   }

   public static void fx(Entity e, String name) {
      fx(e, name, 1.0);
   }

   /** Burst of electric sparks (RealmForge particles + vanilla electric spark). */
   public static void sparks(ServerLevel l, double x, double y, double z, int n, double spread) {
      l.sendParticles(JjkParticles.BLUE_SPARK.get(), x, y, z, n, spread, spread, spread, 0.05);
      l.sendParticles(JjkParticles.SPARK.get(), x, y, z, Math.max(1, n / 2), spread, spread, spread, 0.04);
      l.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, n, spread, spread, spread, 0.3);
   }

   public static void sparks(ServerLevel l, Vec3 c, int n, double spread) {
      sparks(l, c.x, c.y, c.z, n, spread);
   }

   /** Flat ring of sparks at ground level. */
   public static void ring(ServerLevel l, Vec3 c, double radius, int points) {
      for (int i = 0; i < points; i++) {
         double a = Math.PI * 2.0 * (double)i / (double)points;
         double px = c.x + Math.cos(a) * radius;
         double pz = c.z + Math.sin(a) * radius;
         l.sendParticles(JjkParticles.BLUE_SPARK.get(), px, c.y + 0.2, pz, 1, 0.05, 0.1, 0.05, 0.02);
         l.sendParticles(ParticleTypes.ELECTRIC_SPARK, px, c.y + 0.3, pz, 1, 0.05, 0.2, 0.05, 0.1);
      }
   }

   /** Harmless lightning bolt (visual only: no damage, no fire, does not count as a lightning strike). */
   public static void bolt(ServerLevel l, Vec3 pos) {
      LightningBolt b = EntityType.LIGHTNING_BOLT.create(l);
      if (b != null) {
         b.moveTo(pos.x, pos.y, pos.z);
         b.setVisualOnly(true);
         l.addFreshEntity(b);
      }
   }
}
