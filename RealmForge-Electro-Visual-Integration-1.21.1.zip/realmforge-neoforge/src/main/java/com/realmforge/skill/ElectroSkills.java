package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.addon.anim.SkillAnims;
import com.realmforge.data.RpgData;
import com.realmforge.data.Skill;
import com.realmforge.logic.DamagePipeline;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Server-side behaviour of the five Electro skills: animation + sound + Photon fx + particles + damage. */
public final class ElectroSkills {
   private ElectroSkills() {
   }

   public static void cast(ServerPlayer p, RpgData d, Skill s) {
      switch (s) {
         case STRONG_PUNCH -> barrage(p, d);
         case UPPERCUT -> dropkick(p, d);
         case BARRAGE -> doubleScratch(p, d);
         case ELECTRIC_FIELD -> electricField(p, d);
         case ELECTRO_FIST -> electroFist(p, d);
      }
   }

   // ------------------------------------------------------------------ helpers

   private static ServerLevel lvl(ServerPlayer p) {
      return p.serverLevel();
   }

   private static boolean valid(ServerPlayer p, LivingEntity t) {
      return t != p && t.isAlive() && !t.isSpectator() && p.canAttack(t) && !t.isAlliedTo(p);
   }

   private static Vec3 flatLook(ServerPlayer p) {
      Vec3 l = p.getLookAngle();
      Vec3 f = new Vec3(l.x, 0.0, l.z);
      return f.lengthSqr() < 1.0E-4 ? Vec3.directionFromRotation(0.0F, p.getYRot()) : f.normalize();
   }

   private static List<LivingEntity> cone(ServerPlayer p, double range, double halfAngleDeg) {
      Vec3 look = flatLook(p);
      Vec3 origin = p.position();
      double cos = Math.cos(Math.toRadians(halfAngleDeg));
      List<LivingEntity> out = new ArrayList<>();
      AABB box = p.getBoundingBox().inflate(range, 1.5, range);
      for (LivingEntity e : lvl(p).getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
         Vec3 to = new Vec3(e.getX() - origin.x, 0.0, e.getZ() - origin.z);
         double dist = to.length();
         if (dist > range + (double)e.getBbWidth() * 0.5) {
            continue;
         }

         if (dist < 0.9 || to.normalize().dot(look) >= cos) {
            out.add(e);
         }
      }

      return out;
   }

   private static List<LivingEntity> around(ServerPlayer p, Vec3 center, double radius) {
      List<LivingEntity> out = new ArrayList<>();
      AABB box = new AABB(center, center).inflate(radius, 2.0, radius);
      for (LivingEntity e : lvl(p).getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
         if (e.position().distanceTo(center) <= radius + (double)e.getBbWidth() * 0.5) {
            out.add(e);
         }
      }

      return out;
   }

   /** Skill damage: scaled by skill level, INT, perks and outgoing multiplier; bypasses the melee STR pipeline. */
   private static void hurt(ServerPlayer p, RpgData d, Skill s, LivingEntity t, double base) {
      float dmg = (float)(base * d.skillDamageMult(s) * d.dmgOut());
      t.invulnerableTime = 0;
      DamagePipeline.SKILL.set(true);
      try {
         t.hurt(p.damageSources().playerAttack(p), dmg);
      } finally {
         DamagePipeline.SKILL.set(false);
      }
   }

   private static void shove(LivingEntity t, Vec3 dir, double horizontal, double up) {
      double h = horizontal * (1.0 - t.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
      Vec3 m = t.getDeltaMovement();
      t.setDeltaMovement(m.x * 0.3 + dir.x * h, Math.max(m.y, up), m.z * 0.3 + dir.z * h);
      t.hurtMarked = true;
   }

   private static void snd(ServerPlayer p, String name, float vol, float pitch) {
      ModSounds.play(lvl(p), p.getX(), p.getY(), p.getZ(), name, vol, pitch);
   }

   private static void slow(LivingEntity t, int ticks, int amp) {
      t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, amp));
   }

   // ------------------------------------------------------------------ Z: Electro Barrage

   private static void barrage(ServerPlayer p, RpgData d) {
      AnimNet.broadcast(p, SkillAnims.BARRAGE);
      snd(p, "clothwhoosh", 0.9F, 1.1F);
      SkillFx.fx(p, "gorotrail");
      for (int i = 0; i < 8; i++) {
         final int k = i;
         SkillTasks.later(2 + i * 2, p, () -> {
            Vec3 look = flatLook(p);
            for (LivingEntity t : cone(p, 4.0, 50.0)) {
               hurt(p, d, Skill.STRONG_PUNCH, t, 2.2);
               shove(t, look, 0.12, 0.05);
               SkillFx.sparks(lvl(p), t.getX(), t.getY(0.6), t.getZ(), 6, 0.3);
               if (k % 2 == 0) {
                  SkillFx.fx(t, "pgoroimpact1", (double)t.getBbHeight() * 0.5);
               }
            }

            snd(p, k % 2 == 0 ? "lightpunch" : "knucklecrack", 0.8F, 1.0F + 0.03F * (float)k);
         });
      }
   }

   // ------------------------------------------------------------------ X: Electro Dropkick

   private static void dropkick(ServerPlayer p, RpgData d) {
      AnimNet.broadcast(p, SkillAnims.DROPKICK);
      Vec3 dir = flatLook(p);
      Set<UUID> hit = new HashSet<>();
      snd(p, "clothwhoosh", 1.0F, 0.9F);
      snd(p, "floorskid", 0.7F, 1.0F);
      SkillFx.fx(p, "dash3");
      SkillFx.fx(p, "gorodash3");
      for (int i = 1; i <= 9; i++) {
         final int k = i;
         SkillTasks.later(i, p, () -> {
            p.setDeltaMovement(dir.x * 1.5, k <= 2 ? 0.22 : p.getDeltaMovement().y, dir.z * 1.5);
            p.hurtMarked = true;
            p.fallDistance = 0.0F;
            SkillFx.sparks(lvl(p), p.getX(), p.getY() + 0.8, p.getZ(), 4, 0.3);
            AABB box = p.getBoundingBox().inflate(1.2, 0.6, 1.2);
            for (LivingEntity t : lvl(p).getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
               if (hit.add(t.getUUID())) {
                  hurt(p, d, Skill.UPPERCUT, t, 9.0);
                  shove(t, dir, 1.6, 0.45);
                  SkillFx.fx(t, "bigimpact", (double)t.getBbHeight() * 0.5);
                  SkillFx.sparks(lvl(p), t.getX(), t.getY(0.5), t.getZ(), 14, 0.4);
                  snd(p, "groundslam", 0.9F, 1.1F);
               }
            }
         });
      }

      SkillTasks.later(10, p, () -> {
         p.fallDistance = 0.0F;
         Vec3 c = p.position();
         for (LivingEntity t : around(p, c, 3.0)) {
            if (hit.add(t.getUUID())) {
               hurt(p, d, Skill.UPPERCUT, t, 4.5);
               shove(t, t.position().subtract(c).multiply(1.0, 0.0, 1.0).normalize(), 0.9, 0.3);
            }
         }

         SkillFx.ring(lvl(p), c, 3.0, 24);
         SkillFx.sparks(lvl(p), c.x, c.y + 0.5, c.z, 20, 0.6);
         SkillFx.fx(p, "bigimpact", 0.2);
         snd(p, "lightningboomy2", 1.0F, 1.0F);
      });
   }

   // ------------------------------------------------------------------ C: Electro Double Scratch

   private static void doubleScratch(ServerPlayer p, RpgData d) {
      AnimNet.broadcast(p, SkillAnims.SCRATCH);
      SkillFx.fx(p, "violentthrash");
      snd(p, "swordslice2", 1.0F, 1.2F);
      int[] when = new int[]{3, 9};
      for (int i = 0; i < when.length; i++) {
         final int k = i;
         SkillTasks.later(when[i], p, () -> {
            Vec3 look = flatLook(p);
            snd(p, k == 0 ? "bigslice2" : "slishsloch", 1.0F, 1.0F + 0.15F * (float)k);
            for (LivingEntity t : cone(p, 4.2, 70.0)) {
               hurt(p, d, Skill.BARRAGE, t, 5.5);
               shove(t, look, 0.9, 0.2);
               SkillFx.fx(t, "clawshit", (double)t.getBbHeight() * 0.5);
               SkillFx.sparks(lvl(p), t.getX(), t.getY(0.6), t.getZ(), 10, 0.35);
            }
         });
      }
   }

   // ------------------------------------------------------------------ Electric Field

   private static void electricField(ServerPlayer p, RpgData d) {
      AnimNet.broadcast(p, SkillAnims.FIELD);
      SkillFx.fx(p, "countershock");
      SkillFx.fx(p, "goroaura");
      snd(p, "lightningboomy", 1.0F, 0.9F);
      p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0));
      final double radius = 7.0;
      for (int i = 0; i < 3; i++) {
         final int k = i;
         SkillTasks.later(8 + i * 10, p, () -> {
            Vec3 c = p.position();
            boolean last = k == 2;
            SkillFx.ring(lvl(p), c, radius * (double)(k + 1) / 3.0, 32);
            SkillFx.sparks(lvl(p), c.x, c.y + 1.0, c.z, 24, 1.2);
            snd(p, last ? "el_thor" : "smalllightningboomy", 1.0F, 1.0F);
            for (LivingEntity t : around(p, c, radius)) {
               hurt(p, d, Skill.ELECTRIC_FIELD, t, last ? 14.0 : 6.0);
               slow(t, 40, 1);
               SkillFx.fx(t, "pgorolightinggroundlight1", 0.0);
               SkillFx.sparks(lvl(p), t.getX(), t.getY(0.5), t.getZ(), 10, 0.4);
               if (last) {
                  SkillFx.bolt(lvl(p), t.position());
               }
            }

            if (last) {
               SkillFx.fx(p, "pgorolightinggrounde5", 0.0);
               SkillFx.fx(p, "pgororaigostorm149", 0.0);
               snd(p, "longlightning", 1.0F, 1.0F);
            }
         });
      }
   }

   // ------------------------------------------------------------------ Electro Fist

   private static void electroFist(ServerPlayer p, RpgData d) {
      AnimNet.broadcast(p, SkillAnims.FIST);
      SkillFx.fx(p, "goroaura");
      snd(p, "lightningboomy", 0.8F, 1.2F);
      SkillTasks.later(10, p, () -> {
         Vec3 look = flatLook(p);
         LivingEntity target = null;
         double best = Double.MAX_VALUE;
         for (LivingEntity e : cone(p, 7.0, 28.0)) {
            double dist = e.distanceToSqr(p);
            if (dist < best) {
               best = dist;
               target = e;
            }
         }

         Vec3 impact;
         if (target != null) {
            Vec3 dest = target.position().subtract(look.scale(1.4));
            if (lvl(p).noCollision(p, p.getBoundingBox().move(dest.subtract(p.position())))) {
               p.connection.teleport(dest.x, dest.y, dest.z, p.getYRot(), p.getXRot());
            }

            p.fallDistance = 0.0F;
            impact = target.position();
            hurt(p, d, Skill.ELECTRO_FIST, target, 16.0);
            shove(target, look, 2.2, 0.5);
            slow(target, 30, 3);
            SkillFx.fx(target, "kaidolightning", 0.0);
            SkillFx.fx(target, "bigimpact", (double)target.getBbHeight() * 0.5);
            SkillFx.bolt(lvl(p), target.position());
         } else {
            impact = p.position().add(look.scale(2.5));
            SkillFx.bolt(lvl(p), impact);
         }

         for (LivingEntity t : around(p, impact, 5.0)) {
            if (t != target) {
               hurt(p, d, Skill.ELECTRO_FIST, t, 6.0);
               slow(t, 40, 1);
               SkillFx.fx(t, "pgoroimpact1", (double)t.getBbHeight() * 0.5);
               SkillFx.sparks(lvl(p), t.getX(), t.getY(0.5), t.getZ(), 10, 0.4);
            }
         }

         SkillFx.ring(lvl(p), impact, 4.0, 28);
         SkillFx.sparks(lvl(p), impact.x, impact.y + 1.0, impact.z, 30, 0.8);
         snd(p, "gheavyslam", 1.0F, 1.0F);
         snd(p, "lightningboomy2", 1.0F, 0.9F);
      });
   }
}
