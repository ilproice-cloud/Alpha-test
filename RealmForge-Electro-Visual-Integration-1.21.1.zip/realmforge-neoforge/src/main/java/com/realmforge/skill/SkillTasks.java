package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Tiny server-tick scheduler used to sequence multi-hit skills (hit N ticks after the key press). */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID)
public final class SkillTasks {
   private static final class Task {
      final long at;
      final ServerPlayer owner;
      final Runnable run;

      Task(long at, ServerPlayer owner, Runnable run) {
         this.at = at;
         this.owner = owner;
         this.run = run;
      }
   }

   private static final List<Task> TASKS = new ArrayList<>();
   private static long now;

   private SkillTasks() {
   }

   /** Runs {@code r} after {@code ticks} server ticks; skipped if the player has left the world by then. */
   public static void later(int ticks, ServerPlayer owner, Runnable r) {
      if (ticks <= 0) {
         r.run();
      } else {
         TASKS.add(new Task(now + ticks, owner, r));
      }
   }

   @SubscribeEvent
   public static void onTick(ServerTickEvent.Post event) {
      now++;
      if (TASKS.isEmpty()) {
         return;
      }

      List<Task> due = new ArrayList<>();
      Iterator<Task> it = TASKS.iterator();
      while (it.hasNext()) {
         Task t = it.next();
         if (t.at <= now) {
            due.add(t);
            it.remove();
         }
      }

      for (Task t : due) {
         if (t.owner == null || !t.owner.isRemoved()) {
            try {
               t.run.run();
            } catch (Throwable e) {
               RealmForgeMod.LOGGER.error("Skill task failed", e);
            }
         }
      }
   }
}
