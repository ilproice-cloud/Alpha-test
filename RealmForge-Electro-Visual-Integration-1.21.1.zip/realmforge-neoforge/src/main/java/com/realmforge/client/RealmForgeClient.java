package com.realmforge.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.client.BlockingClient;
import com.realmforge.client.particle.JjkAnimatedParticle;
import com.realmforge.logic.JjkParticles;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/** Client-only mod-bus registrations: keys, particles, HUD layer. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class RealmForgeClient {
   private static final String CAT = "key.categories.realmforge";
   public static final KeyMapping OPEN = new KeyMapping("key.realmforge.open", InputConstants.Type.KEYSYM, 77, CAT);
   public static final KeyMapping SKILL_BOOK = new KeyMapping("key.realmforge.skill_book", InputConstants.Type.KEYSYM, 78, CAT);
   public static final KeyMapping[] SKILL_KEYS = new KeyMapping[]{
      new KeyMapping("key.realmforge.skill1", InputConstants.Type.KEYSYM, 90, CAT),
      new KeyMapping("key.realmforge.skill2", InputConstants.Type.KEYSYM, 88, CAT),
      new KeyMapping("key.realmforge.skill3", InputConstants.Type.KEYSYM, 67, CAT)
   };

   private RealmForgeClient() {
   }

   @SubscribeEvent
   public static void registerKeys(RegisterKeyMappingsEvent event) {
      event.register(OPEN);
      event.register(SKILL_BOOK);
      for (KeyMapping k : SKILL_KEYS) {
         event.register(k);
      }

      event.register(BlockingClient.BLOCK);
   }

   @SubscribeEvent
   public static void registerParticles(RegisterParticleProvidersEvent event) {
      event.registerSpriteSet(JjkParticles.BLOOM.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.BF_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.RED_BOOM.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.PURPLE_BOOM.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.BLUE_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.RED_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.PURPLE_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.CE_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.BLOOD_SPLASH.get(), JjkAnimatedParticle.Factory::new);
   }

   @SubscribeEvent
   public static void registerHud(RegisterGuiLayersEvent event) {
      event.registerAboveAll(RealmForgeMod.id("hud"), RpgHud::render);
   }
}
