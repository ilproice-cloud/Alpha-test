package com.realmforge.client;

import net.minecraft.client.Minecraft;

final class ClientActions {
   private ClientActions() {
   }

   static void sync(String snbt, int openPage) {
      ClientRpg.accept(snbt);
      if (openPage != -1 && ClientRpg.data != null) {
         Minecraft.getInstance().setScreen(RpgBook.screen(openPage));
      }
   }
}
