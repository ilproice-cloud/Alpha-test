package com.realmforge.client;

import com.lowdragmc.photon.client.fx.EntityEffectExecutor;
import com.lowdragmc.photon.client.fx.FX;
import com.lowdragmc.photon.client.fx.FXHelper;
import com.realmforge.RealmForgeMod;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/**
 * Client-only bridge to Photon's FX API.
 * FX files live under assets/realmforge/fx/*.fx and are referenced as realmforge:fx/<name>.
 */
public final class PhotonFxClient {
    private PhotonFxClient() {}

    public static void playOnEntity(Entity entity, ResourceLocation fxLoc, int autoRotateOrdinal) {
        if (entity == null || fxLoc == null) return;
        Level level = entity.level();
        if (level == null || !level.isClientSide) return;

        try {
            FX fx = FXHelper.getFX(fxLoc);
            if (fx == null) {
                fx = FXHelper.getFX(fxLoc, true);
            }
            if (fx == null) {
                RealmForgeMod.LOGGER.warn("Photon FX not found: {}", fxLoc);
                return;
            }

            EntityEffectExecutor.AutoRotate rot = EntityEffectExecutor.AutoRotate.NONE;
            EntityEffectExecutor.AutoRotate[] vals = EntityEffectExecutor.AutoRotate.values();
            if (autoRotateOrdinal >= 0 && autoRotateOrdinal < vals.length) {
                rot = vals[autoRotateOrdinal];
            }

            EntityEffectExecutor exec = new EntityEffectExecutor(fx, level, entity, rot);
            exec.setAllowMulti(true);
            exec.start();
        } catch (Throwable t) {
            RealmForgeMod.LOGGER.warn("Failed to play Photon FX {}: {}", fxLoc, t.toString());
        }
    }

    public static void playByUuid(UUID entityId, ResourceLocation fxLoc, int autoRotate) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || entityId == null) return;
        Entity e = null;
        for (Entity ent : mc.level.entitiesForRendering()) {
            if (entityId.equals(ent.getUUID())) {
                e = ent;
                break;
            }
        }
        if (e == null && mc.player != null && entityId.equals(mc.player.getUUID())) {
            e = mc.player;
        }
        playOnEntity(e, fxLoc, autoRotate);
    }
}
