package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.data.RpgData;
import com.realmforge.data.Skill;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

/**
 * Skill Book (key N). Left page: details of the selected skill with TEXT buttons [ EQUIP ] -> [ Z ] [ X ] [ C ].
 * Right page: the five Electro skills (click a name to select) and what is on each key.
 * Locked skills show their unique unlock quest and progress instead of the equip buttons.
 */
public final class SkillBookScreen extends Screen {
   private static final ResourceLocation BOOK = RealmForgeMod.id("textures/gui/rpg_book_background.png");
   private static final ResourceLocation EXIT = RealmForgeMod.id("textures/gui/exit_button.png");
   private static final int INK = -14082024;
   private static final int LEFT_CX = 128;
   private static final int RIGHT_CX = 335;
   private static final String[] KEYS = new String[]{"Z", "X", "C"};
   private static final int K_SELECT = 0;
   private static final int K_EQUIP = 1;
   private static final int K_BIND = 2;
   private static final int K_BACK = 3;
   private int bx;
   private int by;
   private int bw;
   private int bh;
   private int btnW;
   private int btnH;
   private int closeX;
   private int closeY;
   private float scale;
   private int sel;
   private boolean choosing;
   /** Clickable text-button rectangles in book coordinates: x, y, w, h, kind, arg. */
   private final List<int[]> rects = new ArrayList<>();
   private int mx;
   private int my;

   public SkillBookScreen(int page) {
      super(Component.literal("Skill Book"));
      this.sel = Math.max(0, Math.min(Skill.values().length - 1, page));
   }

   @Override
   protected void init() {
      this.clearWidgets();
      this.scale = Math.max(0.25F, Math.min(1.65F, Math.min(((float)this.width - 90.0F) / 463.0F, ((float)this.height - 28.0F) / 301.0F)));
      this.bw = Math.round(463.0F * this.scale);
      this.bh = Math.round(301.0F * this.scale);
      this.bx = (this.width - this.bw) / 2;
      this.by = Math.max(0, (this.height - this.bh) / 2);
      this.btnW = Math.max(22, Math.round(30.0F * this.scale));
      this.btnH = this.btnW;
      this.closeX = Math.min(this.width - this.btnW, this.bx + this.bw - this.btnW / 2);
      this.closeY = Math.max(0, this.by - this.btnH / 2);
      this.addRenderableWidget(Button.builder(Component.empty(), b -> this.onClose()).bounds(this.closeX, this.closeY, this.btnW, this.btnH).build());
   }

   // ---------------------------------------------------------------- text buttons

   /** Draws a clickable text button centred on cx and registers its hit rectangle. */
   private void textButton(GuiGraphics g, String label, int cx, int y, int kind, int arg, boolean selected) {
      int w = this.font.width(label);
      int x = cx - w / 2;
      boolean hover = this.mx >= x - 2 && this.mx <= x + w + 2 && this.my >= y - 2 && this.my <= y + 11;
      ChatFormatting color = selected ? ChatFormatting.GREEN : (hover ? ChatFormatting.GOLD : ChatFormatting.DARK_BLUE);
      MutableComponent c = Component.literal(label).withStyle(color, ChatFormatting.BOLD);
      if (hover) {
         c = c.withStyle(ChatFormatting.UNDERLINE);
      }

      g.drawCenteredString(this.font, c, cx, y, INK);
      this.rects.add(new int[]{x - 2, y - 2, w + 4, 13, kind, arg});
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         double lx = (mouseX - (double)this.bx) / (double)this.scale;
         double ly = (mouseY - (double)this.by) / (double)this.scale;
         for (int[] r : this.rects) {
            if (lx >= (double)r[0] && lx <= (double)(r[0] + r[2]) && ly >= (double)r[1] && ly <= (double)(r[1] + r[3])) {
               this.activate(r[4], r[5]);
               return true;
            }
         }
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   private void activate(int kind, int arg) {
      switch (kind) {
         case K_SELECT -> {
            this.sel = arg;
            this.choosing = false;
         }
         case K_EQUIP -> this.choosing = true;
         case K_BIND -> this.bind(arg);
         default -> this.choosing = false;
      }
   }

   private void bind(int slot) {
      Skill s = Skill.values()[this.sel];
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         mc.player.connection.sendCommand("realmforge skill bind " + (slot + 1) + " " + s.id());
      }

      RpgData d = ClientRpg.data; // optimistic local update; the server sync confirms it
      if (d != null) {
         String previous = d.slots[slot];
         for (int i = 0; i < d.slots.length; i++) {
            if (i != slot && d.slots[i].equals(s.id())) {
               d.slots[i] = previous;
            }
         }

         d.slots[slot] = s.id();
      }

      this.choosing = false;
   }

   private static boolean unlocked(Skill s) {
      return ClientRpg.data != null && ClientRpg.data.isUnlocked(s);
   }

   private static String keysOf(Skill s) {
      RpgData d = ClientRpg.data;
      StringBuilder sb = new StringBuilder();
      if (d != null) {
         for (int i = 0; i < d.slots.length; i++) {
            if (d.slots[i].equals(s.id())) {
               sb.append(sb.length() > 0 ? ", " : "").append(KEYS[i]);
            }
         }
      }

      return sb.length() == 0 ? "not equipped" : sb.toString();
   }

   // ---------------------------------------------------------------- rendering

   private void centered(GuiGraphics g, Component text, int cx, int y) {
      g.drawCenteredString(this.font, text, cx, y, INK);
   }

   private void wrapped(GuiGraphics g, String text, int y, int maxLines) {
      List<FormattedCharSequence> lines = this.font.split(Component.literal(text), 170);
      int n = 0;
      for (FormattedCharSequence line : lines) {
         if (n >= maxLines) {
            break;
         }

         g.drawString(this.font, line, 43, y + n * 11, INK, false);
         n++;
      }
   }

   @Override
   public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
      g.pose().pushPose();
      g.pose().translate((float)this.bx, (float)this.by, 0.0F);
      g.pose().scale(this.scale, this.scale, 1.0F);
      g.blit(BOOK, 0, 0, 0.0F, 0.0F, 463, 301, 463, 301);
      this.rects.clear();
      this.mx = Math.round((float)(mouseX - this.bx) / this.scale);
      this.my = Math.round((float)(mouseY - this.by) / this.scale);
      this.centered(g, Component.literal("SKILL BOOK").withStyle(ChatFormatting.DARK_BLUE), LEFT_CX, 16);
      if (ClientRpg.data == null) {
         this.centered(g, Component.literal("RealmForge data not loaded yet.").withStyle(ChatFormatting.DARK_GRAY), LEFT_CX, 130);
      } else {
         this.drawDetails(g, Skill.values()[this.sel]);
         this.drawList(g);
      }

      g.pose().popPose();
      super.render(g, mouseX, mouseY, delta);
      g.blit(EXIT, this.closeX, this.closeY, 0.0F, 0.0F, this.btnW, this.btnH, this.btnW, this.btnH);
   }

   private void drawDetails(GuiGraphics g, Skill s) {
      RpgData d = ClientRpg.data;
      boolean open = d.isUnlocked(s);
      g.blit(RealmForgeMod.id(s.icon), 83, 32, 0.0F, 0.0F, 90, 90, 90, 90);
      this.centered(g, Component.literal(s.label).withStyle(ChatFormatting.DARK_BLUE, ChatFormatting.BOLD), LEFT_CX, 126);
      ChatFormatting rc = s.rarity.equals("Legendary") ? ChatFormatting.GOLD : (s.rarity.equals("Epic") ? ChatFormatting.DARK_PURPLE : ChatFormatting.BLUE);
      this.centered(g, Component.literal("Rarity: " + s.rarity).withStyle(rc), LEFT_CX, 138);
      this.centered(g, Component.literal(String.format(Locale.ROOT, "Damage: %.1f", s.baseDamage() * d.skillDamageMult(s))), LEFT_CX, 150);
      this.wrapped(g, s.desc, 164, 4);
      this.centered(g, Component.literal("Cost: " + s.energyCost + " energy  |  Cooldown: " + s.cooldownTicks / 20 + "s").withStyle(ChatFormatting.DARK_GRAY), LEFT_CX, 214);
      if (!open) {
         this.centered(g, Component.literal("LOCKED").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), LEFT_CX, 226);
         this.wrapped(g, "Quest: " + s.hint, 238, 2);
         this.centered(g, Component.literal("Progress: " + d.progress(s) + " / " + s.goal + " " + s.unit).withStyle(ChatFormatting.DARK_GREEN), LEFT_CX, 264);
         return;
      }

      this.centered(g, Component.literal("Equipped on: " + keysOf(s)).withStyle(ChatFormatting.DARK_GREEN), LEFT_CX, 226);
      if (!this.choosing) {
         this.textButton(g, "[ EQUIP ]", LEFT_CX, 248, K_EQUIP, 0, false);
      } else {
         this.centered(g, Component.literal("Pick a key").withStyle(ChatFormatting.DARK_GRAY), LEFT_CX, 238);
         for (int i = 0; i < 3; i++) {
            this.textButton(g, "[ " + KEYS[i] + " ]", 88 + i * 40, 250, K_BIND, i, d.slots[i].equals(s.id()));
         }

         this.textButton(g, "[ BACK ]", LEFT_CX, 266, K_BACK, 0, false);
      }
   }

   private void drawList(GuiGraphics g) {
      RpgData d = ClientRpg.data;
      this.centered(g, Component.literal("ELECTRO SKILLS").withStyle(ChatFormatting.DARK_BLUE), RIGHT_CX, 16);
      Skill[] all = Skill.values();
      for (int i = 0; i < all.length; i++) {
         Skill s = all[i];
         int y = 38 + i * 30;
         this.textButton(g, (unlocked(s) ? "" : "(locked) ") + s.label, RIGHT_CX, y, K_SELECT, i, i == this.sel);
         String status = unlocked(s) ? "Unlocked - key: " + keysOf(s) : d.progress(s) + " / " + s.goal + " " + s.unit;
         this.centered(g, Component.literal(status).withStyle(unlocked(s) ? ChatFormatting.DARK_GREEN : ChatFormatting.DARK_GRAY), RIGHT_CX, y + 12);
      }

      for (int i = 0; i < 3; i++) {
         Skill b = Skill.byId(d.slots[i]);
         String name = b == null ? "-" : (unlocked(b) ? b.label : b.label + " (locked)");
         this.centered(g, Component.literal(KEYS[i] + ":  " + name).withStyle(ChatFormatting.DARK_AQUA), RIGHT_CX, 196 + i * 12);
      }

      this.centered(g, Component.literal("Cheat: /realmforge skill unlock all").withStyle(ChatFormatting.DARK_GRAY), RIGHT_CX, 262);
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode != 256 && keyCode != 78) {
         return super.keyPressed(keyCode, scanCode, modifiers);
      }

      this.onClose();
      return true;
   }

   @Override
   public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
