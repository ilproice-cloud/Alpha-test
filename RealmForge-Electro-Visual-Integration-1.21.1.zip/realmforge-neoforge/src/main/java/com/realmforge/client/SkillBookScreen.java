package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.data.RpgData;
import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillRegistry;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

/**
 * Skill book that lists only unlocked skills, allows selecting one,
 * shows name/description, and equips it to Z / X / C slots.
 */
public final class SkillBookScreen extends Screen {
   private static final ResourceLocation BOOK = RealmForgeMod.id("textures/gui/rpg_book_background.png");
   private static final ResourceLocation EXIT = RealmForgeMod.id("textures/gui/exit_button.png");
   private static final int INK = -14082024;
   private static final String[] KEYS = new String[]{"Z", "X", "C"};

   private int bx, by, bw, bh;
   private int btnW, btnH, closeX, closeY;
   private float scale;
   private boolean choosing;
   private final List<int[]> rects = new ArrayList<>();
   private int mx, my;
   private List<SkillDefinition> unlocked = new ArrayList<>();
   private int selected = 0;

   public SkillBookScreen(int page) {
      super(Component.literal("Skill Book"));
   }

   @Override
   protected void init() {
      this.clearWidgets();
      this.scale = Math.max(0.25F, Math.min(1.65F, Math.min(((float)this.width - 90.0F) / 463.0F, ((float)this.height - 28.0F) / 301.0F)));
      this.bw = Math.round(463.0F * this.scale);
      this.bh = Math.round(301.0F * this.scale);
      this.bx = (this.width - this.bw) / 2;
      this.by = Math.max(0, (this.height - this.bh) / 2);
      this.btnW = Math.max(22, Math.round(30.0F * this.scale));
      this.btnH = this.btnW;
      this.closeX = Math.min(this.width - this.btnW, this.bx + this.bw - this.btnW / 2);
      this.closeY = Math.max(0, this.by - this.btnH / 2);
      this.addRenderableWidget(Button.builder(Component.empty(), b -> this.onClose()).bounds(this.closeX, this.closeY, this.btnW, this.btnH).build());
      refreshUnlocked();
   }

   private void refreshUnlocked() {
      this.unlocked.clear();
      RpgData data = ClientRpg.data;
      if (data == null) return;
      for (SkillDefinition s : SkillRegistry.all()) {
         if (s.isUnlocked(data)) {
            this.unlocked.add(s);
         }
      }
      if (this.selected >= this.unlocked.size()) this.selected = Math.max(0, this.unlocked.size() - 1);
   }

   private void textButton(GuiGraphics g, String label, int cx, int y, int id, boolean selected) {
      int w = this.font.width(label);
      int x = cx - w / 2;
      boolean hover = this.mx >= x - 2 && this.mx <= x + w + 2 && this.my >= y - 2 && this.my <= y + 11;
      ChatFormatting color = selected ? ChatFormatting.GREEN : (hover ? ChatFormatting.GOLD : ChatFormatting.DARK_BLUE);
      MutableComponent c = Component.literal(label).withStyle(color, ChatFormatting.BOLD);
      if (hover) c = c.withStyle(ChatFormatting.UNDERLINE);
      g.drawCenteredString(this.font, c, cx, y, INK);
      this.rects.add(new int[]{x - 2, y - 2, w + 4, 13, id});
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         double lx = (mouseX - (double)this.bx) / (double)this.scale;
         double ly = (mouseY - (double)this.by) / (double)this.scale;
         for (int[] r : this.rects) {
            if (lx >= (double)r[0] && lx <= (double)(r[0] + r[2]) && ly >= (double)r[1] && ly <= (double)(r[1] + r[3])) {
               int id = r[4];
               if (id == -1) {
                  this.choosing = true;
               } else if (id >= 100) {
                  // select skill from list
                  this.selected = id - 100;
                  this.choosing = false;
               } else if (id >= 0 && id < 3) {
                  equip(id);
               }
               return true;
            }
         }
      }
      return super.mouseClicked(mouseX, mouseY, button);
   }

   private void equip(int slot) {
      if (this.unlocked.isEmpty() || this.selected < 0 || this.selected >= this.unlocked.size()) return;
      SkillDefinition skill = this.unlocked.get(this.selected);
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         // Use command for server-side persistence
         mc.player.connection.sendCommand("realmforge skill bind " + (slot + 1) + " " + skill.id());
         // optimistic local update
         RpgData data = ClientRpg.data;
         if (data != null) {
            data.setSlotSkill(slot, skill.id());
         }
         this.choosing = false;
      }
   }

   @Override
   public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
      this.mx = (int)((mouseX - this.bx) / this.scale);
      this.my = (int)((mouseY - this.by) / this.scale);
      this.rects.clear();
      refreshUnlocked();

      g.pose().pushPose();
      g.pose().translate(this.bx, this.by, 0);
      g.pose().scale(this.scale, this.scale, 1);
      g.blit(BOOK, 0, 0, 0, 0, 463, 301, 463, 301);

      // Close icon area already has button

      if (this.unlocked.isEmpty()) {
         centered(g, Component.literal("No skills unlocked yet.").withStyle(ChatFormatting.DARK_GRAY), 120);
         centered(g, Component.literal("Use /realmforge skill unlock all").withStyle(ChatFormatting.GRAY), 140);
      } else {
         // Left panel: list of unlocked skills
         int y = 40;
         for (int i = 0; i < this.unlocked.size(); i++) {
            SkillDefinition s = this.unlocked.get(i);
            boolean sel = i == this.selected;
            textButton(g, s.label(), 90, y, 100 + i, sel);
            y += 16;
         }

         // Right panel: selected skill details
         SkillDefinition cur = this.unlocked.get(this.selected);
         centered(g, Component.literal(cur.label()).withStyle(ChatFormatting.DARK_BLUE, ChatFormatting.BOLD), 300);
         wrapped(g, cur.description(), 320);
         centered(g, Component.literal("Cost: " + cur.energyCost() + " energy").withStyle(ChatFormatting.DARK_GRAY), 360);
         centered(g, Component.literal("Cooldown: " + (cur.cooldownTicks() / 20) + "s").withStyle(ChatFormatting.DARK_GRAY), 372);

         RpgData data = ClientRpg.data;
         String[] equipped = new String[3];
         for (int i = 0; i < 3; i++) {
            String id = data != null ? data.getSlotSkill(i) : "";
            SkillDefinition eq = SkillRegistry.get(id);
            equipped[i] = eq != null ? eq.label() : "(empty)";
         }
         centered(g, Component.literal("Z: " + equipped[0]).withStyle(ChatFormatting.GREEN), 400);
         centered(g, Component.literal("X: " + equipped[1]).withStyle(ChatFormatting.GREEN), 412);
         centered(g, Component.literal("C: " + equipped[2]).withStyle(ChatFormatting.GREEN), 424);

         if (!this.choosing) {
            textButton(g, "[ EQUIP ]", 300, 450, -1, false);
         } else {
            centered(g, Component.literal("Pick a key").withStyle(ChatFormatting.DARK_GRAY), 440);
            for (int i = 0; i < 3; i++) {
               textButton(g, "[ " + KEYS[i] + " ]", 250 + i * 50, 455, i, false);
            }
         }
      }

      g.pose().popPose();
      super.render(g, mouseX, mouseY, delta);
   }

   private void centered(GuiGraphics g, Component c, int y) {
      g.drawCenteredString(this.font, c, 300, y, INK);
   }

   private void wrapped(GuiGraphics g, String text, int y) {
      List<FormattedCharSequence> lines = this.font.split(Component.literal(text), 160);
      int n = 0;
      for (FormattedCharSequence line : lines) {
         if (n >= 4) break;
         g.drawString(this.font, line, 220, y + n * 11, INK, false);
         n++;
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256 || keyCode == 78) {
         this.onClose();
         return true;
      }
      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   @Override
   public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {}

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
