package com.realmforge.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public final class JjkAnimatedParticle extends TextureSheetParticle {
   private final SpriteSet sprites;

   private JjkAnimatedParticle(ClientLevel world, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(world, x, y, z, vx, vy, vz);
      this.sprites = sprites;
      this.lifetime = 8;
      this.quadSize = 0.42F;
      this.friction = 0.82F;
      this.setSprite(sprites.get(0, this.lifetime));
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public void tick() {
      super.tick();
      if (!this.removed) {
         this.setSprite(this.sprites.get(this.age, this.lifetime));
      }
   }

   public static final class Factory implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Factory(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel world, double x, double y, double z, double vx, double vy, double vz) {
         return new JjkAnimatedParticle(world, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
