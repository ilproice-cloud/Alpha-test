package com.realmforge.data;

import java.util.Locale;
import net.minecraft.ChatFormatting;

public enum Stat {
   STR("STR", "Strength", ChatFormatting.RED, ChatFormatting.DARK_RED),
   AGI("AGI", "Agility", ChatFormatting.AQUA, ChatFormatting.DARK_AQUA),
   VIT("VIT", "Vitality", ChatFormatting.GREEN, ChatFormatting.DARK_GREEN),
   INT("INT", "Intelligence", ChatFormatting.BLUE, ChatFormatting.DARK_BLUE),
   ENE("ENE", "Energy", ChatFormatting.YELLOW, ChatFormatting.GOLD);

   public final String abbr;
   public final String label;
   public final ChatFormatting color;
   public final ChatFormatting bookColor;

   private Stat(String abbr, String label, ChatFormatting color, ChatFormatting bookColor) {
      this.abbr = abbr;
      this.label = label;
      this.color = color;
      this.bookColor = bookColor;
   }

   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   public static Stat byId(String s) {
      for (Stat st : values()) {
         if (st.id().equalsIgnoreCase(s)) {
            return st;
         }
      }

      return null;
   }
}
