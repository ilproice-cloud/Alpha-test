package com.realmforge.data;

import java.util.function.ToDoubleFunction;
import net.minecraft.nbt.CompoundTag;

/**
 * Per-player RPG data. This class already contains the changes the Fabric
 * "fused" addon applied to it through mixins (clan, Toji set flag, skill slots,
 * rebalanced HP / energy / regen / dodge / EXP formulas).
 */
public final class RpgData {
   public static final int MAX_LEVEL = 100;
   public static final int POINTS_PER_LEVEL = 3;
   public static final int STARTING_POINTS = 5;
   public static final int BASE_ENERGY = 5;
   public static final int HP_PER_VIT = 4;
   public static final int ENERGY_PER_ENE = 5;
   public static final double EXP_GROWTH = 1.2;
   public static final double BASE_EXP = 100.0;
   public static final double STR_PHYS = 0.02;
   public static final double INT_SKILL = 0.03;
   public static final double AGI_SPEED = 0.01;
   public static final double AGI_DODGE = 0.005;
   public static final double ENE_REGEN = 0.1;
   public int level = 1;
   public long exp = 0L;
   public int points = 5;
   public final int[] base = new int[Stat.values().length];
   public float energy = 5.0F;
   public String traitId = "";
   public String perkId = "";
   public int rankIdx = 0;
   public int kills = 0;
   public final int[] skillUses = new int[Skill.values().length];
   public final long[] cdEnd = new long[Skill.values().length];
   public final String[] slots = new String[]{"strong_punch", "uppercut", "barrage"};
   public int[] equip = new int[Stat.values().length];
   public int[] cdRemain = new int[Skill.values().length];
   public boolean syncDirty;

   // ---- addon fields (were mixin-injected) ----
   private String clan;
   private boolean toji;
   private int rolledLevel = -1;
   private final String[] extraSkills = new String[]{"", "", ""};
   /** Bit i set = Skill.values()[i] unlocked. Every skill starts locked. */
   private int unlockMask = 0;
   /** Progress toward each skill's unlock quest (units depend on the skill, see Skill.unit). */
   public final int[] unlockProg = new int[Skill.values().length];

   public boolean isUnlocked(Skill s) {
      return (this.unlockMask & (1 << s.ordinal())) != 0;
   }

   /** @return true if this call newly unlocked the skill. */
   public boolean unlock(Skill s) {
      if (this.isUnlocked(s)) {
         return false;
      }
      this.unlockMask |= 1 << s.ordinal();
      this.unlockProg[s.ordinal()] = s.goal;
      this.syncDirty = true;
      return true;
   }

   public void lock(Skill s) {
      this.unlockMask &= ~(1 << s.ordinal());
      this.unlockProg[s.ordinal()] = 0;
      this.syncDirty = true;
   }

   public int progress(Skill s) {
      return this.isUnlocked(s) ? s.goal : Math.min(s.goal, this.unlockProg[s.ordinal()]);
   }

   /** Adds quest progress. @return true if this addition completed the quest (skill is now unlocked). */
   public boolean addProgress(Skill s, int amount) {
      if (this.isUnlocked(s) || amount <= 0) {
         return false;
      }
      this.unlockProg[s.ordinal()] = Math.min(s.goal, this.unlockProg[s.ordinal()] + amount);
      this.syncDirty = true;
      return this.unlockProg[s.ordinal()] >= s.goal && this.unlock(s);
   }

   public String clan() {
      return this.clan;
   }

   public void setClan(String id) {
      if (this.clan == null || this.clan.isEmpty()) {
         this.clan = id;
      }
   }

   public boolean toji() {
      return this.toji;
   }

   public void setToji(boolean on) {
      this.toji = on;
   }

   public int rolledLevel() {
      return this.rolledLevel;
   }

   public void setRolledLevel(int l) {
      this.rolledLevel = l;
   }

   public String skill(int i) {
      return i >= 0 && i < 3 ? this.extraSkills[i] : "";
   }

   public void setSkill(int i, String s) {
      if (i >= 0 && i < 3) {
         this.extraSkills[i] = s == null ? "" : s;
      }
   }

   private com.realmforge.addon.data.Clan clanType() {
      return com.realmforge.addon.data.Clan.byId(this.clan);
   }

   public Trait trait() {
      return Trait.byId(this.traitId);
   }

   public Perk perk() {
      return Perk.byId(this.perkId);
   }

   public boolean initialized() {
      return this.trait() != null && this.perk() != null;
   }

   public Rank rank() {
      return Rank.values()[Math.min(this.rankIdx, Rank.values().length - 1)];
   }

   public int stat(Stat s) {
      int i = s.ordinal();
      int v = this.base[i] + (i < this.equip.length ? this.equip[i] : 0);
      Trait t = this.trait();
      if (t != null) {
         v += t.effects().stats[i];
      }

      Perk p = this.perk();
      if (p != null) {
         v += p.effects().stats[i];
      }

      return Math.max(0, v);
   }

   public int bonusOf(Stat s) {
      return this.stat(s) - this.base[s.ordinal()];
   }

   private double fx(ToDoubleFunction<Effects> f) {
      double v = 0.0;
      Trait t = this.trait();
      if (t != null) {
         v += f.applyAsDouble(t.effects());
      }

      Perk p = this.perk();
      if (p != null) {
         v += f.applyAsDouble(p.effects());
      }

      return v;
   }

   /** Fused addon: STR no longer gives a % multiplier (it gives flat damage instead, see DamagePipeline). */
   public double physMult() {
      return 1.0;
   }

   public double intSkillMult() {
      return 1.0 + 0.03 * (double)this.stat(Stat.INT);
   }

   public double speedBonus() {
      return Math.min(1.0, 0.01 * (double)this.stat(Stat.AGI));
   }

   public double dodge() {
      double d = Math.max(0.0, 0.005 * (double)this.stat(Stat.AGI) + this.fx(e -> e.dodge));
      return this.toji ? Math.min(1.0, d + 0.2) : Math.min(0.4, d);
   }

   public int maxHealthBonus() {
      return this.stat(Stat.VIT) * 2 + (int)this.fx(e -> (double)e.hp);
   }

   public double dmgOut() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.dmgOut));
   }

   public double dmgIn() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.dmgIn));
   }

   public double expMult() {
      double m = Math.max(0.0, 1.0 + this.fx(e -> e.exp));
      com.realmforge.addon.data.Clan c = this.clanType();
      return c != null ? m * c.expMult : m;
   }

   public double lifesteal() {
      return Math.max(0.0, this.fx(e -> e.lifesteal));
   }

   public double skillBonus() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.skillDmg));
   }

   public float maxEnergy() {
      double m = Math.max(0.1, 1.0 + this.fx(e -> e.energy));
      return (float)Math.max(1.0, (double)(5 + 2 * this.stat(Stat.ENE)) * m);
   }

   public double regenPerSecond() {
      double m = Math.max(0.0, 1.0 + this.fx(e -> e.regen));
      return (1.0 + 0.25 * (double)this.stat(Stat.ENE)) * m;
   }

   public static long expRequired(int level) {
      return Math.round(100.0 * Math.pow(1.2, (double)(level - 1)));
   }

   public long expRequired() {
      return expRequired(this.level);
   }

   /** Fused addon version: clan stat-point multiplier, and +1 to every base stat per level. */
   public int addExp(long amount) {
      if (amount > 0L && this.level < 100) {
         this.exp += amount;
         int gained = 0;
         com.realmforge.addon.data.Clan c = this.clanType();
         int perLevel = (int)Math.round(3.0 * (c == null ? 1.0 : c.statPointMult));

         while (this.level < 100 && this.exp >= expRequired(this.level)) {
            this.exp = this.exp - expRequired(this.level);
            this.level++;
            this.points += perLevel;

            for (int i = 0; i < this.base.length; i++) {
               this.base[i]++;
            }

            gained++;
         }

         if (this.level >= 100) {
            this.exp = 0L;
         }

         this.syncDirty = true;
         return gained;
      } else {
         return 0;
      }
   }

   public boolean spend(Stat s, int n) {
      if (n >= 1 && n <= this.points) {
         this.base[s.ordinal()] += n;
         this.points -= n;
         this.syncDirty = true;
         return true;
      } else {
         return false;
      }
   }

   public int skillLevel(Skill s) {
      return Math.min(10, 1 + this.skillUses[s.ordinal()] / 20);
   }

   public double skillLevelMult(Skill s) {
      return 1.0 + 0.05 * (double)(this.skillLevel(s) - 1);
   }

   public double skillDamageMult(Skill s) {
      double m = this.skillLevelMult(s) * this.skillBonus() * this.intSkillMult();
      if (s.stat == Stat.STR) {
         m *= this.physMult();
      }

      return m;
   }

   public CompoundTag write() {
      CompoundTag n = new CompoundTag();
      n.putInt("level", this.level);
      n.putLong("exp", this.exp);
      n.putInt("points", this.points);
      n.putIntArray("base", this.base);
      n.putFloat("energy", this.energy);
      n.putString("trait", this.traitId);
      n.putString("perk", this.perkId);
      n.putInt("rank", this.rankIdx);
      n.putInt("kills", this.kills);
      n.putIntArray("uses", this.skillUses);
      n.putLongArray("cd", this.cdEnd);

      for (int i = 0; i < this.slots.length; i++) {
         n.putString("slot" + i, this.slots[i]);
      }

      n.putString("rf_clan", this.clan == null ? "" : this.clan);
      n.putInt("rf_unlocked", this.unlockMask);
      n.putIntArray("rf_prog", this.unlockProg);

      for (int i = 0; i < 3; i++) {
         n.putString("rf_skill" + i, this.extraSkills[i]);
      }

      return n;
   }

   public static RpgData read(CompoundTag n) {
      RpgData d = new RpgData();
      if (n.contains("level")) {
         d.level = Math.max(1, Math.min(100, n.getInt("level")));
      }

      d.exp = Math.max(0L, n.getLong("exp"));
      if (n.contains("points")) {
         d.points = Math.max(0, n.getInt("points"));
      }

      copy(n.getIntArray("base"), d.base);
      if (n.contains("energy")) {
         d.energy = n.getFloat("energy");
      }

      d.traitId = n.getString("trait");
      d.perkId = n.getString("perk");
      d.rankIdx = Math.max(0, Math.min(Rank.values().length - 1, n.getInt("rank")));
      d.kills = Math.max(0, n.getInt("kills"));
      copy(n.getIntArray("uses"), d.skillUses);
      long[] cd = n.getLongArray("cd");
      System.arraycopy(cd, 0, d.cdEnd, 0, Math.min(cd.length, d.cdEnd.length));

      for (int i = 0; i < d.slots.length; i++) {
         String s = n.getString("slot" + i);
         if (Skill.byId(s) != null) {
            d.slots[i] = s;
         }
      }

      d.unlockMask = n.getInt("rf_unlocked") & ((1 << Skill.values().length) - 1);
      copy(n.getIntArray("rf_prog"), d.unlockProg);
      String c = n.getString("rf_clan");
      if (!c.isEmpty()) {
         d.setClan(c);
      }

      for (int i = 0; i < 3; i++) {
         d.setSkill(i, n.getString("rf_skill" + i));
      }

      return d;
   }

   public CompoundTag toSync(long worldTime) {
      CompoundTag n = this.write();
      n.putIntArray("equip", this.equip);
      int[] rem = new int[this.cdEnd.length];

      for (int i = 0; i < rem.length; i++) {
         rem[i] = (int)Math.max(0L, this.cdEnd[i] - worldTime);
      }

      n.putIntArray("cdrem", rem);
      return n;
   }

   public static RpgData fromSync(CompoundTag n) {
      RpgData d = read(n);
      copy(n.getIntArray("equip"), d.equip);
      copy(n.getIntArray("cdrem"), d.cdRemain);
      return d;
   }

   private static void copy(int[] src, int[] dst) {
      System.arraycopy(src, 0, dst, 0, Math.min(src.length, dst.length));
   }
}
