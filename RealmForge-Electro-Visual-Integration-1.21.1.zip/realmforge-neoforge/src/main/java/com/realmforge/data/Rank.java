package com.realmforge.data;

import net.minecraft.ChatFormatting;

public enum Rank {
   NOVICE("Novice", "o", 1, 0, ChatFormatting.GRAY, ChatFormatting.DARK_GRAY),
   APPRENTICE("Apprentice", "+", 5, 10, ChatFormatting.GREEN, ChatFormatting.DARK_GREEN),
   ADEPT("Adept", "*", 10, 50, ChatFormatting.AQUA, ChatFormatting.DARK_AQUA),
   VETERAN("Veteran", "#", 20, 150, ChatFormatting.BLUE, ChatFormatting.DARK_BLUE),
   ELITE("Elite", "@", 30, 400, ChatFormatting.LIGHT_PURPLE, ChatFormatting.DARK_PURPLE),
   MASTER("Master", "$", 45, 900, ChatFormatting.GOLD, ChatFormatting.GOLD),
   GRANDMASTER("Grandmaster", "&", 65, 2000, ChatFormatting.RED, ChatFormatting.DARK_RED),
   LEGEND("Legend", "%", 90, 5000, ChatFormatting.YELLOW, ChatFormatting.WHITE);

   public final String label;
   public final String icon;
   public final int minLevel;
   public final int minKills;
   public final ChatFormatting color;
   public final ChatFormatting bookColor;

   private Rank(String label, String icon, int minLevel, int minKills, ChatFormatting color, ChatFormatting bookColor) {
      this.label = label;
      this.icon = icon;
      this.minLevel = minLevel;
      this.minKills = minKills;
      this.color = color;
      this.bookColor = bookColor;
   }

   public static Rank forProgress(int level, int kills) {
      Rank best = NOVICE;

      for (Rank r : values()) {
         if (level >= r.minLevel && kills >= r.minKills) {
            best = r;
         }
      }

      return best;
   }

   public Rank next() {
      return this.ordinal() + 1 < values().length ? values()[this.ordinal() + 1] : null;
   }
}
