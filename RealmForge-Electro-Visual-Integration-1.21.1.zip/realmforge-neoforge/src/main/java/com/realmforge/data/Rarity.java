package com.realmforge.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.ChatFormatting;

public enum Rarity {
   COMMON("Common", ChatFormatting.GRAY, ChatFormatting.DARK_GRAY, 50.0),
   UNCOMMON("Uncommon", ChatFormatting.GREEN, ChatFormatting.DARK_GREEN, 28.0),
   RARE("Rare", ChatFormatting.BLUE, ChatFormatting.DARK_BLUE, 13.0),
   EPIC("Epic", ChatFormatting.DARK_PURPLE, ChatFormatting.DARK_PURPLE, 6.0),
   LEGENDARY("Legendary", ChatFormatting.GOLD, ChatFormatting.GOLD, 2.5),
   MYTHICAL("Mythical", ChatFormatting.RED, ChatFormatting.DARK_RED, 0.5);

   public final String label;
   public final ChatFormatting color;
   public final ChatFormatting bookColor;
   public final double weight;

   private Rarity(String label, ChatFormatting color, ChatFormatting bookColor, double weight) {
      this.label = label;
      this.color = color;
      this.bookColor = bookColor;
      this.weight = weight;
   }

   public static double totalWeight() {
      double t = 0.0;

      for (Rarity r : values()) {
         t += r.weight;
      }

      return t;
   }

   public double chancePercent() {
      return this.weight / totalWeight() * 100.0;
   }

   public static Rarity roll(Random rnd) {
      double x = rnd.nextDouble() * totalWeight();
      double acc = 0.0;

      for (Rarity r : values()) {
         acc += r.weight;
         if (x < acc) {
            return r;
         }
      }

      return COMMON;
   }

   public static <T extends Passive> T pick(T[] all, Random rnd) {
      Rarity r = roll(rnd);
      List<T> pool = new ArrayList<>();

      for (T t : all) {
         if (t.rarity() == r) {
            pool.add(t);
         }
      }

      if (pool.isEmpty()) {
         throw new IllegalStateException("No entries for rarity " + r);
      } else {
         return pool.get(rnd.nextInt(pool.size()));
      }
   }

   public static void validate(Passive[] all, String what) {
      for (Rarity r : values()) {
         boolean found = false;

         for (Passive p : all) {
            if (p.rarity() == r) {
               found = true;
               break;
            }
         }

         if (!found) {
            throw new IllegalStateException(what + " list has no entry for rarity " + r);
         }
      }
   }
}
