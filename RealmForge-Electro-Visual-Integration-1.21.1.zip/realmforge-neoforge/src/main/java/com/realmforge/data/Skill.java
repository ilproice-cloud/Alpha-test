package com.realmforge.data;

import java.util.Locale;

/**
 * The five Electro skills. Enum constant names (STRONG_PUNCH / UPPERCUT / BARRAGE) are legacy ids kept so
 * old save data still loads; the display labels are what players see.
 * Every skill starts LOCKED and has its own unique unlock quest (see {@code SkillUnlocks}).
 */
public enum Skill {
   STRONG_PUNCH("Electro Barrage", "Rapid electrified strikes in a cone in front of you.", "Land 100 punches with an empty hand.", "Rare", 100, 2, 100, Stat.STR, "textures/gui/uppercut.png", 512, 512, "punches"),
   UPPERCUT("Electro Dropkick", "A charged flying dropkick that blasts targets away.", "Survive 5 falls of 12+ blocks.", "Rare", 5, 3, 200, Stat.STR, "textures/gui/electric_drop.png", 32, 32, "falls"),
   BARRAGE("Electro Double Scratch", "Two fast electric claw swipes that hit a cone and knock enemies back.", "Get 15 kills while sprinting.", "Epic", 15, 2, 150, Stat.STR, "textures/item/electro_claws.png", 16, 16, "kills"),
   ELECTRIC_FIELD("Electric Field", "A huge electric shockwave that pulses around you, shocking and slowing everything nearby.", "Stand in the open during a thunderstorm for 8 seconds.", "Epic", 8, 5, 300, Stat.INT, "textures/gui/electric_field.png", 32, 32, "seconds"),
   ELECTRO_FIST("Electro Fist", "A charged thunder punch: rush the target, smash it, and arc lightning to nearby enemies.", "Survive a lightning strike while at 6 hearts or less.", "Legendary", 1, 4, 250, Stat.STR, "textures/gui/strong_punch.png", 512, 512, "strikes");

   public static final int SLOTS = 3;
   public final String label;
   public final String desc;
   public final String hint;
   public final String rarity;
   public final int goal;
   public final int energyCost;
   public final int cooldownTicks;
   public final Stat stat;
   public final String icon;
   public final int iconW;
   public final int iconH;
   public final String unit;

   private Skill(String label, String desc, String hint, String rarity, int goal, int energyCost, int cooldownTicks, Stat stat, String icon, int iconW, int iconH, String unit) {
      this.label = label;
      this.desc = desc;
      this.hint = hint;
      this.rarity = rarity;
      this.goal = goal;
      this.energyCost = energyCost;
      this.cooldownTicks = cooldownTicks;
      this.stat = stat;
      this.icon = icon;
      this.iconW = iconW;
      this.iconH = iconH;
      this.unit = unit;
   }

   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   /** Base damage shown in the Skill Book (total of all hits of one cast, before stat scaling). */
   public double baseDamage() {
      return switch (this) {
         case STRONG_PUNCH -> 8 * 2.2;
         case UPPERCUT -> 9.0;
         case BARRAGE -> 2 * 5.5;
         case ELECTRIC_FIELD -> 3 * 6.0 + 8.0;
         case ELECTRO_FIST -> 16.0;
      };
   }

   public static Skill byId(String id) {
      if (id == null) {
         return null;
      } else {
         for (Skill s : values()) {
            if (s.id().equalsIgnoreCase(id)) {
               return s;
            }
         }

         String key = id.toLowerCase(Locale.ROOT).replace(' ', '_');
         return switch (key) {
            case "power_strike", "electro_barrage" -> STRONG_PUNCH;
            case "dash", "electro_dropkick", "dropkick" -> UPPERCUT;
            case "arcane_bolt", "mend", "electro_double_scratch", "double_scratch" -> BARRAGE;
            case "electro_field" -> ELECTRIC_FIELD;
            case "fist", "electro_fist_skill" -> ELECTRO_FIST;
            default -> null;
         };
      }
   }
}
