package com.realmforge.data;

public interface Passive {
   String id();

   String displayName();

   Rarity rarity();

   String description();

   Effects effects();
}
