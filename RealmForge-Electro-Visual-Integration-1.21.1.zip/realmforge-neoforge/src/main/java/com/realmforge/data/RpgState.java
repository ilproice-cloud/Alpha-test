package com.realmforge.data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

public class RpgState extends SavedData {
   public static final SavedData.Factory<RpgState> FACTORY = new SavedData.Factory<>(RpgState::new, RpgState::load, null);
   private final Map<UUID, RpgData> players = new HashMap<>();

   public RpgData get(UUID id) {
      return this.players.computeIfAbsent(id, k -> new RpgData());
   }

   public void remove(UUID id) {
      this.players.remove(id);
   }

   @Override
   public CompoundTag save(CompoundTag nbt, HolderLookup.Provider lookup) {
      CompoundTag all = new CompoundTag();
      this.players.forEach((id, d) -> all.put(id.toString(), d.write()));
      nbt.put("players", all);
      return nbt;
   }

   public static RpgState load(CompoundTag nbt, HolderLookup.Provider lookup) {
      RpgState s = new RpgState();
      CompoundTag all = nbt.getCompound("players");

      for (String key : all.getAllKeys()) {
         try {
            s.players.put(UUID.fromString(key), RpgData.read(all.getCompound(key)));
         } catch (IllegalArgumentException ignored) {
         }
      }

      return s;
   }
}
