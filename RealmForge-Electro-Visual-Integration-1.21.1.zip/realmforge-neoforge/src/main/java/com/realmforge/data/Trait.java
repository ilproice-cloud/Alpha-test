package com.realmforge.data;

import java.util.Locale;

public enum Trait implements Passive {
   BRAWLER("Brawler", Rarity.COMMON, "Fights first, thinks later.", Effects.of().stat(Stat.STR, 2).stat(Stat.AGI, -1)),
   BOOKWORM("Bookworm", Rarity.COMMON, "Always has a book nearby.", Effects.of().stat(Stat.INT, 2).stat(Stat.VIT, -1)),
   QUICK_LEARNER("Quick Learner", Rarity.UNCOMMON, "Learns fast, hits soft.", Effects.of().exp(0.15).dmgOut(-0.05)),
   STEADY_BREATH("Steady Breath", Rarity.UNCOMMON, "Calm and collected.", Effects.of().regen(0.25).stat(Stat.STR, -1)),
   IRON_CONSTITUTION("Iron Constitution", Rarity.RARE, "Hard to put down.", Effects.of().stat(Stat.VIT, 3).dmgIn(-0.05).stat(Stat.AGI, -1)),
   DUELIST("Duelist", Rarity.RARE, "Precise and fragile.", Effects.of().dodge(0.06).dmgOut(0.05).stat(Stat.VIT, -2)),
   ARCANE_VESSEL("Arcane Vessel", Rarity.EPIC, "Overflowing with power.", Effects.of().stat(Stat.INT, 4).stat(Stat.ENE, 3).dmgIn(0.08)),
   BLOODTHIRSTY("Bloodthirsty", Rarity.EPIC, "Heals by hurting.", Effects.of().stat(Stat.STR, 3).lifesteal(0.05).dmgIn(0.05)),
   WARBORN("Warborn", Rarity.LEGENDARY, "Born on a battlefield.", Effects.of().stat(Stat.STR, 5).stat(Stat.VIT, 3).exp(-0.1)),
   WINDWALKER("Windwalker", Rarity.LEGENDARY, "Light as the wind.", Effects.of().stat(Stat.AGI, 6).dodge(0.08).stat(Stat.VIT, -2)),
   CHOSEN_ONE("Chosen One", Rarity.MYTHICAL, "Fate itself takes notice.", Effects.of().all(3).exp(0.25).dmgOut(0.1).dmgIn(0.1));

   private final String display;
   private final String desc;
   private final Rarity rarity;
   private final Effects fx;

   private Trait(String display, Rarity r, String desc, Effects fx) {
      this.display = display;
      this.rarity = r;
      this.desc = desc;
      this.fx = fx;
   }

   @Override
   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   @Override
   public String displayName() {
      return this.display;
   }

   @Override
   public Rarity rarity() {
      return this.rarity;
   }

   @Override
   public String description() {
      return this.desc;
   }

   @Override
   public Effects effects() {
      return this.fx;
   }

   public static Trait byId(String id) {
      if (id == null) {
         return null;
      } else {
         for (Trait t : values()) {
            if (t.id().equalsIgnoreCase(id)) {
               return t;
            }
         }

         return null;
      }
   }
}
