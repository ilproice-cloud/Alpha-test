package com.realmforge.addon.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import com.realmforge.addon.data.Clan;
import com.realmforge.data.RpgData;
import java.util.List;

public final class ClanPage {
   private ClanPage() {
   }

   private static MutableComponent head(String title) {
      return Component.literal(title + "\n")
         .withStyle(new ChatFormatting[]{ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD})
         .append(Component.literal("[ BACK TO INFORMATION ]").withStyle(new ChatFormatting[]{ChatFormatting.DARK_GRAY, ChatFormatting.BOLD}))
         .append(Component.literal("\n\n"));
   }

   public static List<Component> pages(RpgData d) {
      Clan c = d == null ? null : Clan.byId(d.clan());
      MutableComponent a = head("CLAN");
      MutableComponent b = head("CLAN PERKS");
      if (c == null) {
         a.append(Component.literal("You have no clan yet.\n").withStyle(ChatFormatting.DARK_GRAY));
         a.append(Component.literal("Clans are obtained randomly and are permanent.\n\n").withStyle(ChatFormatting.DARK_GRAY));
         a.append(Component.literal(Clan.SHIROGANE.display + " ").withStyle(new ChatFormatting[]{ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD}))
            .append(Component.literal("[" + Clan.SHIROGANE.rarity.label + "]").withStyle(Clan.SHIROGANE.rarity.bookColor));
         b.append(Component.literal("Shirogane perks:\n").withStyle(new ChatFormatting[]{ChatFormatting.DARK_GREEN, ChatFormatting.BOLD}));

         for (String p : Clan.SHIROGANE.perks) {
            b.append(Component.literal(" + " + p + "\n").withStyle(ChatFormatting.DARK_GREEN));
         }

         return List.of(a, b);
      } else {
         a.append(Component.literal(c.display + "\n").withStyle(new ChatFormatting[]{c.rarity.bookColor, ChatFormatting.BOLD}));
         a.append(Component.literal("Rarity: ").withStyle(ChatFormatting.DARK_GRAY))
            .append(Component.literal(c.rarity.label + "\n\n").withStyle(c.rarity.bookColor));
         a.append(Component.literal(c.flavor + "\n\n").withStyle(new ChatFormatting[]{ChatFormatting.GRAY, ChatFormatting.ITALIC}));
         a.append(Component.literal("Permanent. Cannot be changed.").withStyle(ChatFormatting.DARK_RED));
         b.append(Component.literal("Traits & Perks\n").withStyle(new ChatFormatting[]{ChatFormatting.DARK_GREEN, ChatFormatting.BOLD}));

         for (String p : c.perks) {
            b.append(Component.literal(" + " + p + "\n").withStyle(ChatFormatting.DARK_GREEN));
         }

         return List.of(a, b);
      }
   }
}

