package com.realmforge.addon.anim;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;

/**
 * Plays Blockbench-style skill animation clips on player models. Called from
 * HumanoidModelMixin after vanilla poses the model. (The Fabric build reached
 * model fields via reflection; on NeoForge the fields are accessed directly.)
 */
public final class AnimClient {
   private static final String[] FILES = new String[]{"electro_dropkick_pawdash", "electro_double_scratch_violentthrash", "electric_field_countershock", "electro_fist_countershockow", "electro_dropkick_dash", "rushdownbarrage"};
   // violentthrash is a 6.5 s clip; 3.5x makes the Double Scratch pose last ~1.9 s. Tune here.
   private static final float[] SPEED = new float[]{1.0F, 3.5F, 1.0F, 1.0F, 1.0F, 1.0F};
   private static final float[] ROT_SIGN = new float[]{1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F};
   private static final float[] POS_SIGN = new float[]{1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F};
   private static final Map<UUID, Active> ACTIVE = new ConcurrentHashMap<>();
   private static final Clip[] CLIPS = new Clip[FILES.length];
   private static final String[] BONES = new String[]{"head", "body", "right_arm", "left_arm", "right_leg", "left_leg"};

   private AnimClient() {
   }

   public static void clear() {
      ACTIVE.clear();
   }

   public static void play(UUID player, int anim) {
      if (anim >= 0 && anim < FILES.length) {
         Clip clip = CLIPS[anim];
         if (clip == null) {
            clip = Clip.load(FILES[anim]);
            CLIPS[anim] = clip;
         }

         if (clip != null) {
            ACTIVE.put(player, new Active(clip, System.nanoTime(), SPEED[anim]));
         }
      }
   }

   private static ModelPart part(HumanoidModel<?> m, int i) {
      return switch (i) {
         case 0 -> m.head;
         case 1 -> m.body;
         case 2 -> m.rightArm;
         case 3 -> m.leftArm;
         case 4 -> m.rightLeg;
         default -> m.leftLeg;
      };
   }

   public static void apply(HumanoidModel<?> model, UUID player) {
      if (ACTIVE.isEmpty() || player == null) {
         return;
      }

      Active a = ACTIVE.get(player);
      if (a == null) {
         return;
      }

      float t = (float)(System.nanoTime() - a.start) / 1.0E9F * a.speed;
      if (t > a.clip.length) {
         ACTIVE.remove(player, a);
         return;
      }

      float[] v = new float[3];

      for (int i = 0; i < BONES.length; i++) {
         ModelPart p = part(model, i);
         Clip.Track rot = a.clip.rot.get(BONES[i]);
         if (rot != null) {
            rot.sample(t, v);
            p.xRot = (float)Math.toRadians((double)(v[0] * ROT_SIGN[0]));
            p.yRot = (float)Math.toRadians((double)(v[1] * ROT_SIGN[1]));
            p.zRot = (float)Math.toRadians((double)(v[2] * ROT_SIGN[2]));
         }

         Clip.Track pos = a.clip.pos.get(BONES[i]);
         if (pos != null) {
            pos.sample(t, v);
            p.x += v[0] * POS_SIGN[0];
            p.y += v[1] * POS_SIGN[1];
            p.z += v[2] * POS_SIGN[2];
         }
      }
   }

   private static final class Active {
      final Clip clip;
      final long start;
      final float speed;

      Active(Clip clip, long start, float speed) {
         this.clip = clip;
         this.start = start;
         this.speed = speed;
      }
   }
}
