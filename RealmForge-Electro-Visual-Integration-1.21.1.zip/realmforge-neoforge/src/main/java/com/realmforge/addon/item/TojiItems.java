package com.realmforge.addon.item;

import com.realmforge.RealmForgeMod;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** "Sorcerer Killer" (Toji) armor set + cloth item. */
public final class TojiItems {
   public static final String ID = "sorcerer_killer";
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RealmForgeMod.MOD_ID);
   public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS = DeferredRegister.create(Registries.ARMOR_MATERIAL, RealmForgeMod.MOD_ID);

   public static final DeferredHolder<ArmorMaterial, ArmorMaterial> MATERIAL = ARMOR_MATERIALS.register(ID, () -> {
      EnumMap<ArmorItem.Type, Integer> defense = new EnumMap<>(ArmorItem.Type.class);
      defense.put(ArmorItem.Type.BOOTS, 3);
      defense.put(ArmorItem.Type.LEGGINGS, 6);
      defense.put(ArmorItem.Type.CHESTPLATE, 8);
      defense.put(ArmorItem.Type.HELMET, 3);
      defense.put(ArmorItem.Type.BODY, 0);
      return new ArmorMaterial(
         defense,
         15,
         SoundEvents.ARMOR_EQUIP_GENERIC,
         () -> Ingredient.EMPTY,
         List.of(new ArmorMaterial.Layer(RealmForgeMod.id(ID))),
         3.0F,
         0.1F
      );
   });

   public static final DeferredItem<ArmorItem> SHIRT = ITEMS.register(
      "sorcerer_killer_armor_chestplate",
      () -> new ArmorItem(MATERIAL, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1).durability(ArmorItem.Type.CHESTPLATE.getDurability(500)))
   );
   public static final DeferredItem<ArmorItem> PANTS = ITEMS.register(
      "sorcerer_killer_armor_leggings",
      () -> new ArmorItem(MATERIAL, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1).durability(ArmorItem.Type.LEGGINGS.getDurability(500)))
   );
   public static final DeferredItem<ArmorItem> BOOTS = ITEMS.register(
      "sorcerer_killer_armor_boots",
      () -> new ArmorItem(MATERIAL, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1).durability(ArmorItem.Type.BOOTS.getDurability(500)))
   );
   public static final DeferredItem<Item> CLOTH = ITEMS.register(
      "sorcerer_killer_cloth", () -> new Item(new Item.Properties().stacksTo(16).rarity(Rarity.RARE))
   );

   private TojiItems() {
   }
}
