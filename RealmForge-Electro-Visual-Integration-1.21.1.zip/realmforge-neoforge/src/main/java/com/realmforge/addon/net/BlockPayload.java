package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: block key pressed / released. */
public record BlockPayload(boolean active) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<BlockPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("block"));
   public static final StreamCodec<ByteBuf, BlockPayload> CODEC = ByteBufCodecs.BOOL.map(BlockPayload::new, BlockPayload::active);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
