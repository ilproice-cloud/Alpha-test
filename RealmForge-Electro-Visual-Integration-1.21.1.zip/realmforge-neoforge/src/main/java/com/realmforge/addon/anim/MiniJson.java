package com.realmforge.addon.anim;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class MiniJson {
   private final String s;
   private int i;

   private MiniJson(String var1) {
      this.s = var1;
   }

   static Object parse(String var0) {
      MiniJson var1 = new MiniJson(var0);
      var1.ws();
      return var1.value();
   }

   private void ws() {
      while (this.i < this.s.length() && Character.isWhitespace(this.s.charAt(this.i))) {
         this.i++;
      }
   }

   private Object value() {
      this.ws();
      char var1 = this.s.charAt(this.i);
      if (var1 == '{') {
         return this.obj();
      } else if (var1 == '[') {
         return this.arr();
      } else if (var1 == '"') {
         return this.str();
      } else if (this.s.startsWith("true", this.i)) {
         this.i += 4;
         return Boolean.TRUE;
      } else if (this.s.startsWith("false", this.i)) {
         this.i += 5;
         return Boolean.FALSE;
      } else if (this.s.startsWith("null", this.i)) {
         this.i += 4;
         return null;
      } else {
         int var2 = this.i;

         while (this.i < this.s.length() && "+-0123456789.eE".indexOf(this.s.charAt(this.i)) >= 0) {
            this.i++;
         }

         return Double.parseDouble(this.s.substring(var2, this.i));
      }
   }

   private Map<String, Object> obj() {
      LinkedHashMap var1 = new LinkedHashMap();
      this.i++;
      this.ws();
      if (this.s.charAt(this.i) == '}') {
         this.i++;
         return var1;
      } else {
         char var3;
         do {
            this.ws();
            String var2 = this.str();
            this.ws();
            this.i++;
            var1.put(var2, this.value());
            this.ws();
            var3 = this.s.charAt(this.i++);
         } while (var3 != '}');

         return var1;
      }
   }

   private List<Object> arr() {
      ArrayList var1 = new ArrayList();
      this.i++;
      this.ws();
      if (this.s.charAt(this.i) == ']') {
         this.i++;
         return var1;
      } else {
         char var2;
         do {
            var1.add(this.value());
            this.ws();
            var2 = this.s.charAt(this.i++);
         } while (var2 != ']');

         return var1;
      }
   }

   private String str() {
      StringBuilder var1 = new StringBuilder();
      this.i++;

      while (true) {
         char var2 = this.s.charAt(this.i++);
         if (var2 == '"') {
            return var1.toString();
         }

         if (var2 == '\\') {
            char var3 = this.s.charAt(this.i++);
            switch (var3) {
               case 'n':
                  var1.append('\n');
                  break;
               case 'o':
               case 'p':
               case 'q':
               case 's':
               default:
                  var1.append(var3);
                  break;
               case 'r':
                  var1.append('\r');
                  break;
               case 't':
                  var1.append('\t');
                  break;
               case 'u':
                  var1.append((char)Integer.parseInt(this.s.substring(this.i, this.i + 4), 16));
                  this.i += 4;
            }
         } else {
            var1.append(var2);
         }
      }
   }
}
