package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: another (or the same) player started / stopped blocking. */
public record BlockStatePayload(UUID player, boolean active) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<BlockStatePayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("block_state"));
   public static final StreamCodec<ByteBuf, BlockStatePayload> CODEC = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC, BlockStatePayload::player, ByteBufCodecs.BOOL, BlockStatePayload::active, BlockStatePayload::new
   );

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
