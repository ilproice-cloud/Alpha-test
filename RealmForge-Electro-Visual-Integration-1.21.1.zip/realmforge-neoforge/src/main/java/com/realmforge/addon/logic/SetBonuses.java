package com.realmforge.addon.logic;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.item.TojiItems;
import com.realmforge.data.RpgData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

public final class SetBonuses {
   public static final double DEFENSE = 20.0;
   public static final double SPEED = 0.5;
   public static final double STRENGTH = 0.75;
   public static final double DODGE = 1.5;
   private static final ResourceLocation ARMOR_ID = RealmForgeMod.id("toji_defense");
   private static final ResourceLocation SPEED_ID = RealmForgeMod.id("toji_speed");

   private SetBonuses() {
   }

   public static boolean hasTojiSet(Player p) {
      return p.getItemBySlot(EquipmentSlot.CHEST).is(TojiItems.SHIRT.get())
         && p.getItemBySlot(EquipmentSlot.LEGS).is(TojiItems.PANTS.get())
         && p.getItemBySlot(EquipmentSlot.FEET).is(TojiItems.BOOTS.get());
   }

   public static void update(ServerPlayer p, RpgData d) {
      boolean on = hasTojiSet(p);
      d.setToji(on);
      mod(p.getAttribute(Attributes.ARMOR), ARMOR_ID, 20.0, AttributeModifier.Operation.ADD_VALUE, on);
      mod(p.getAttribute(Attributes.MOVEMENT_SPEED), SPEED_ID, 0.5, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL, on);
   }

   private static void mod(AttributeInstance inst, ResourceLocation id, double v, AttributeModifier.Operation op, boolean on) {
      if (inst != null) {
         boolean has = inst.getModifier(id) != null;
         if (on && !has) {
            inst.addTransientModifier(new AttributeModifier(id, v, op));
         } else if (!on && has) {
            inst.removeModifier(id);
         }
      }
   }

   public static boolean cancelsFall(Player p, DamageSource src) {
      return hasTojiSet(p) && src.is(DamageTypeTags.IS_FALL);
   }
}
