package com.realmforge.addon.logic;

import com.realmforge.addon.net.BlockStatePayload;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.PacketDistributor;

public final class BlockingManager {
   public static final float REDUCTION = 0.5F;
   private static final Set<UUID> BLOCKING = ConcurrentHashMap.newKeySet();

   private BlockingManager() {
   }

   public static boolean isBlocking(LivingEntity e) {
      return BLOCKING.contains(e.getUUID());
   }

   public static void set(ServerPlayer p, boolean on) {
      boolean changed = on ? BLOCKING.add(p.getUUID()) : BLOCKING.remove(p.getUUID());
      if (changed) {
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(p, new BlockStatePayload(p.getUUID(), on));
      }
   }

   /** Called on server tick: stop blocking for dead / spectating players. */
   public static void tick(Iterable<ServerPlayer> players) {
      for (ServerPlayer p : players) {
         if (BLOCKING.contains(p.getUUID()) && (!p.isAlive() || p.isSpectator())) {
            set(p, false);
         }
      }
   }

   /** Called when a player joins: tell them who is currently blocking. */
   public static void sendAllTo(ServerPlayer joiner) {
      for (UUID id : BLOCKING) {
         PacketDistributor.sendToPlayer(joiner, new BlockStatePayload(id, true));
      }
   }

   public static float apply(LivingEntity victim, DamageSource src, float amount) {
      if (!isBlocking(victim)) {
         return amount;
      }

      return !src.is(DamageTypes.FELL_OUT_OF_WORLD) && !src.is(DamageTypes.GENERIC_KILL) ? amount * 0.5F : amount;
   }
}
