package com.realmforge.addon.anim;

/** Animation ids understood by {@link AnimClient} / {@link AnimNet#broadcast}. Same order as AnimClient.FILES. */
public final class SkillAnims {
   public static final int DROPKICK = 0;   // electro_dropkick_pawdash
   public static final int SCRATCH = 1;    // electro_double_scratch_violentthrash
   public static final int FIELD = 2;      // electric_field_countershock
   public static final int FIST = 3;       // electro_fist_countershockow
   public static final int DASH = 4;       // electro_dropkick_dash
   public static final int BARRAGE = 5;    // rushdownbarrage

   private SkillAnims() {
   }
}
