package com.realmforge.addon.data;

import com.realmforge.data.Rarity;
import java.util.Random;

public enum Clan {
   SHIROGANE("shirogane", "Shirogane", Rarity.MYTHICAL, 2.0, 1.5, "An ancient and extremely rare bloodline.", "x2 Stat Points", "x1.5 EXP");

   public static final double ROLL_CHANCE_PERCENT = 100.0;
   public final String id;
   public final String display;
   public final String flavor;
   public final Rarity rarity;
   public final double statPointMult;
   public final double expMult;
   public final String[] perks;

   Clan(String id, String display, Rarity rarity, double statPointMult, double expMult, String flavor, String... perks) {
      this.id = id;
      this.display = display;
      this.rarity = rarity;
      this.statPointMult = statPointMult;
      this.expMult = expMult;
      this.flavor = flavor;
      this.perks = perks;
   }

   public static Clan byId(String id) {
      if (id == null || id.isEmpty()) {
         return null;
      }

      for (Clan c : values()) {
         if (c.id.equals(id)) {
            return c;
         }
      }

      return null;
   }

   public static Clan roll(Random rnd) {
      for (Clan c : values()) {
         if (rnd.nextDouble() * 100.0 < ROLL_CHANCE_PERCENT) {
            return c;
         }
      }

      return null;
   }
}
