package com.realmforge.addon.client;

import com.realmforge.addon.net.BlockPayload;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.network.PacketDistributor;

public final class BlockingClient {
   /** Hold F (default) to block. */
   public static final KeyMapping BLOCK = new KeyMapping("key.realmforge.block", 70, "key.categories.realmforge");
   private static final Set<UUID> BLOCKING = ConcurrentHashMap.newKeySet();
   private static boolean sent;

   private BlockingClient() {
   }

   public static boolean isBlocking(UUID id) {
      return BLOCKING.contains(id);
   }

   public static void set(UUID id, boolean active) {
      if (active) {
         BLOCKING.add(id);
      } else {
         BLOCKING.remove(id);
      }
   }

   public static void clear() {
      BLOCKING.clear();
      sent = false;
   }

   public static void tick(Minecraft mc) {
      boolean down = mc.player != null && mc.screen == null && BLOCK.isDown();
      if (down != sent) {
         sent = down;
         PacketDistributor.sendToServer(new BlockPayload(down));
      }
   }
}
