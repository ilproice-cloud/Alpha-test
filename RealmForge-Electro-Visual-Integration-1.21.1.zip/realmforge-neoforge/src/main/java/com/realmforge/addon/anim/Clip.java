package com.realmforge.addon.anim;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A Blockbench-style animation clip: per-bone rotation / position keyframe tracks. */
final class Clip {
   final float length;
   final Map<String, Track> rot = new HashMap<>();
   final Map<String, Track> pos = new HashMap<>();

   private Clip(float length) {
      this.length = length;
   }

   @SuppressWarnings("unchecked")
   static Clip load(String name) {
      try (InputStream in = Clip.class.getResourceAsStream("/assets/realmforge/player_animation/" + name + ".json")) {
         if (in == null) {
            return null;
         }

         Map<String, Object> root = (Map<String, Object>)MiniJson.parse(new String(in.readAllBytes(), StandardCharsets.UTF_8));
         Map<String, Object> animations = (Map<String, Object>)root.get("animations");
         Map<String, Object> anim = (Map<String, Object>)animations.values().iterator().next();
         Clip clip = new Clip(((Number)anim.get("animation_length")).floatValue());
         Map<String, Object> bones = (Map<String, Object>)anim.get("bones");

         for (Map.Entry<String, Object> e : bones.entrySet()) {
            Map<String, Object> bone = (Map<String, Object>)e.getValue();
            Track r = track(bone.get("rotation"));
            Track p = track(bone.get("position"));
            if (r != null) {
               clip.rot.put(e.getKey(), r);
            }

            if (p != null) {
               clip.pos.put(e.getKey(), p);
            }
         }

         return clip;
      } catch (Throwable t) {
         return null;
      }
   }

   @SuppressWarnings("unchecked")
   private static Track track(Object o) {
      if (!(o instanceof Map<?, ?> raw)) {
         return null;
      }

      Map<String, Object> m = (Map<String, Object>)raw;
      if (m.containsKey("vector")) {
         return new Track(new float[]{0.0F}, new float[][]{vec(m.get("vector"))});
      }

      List<float[]> keys = new ArrayList<>();

      for (Map.Entry<String, Object> e : m.entrySet()) {
         float time;
         try {
            time = Float.parseFloat(e.getKey());
         } catch (NumberFormatException ex) {
            continue;
         }

         Object v = e.getValue();
         if (v instanceof Map<?, ?> vm) {
            Map<String, Object> frame = (Map<String, Object>)vm;
            v = frame.containsKey("vector") ? frame.get("vector") : (frame.containsKey("post") ? frame.get("post") : frame.get("pre"));
         }

         float[] xyz = vec(v);
         keys.add(new float[]{time, xyz[0], xyz[1], xyz[2]});
      }

      if (keys.isEmpty()) {
         return null;
      }

      keys.sort((a, b) -> Float.compare(a[0], b[0]));
      float[] times = new float[keys.size()];
      float[][] vals = new float[keys.size()][];

      for (int i = 0; i < times.length; i++) {
         float[] k = keys.get(i);
         times[i] = k[0];
         vals[i] = new float[]{k[1], k[2], k[3]};
      }

      return new Track(times, vals);
   }

   private static float[] vec(Object o) {
      List<?> list = (List<?>)o;
      float[] out = new float[3];

      for (int i = 0; i < 3 && i < list.size(); i++) {
         Object x = list.get(i);
         out[i] = x instanceof Number n ? n.floatValue() : 0.0F;
      }

      return out;
   }

   static final class Track {
      final float[] times;
      final float[][] vals;

      Track(float[] times, float[][] vals) {
         this.times = times;
         this.vals = vals;
      }

      void sample(float t, float[] out) {
         int n = this.times.length;
         if (n == 1 || t <= this.times[0]) {
            copy(this.vals[0], out);
         } else if (t >= this.times[n - 1]) {
            copy(this.vals[n - 1], out);
         } else {
            int i = 0;

            while (i < n - 2 && t >= this.times[i + 1]) {
               i++;
            }

            float span = this.times[i + 1] - this.times[i];
            float f = span <= 0.0F ? 0.0F : (t - this.times[i]) / span;

            for (int k = 0; k < 3; k++) {
               out[k] = this.vals[i][k] + (this.vals[i + 1][k] - this.vals[i][k]) * f;
            }
         }
      }

      private static void copy(float[] src, float[] dst) {
         dst[0] = src[0];
         dst[1] = src[1];
         dst[2] = src[2];
      }
   }
}
