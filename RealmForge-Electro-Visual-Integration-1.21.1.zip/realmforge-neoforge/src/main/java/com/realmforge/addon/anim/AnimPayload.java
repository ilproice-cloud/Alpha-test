package com.realmforge.addon.anim;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: play skill animation {@code anim} on player {@code player}. */
public record AnimPayload(UUID player, int anim) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<AnimPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("skill_anim"));
   public static final StreamCodec<ByteBuf, AnimPayload> CODEC = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC, AnimPayload::player, ByteBufCodecs.INT, AnimPayload::anim, AnimPayload::new
   );

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
