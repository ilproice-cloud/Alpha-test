package com.realmforge.skill.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.anim.Clip;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Loads a Bedrock {@code .geo.json} (format 1.12.0, box-UV cubes) into a vanilla {@link ModelPart} tree so the
 * ORIGINAL model files can be rendered without GeckoLib. Axis mapping: model X/Y are negated relative to Bedrock
 * because the renderer flips the pose stack by (-1,-1,1), exactly like vanilla living renderers.
 */
public final class GeoModel {
   public final ModelPart root;
   private final Map<String, ModelPart> bones = new LinkedHashMap<>();
   private final Map<String, float[]> rest = new LinkedHashMap<>();

   private GeoModel(ModelPart root) {
      this.root = root;
   }

   public static GeoModel load(ResourceLocation geoFile) {
      try {
         var res = Minecraft.getInstance().getResourceManager().getResource(geoFile).orElse(null);
         if (res == null) {
            RealmForgeMod.LOGGER.error("Geo model not found: {}", geoFile);
            return null;
         }

         try (InputStream in = res.open()) {
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject geo = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
            JsonObject desc = geo.getAsJsonObject("description");
            int tw = desc.get("texture_width").getAsInt();
            int th = desc.get("texture_height").getAsInt();
            MeshDefinition mesh = new MeshDefinition();
            Map<String, float[]> pivots = new LinkedHashMap<>();
            Map<String, PartDefinition> defs = new LinkedHashMap<>();
            Map<String, float[]> restPose = new LinkedHashMap<>();
            int cubeId = 0;
            for (JsonElement be : geo.getAsJsonArray("bones")) {
               JsonObject b = be.getAsJsonObject();
               String name = b.get("name").getAsString();
               float[] pv = arr(b.get("pivot"), 3);
               float[] rot = b.has("rotation") ? arr(b.get("rotation"), 3) : new float[3];
               String parent = b.has("parent") ? b.get("parent").getAsString() : null;
               PartDefinition parentDef = parent != null && defs.containsKey(parent) ? defs.get(parent) : mesh.getRoot();
               float[] pp = parent != null && pivots.containsKey(parent) ? pivots.get(parent) : new float[3];
               // bone pose relative to its parent, in model space (x,y negated)
               float ox = -(pv[0] - pp[0]);
               float oy = -(pv[1] - pp[1]);
               float oz = pv[2] - pp[2];
               PartPose pose = PartPose.offsetAndRotation(ox, oy, oz, rad(-rot[0]), rad(-rot[1]), rad(rot[2]));
               PartDefinition boneDef = parentDef.addOrReplaceChild(name, CubeListBuilder.create(), pose);
               defs.put(name, boneDef);
               pivots.put(name, pv);
               restPose.put(name, new float[]{ox, oy, oz, rad(-rot[0]), rad(-rot[1]), rad(rot[2])});
               if (b.has("cubes")) {
                  for (JsonElement ce : b.getAsJsonArray("cubes")) {
                     JsonObject c = ce.getAsJsonObject();
                     float[] o = arr(c.get("origin"), 3);
                     float[] s = arr(c.get("size"), 3);
                     float[] uv = c.has("uv") && c.get("uv").isJsonArray() ? arr(c.get("uv"), 2) : new float[2];
                     float[] cp = c.has("pivot") ? arr(c.get("pivot"), 3) : pv;
                     float[] cr = c.has("rotation") ? arr(c.get("rotation"), 3) : new float[3];
                     float inflate = c.has("inflate") ? c.get("inflate").getAsFloat() : 0.0F;
                     CubeListBuilder cube = CubeListBuilder.create()
                        .texOffs((int)uv[0], (int)uv[1])
                        .addBox(cp[0] - o[0] - s[0], cp[1] - o[1] - s[1], o[2] - cp[2], s[0], s[1], s[2], new net.minecraft.client.model.geom.builders.CubeDeformation(inflate));
                     PartPose cpose = PartPose.offsetAndRotation(-(cp[0] - pv[0]), -(cp[1] - pv[1]), cp[2] - pv[2], rad(-cr[0]), rad(-cr[1]), rad(cr[2]));
                     boneDef.addOrReplaceChild("cube" + cubeId++, cube, cpose);
                  }
               }
            }

            ModelPart baked = LayerDefinition.create(mesh, tw, th).bakeRoot();
            GeoModel m = new GeoModel(baked);
            collect(baked, defs.keySet(), m, restPose);
            return m;
         }
      } catch (Throwable t) {
         RealmForgeMod.LOGGER.error("Failed to load geo model " + geoFile, t);
         return null;
      }
   }

   private static void collect(ModelPart root, Iterable<String> names, GeoModel m, Map<String, float[]> restPose) {
      for (String n : names) {
         ModelPart p = find(root, n);
         if (p != null) {
            m.bones.put(n, p);
            m.rest.put(n, restPose.get(n));
         }
      }
   }

   private static ModelPart find(ModelPart part, String name) {
      if (part.hasChild(name)) {
         return part.getChild(name);
      }

      // nested bones: search the children's subtrees
      for (var e : part.getAllParts().toList()) {
         if (e != part && e.hasChild(name)) {
            return e.getChild(name);
         }
      }

      return null;
   }

   /** Resets every bone to its rest pose, then applies {@code clip} at time {@code t} seconds (clip may be null). */
   public void pose(Clip clip, float t, float[] posSign, float[] rotSign) {
      float[] v = new float[3];
      for (Map.Entry<String, ModelPart> e : this.bones.entrySet()) {
         ModelPart p = e.getValue();
         float[] r = this.rest.get(e.getKey());
         p.x = r[0];
         p.y = r[1];
         p.z = r[2];
         p.xRot = r[3];
         p.yRot = r[4];
         p.zRot = r[5];
         p.xScale = 1.0F;
         p.yScale = 1.0F;
         p.zScale = 1.0F;
         if (clip == null) {
            continue;
         }

         float tt = clip.loop && clip.length > 0.0F ? t % clip.length : t;
         Clip.Track rot = clip.rot.get(e.getKey());
         if (rot != null) {
            rot.sample(tt, v);
            p.xRot += rad(v[0] * rotSign[0]);
            p.yRot += rad(v[1] * rotSign[1]);
            p.zRot += rad(v[2] * rotSign[2]);
         }

         Clip.Track pos = clip.pos.get(e.getKey());
         if (pos != null) {
            pos.sample(tt, v);
            p.x += v[0] * posSign[0];
            p.y += v[1] * posSign[1];
            p.z += v[2] * posSign[2];
         }

         Clip.Track sc = clip.scale.get(e.getKey());
         if (sc != null) {
            sc.sample(tt, v);
            p.xScale = v[0];
            p.yScale = v[1];
            p.zScale = v[2];
         }
      }
   }

   private static float rad(float deg) {
      return (float)Math.toRadians((double)deg);
   }

   private static float[] arr(JsonElement e, int n) {
      JsonArray a = e.getAsJsonArray();
      float[] out = new float[n];
      for (int i = 0; i < n && i < a.size(); i++) {
         out[i] = a.get(i).getAsFloat();
      }

      return out;
   }
}
