package com.realmforge.skill;

import com.realmforge.RealmForgeMod;
import net.minecraft.resources.ResourceLocation;

/**
 * One skill. Implement this interface (and list the class in a {@link SkillPack}) to add a skill.
 * The shared systems (registry, executor, menu, cooldowns, energy, damage, animation and FX
 * synchronisation) never mention individual skills; everything skill specific lives behind this interface.
 */
public interface SkillDefinition {
   /** Stable lowercase id used in save data, commands and the menu (e.g. {@code electro_barrage}). */
   String id();

   String displayName();

   String description();

   int energyCost();

   int cooldownTicks();

   /** How long the skill keeps the caster "busy" (no other skill can start). */
   default int durationTicks() {
      return 20;
   }

   /** Photon FX names (files in assets/photon/fx) this skill plays; they are preloaded to avoid a hitch on first use. */
   default java.util.List<String> fxNames() {
      return java.util.List.of();
   }

   /** Menu icon. Defaults to {@code assets/realmforge/textures/skills/<id>.png}. */
   default ResourceLocation icon() {
      return RealmForgeMod.id("textures/skills/" + this.id() + ".png");
   }

   /** Extra gate checked before energy/cooldown are spent. Send the player a message and return false to refuse. */
   default boolean canUse(SkillContext ctx) {
      return true;
   }

   /** Server-side behaviour. Use the {@link SkillContext} helpers for timing, damage, movement, animation and FX. */
   void execute(SkillContext ctx);
}
