package com.realmforge.skill;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Server-tick scheduler for skill timelines. Tasks owned by a player are dropped if that player dies or leaves. */
public final class SkillTasks {
   private static final List<Task> TASKS = new ArrayList<>();
   private static final Map<UUID, Long> BUSY_UNTIL = new ConcurrentHashMap<>();

   private SkillTasks() {
   }

   private record Task(UUID owner, long runAt, Runnable action) {
   }

   public static synchronized void later(ServerPlayer owner, int delayTicks, Runnable action) {
      TASKS.add(new Task(owner.getUUID(), owner.server.getTickCount() + Math.max(0, delayTicks), action));
   }

   public static void setBusy(ServerPlayer p, int ticks) {
      BUSY_UNTIL.put(p.getUUID(), (long)p.server.getTickCount() + ticks);
   }

   public static boolean isBusy(ServerPlayer p) {
      Long until = BUSY_UNTIL.get(p.getUUID());
      return until != null && (long)p.server.getTickCount() < until;
   }

   public static void clear(UUID id) {
      BUSY_UNTIL.remove(id);
      synchronized (SkillTasks.class) {
         TASKS.removeIf(t -> t.owner().equals(id));
      }
   }

   public static void tick(MinecraftServer server) {
      long now = server.getTickCount();
      List<Runnable> due = new ArrayList<>();
      synchronized (SkillTasks.class) {
         Iterator<Task> it = TASKS.iterator();
         while (it.hasNext()) {
            Task t = it.next();
            ServerPlayer owner = server.getPlayerList().getPlayer(t.owner());
            if (owner == null || !owner.isAlive()) {
               it.remove();
            } else if (t.runAt() <= now) {
               it.remove();
               due.add(t.action());
            }
         }
      }

      for (Runnable r : due) {
         try {
            r.run();
         } catch (Throwable e) {
            com.realmforge.RealmForgeMod.LOGGER.error("Skill task failed", e);
         }
      }
   }
}
