package com.realmforge.skill.skills;

import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillPack;
import java.util.function.Consumer;

/** The five original Electro skills. To add more skills, create another SkillPack and list it in META-INF/services. */
public final class ElectroSkillPack implements SkillPack {
   @Override
   public void register(Consumer<SkillDefinition> registry) {
      registry.accept(new ElectroBarrageSkill());
      registry.accept(new ElectroDropkickSkill());
      registry.accept(new ElectroDoubleScratchSkill());
      registry.accept(new ElectricFieldSkill());
      registry.accept(new ElectroFistSkill());
   }
}
