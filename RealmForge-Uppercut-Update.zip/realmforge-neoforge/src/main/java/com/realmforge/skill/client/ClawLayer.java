package com.realmforge.skill.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.realmforge.RealmForgeMod;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * The original Electro claw model (Modelelecclaw): per hand, one flat 10x10 blade plane and one 2x10 plane, taken
 * cube-for-cube from the original class, textured with the original elecclaw.png (64x64). Drawn on both hands
 * while a skill requests claws.
 */
public final class ClawLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   public static final ModelLayerLocation LAYER = new ModelLayerLocation(RealmForgeMod.id("electro_claws"), "main");
   private static final ResourceLocation TEX = RealmForgeMod.id("textures/entity/elecclaw.png");
   private final ModelPart rightArm;
   private final ModelPart leftArm;

   public ClawLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, ModelPart root) {
      super(parent);
      this.rightArm = root.getChild("right_arm");
      this.leftArm = root.getChild("left_arm");
   }

   public static LayerDefinition createLayer() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = mesh.getRoot();
      CubeDeformation d = CubeDeformation.NONE;
      root.addOrReplaceChild(
         "right_arm",
         CubeListBuilder.create()
            .texOffs(0, 44).addBox(-3.25F, 3.0F, -5.75F, 0.0F, 10.0F, 10.0F, d)
            .texOffs(50, 0).addBox(-3.25F, 13.0F, -5.75F, 2.0F, 0.0F, 10.0F, d),
         PartPose.offset(-5.0F, 2.0F, 0.0F)
      );
      root.addOrReplaceChild(
         "left_arm",
         CubeListBuilder.create()
            .texOffs(50, 0).addBox(1.25F, 13.0F, -5.75F, 2.0F, 0.0F, 10.0F, d)
            .texOffs(0, 44).addBox(3.25F, 3.0F, -5.5F, 0.0F, 10.0F, 10.0F, d),
         PartPose.offset(5.0F, 2.0F, 0.0F)
      );
      return LayerDefinition.create(mesh, 64, 64);
   }

   @Override
   public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
      if (!SkillFxClient.hasClaws(player.getUUID())) {
         return;
      }

      PlayerModel<AbstractClientPlayer> m = this.getParentModel();
      this.rightArm.copyFrom(m.rightArm);
      this.leftArm.copyFrom(m.leftArm);
      var vc = buffers.getBuffer(RenderType.entityTranslucent(TEX));
      this.rightArm.render(pose, vc, 15728880, OverlayTexture.NO_OVERLAY);
      this.leftArm.render(pose, vc, 15728880, OverlayTexture.NO_OVERLAY);
   }
}
