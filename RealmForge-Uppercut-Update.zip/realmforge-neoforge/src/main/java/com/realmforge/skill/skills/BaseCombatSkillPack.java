package com.realmforge.skill.skills;

import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillPack;
import java.util.function.Consumer;

/** Prime Piece Base Combat moves ported into RealmForge. */
public final class BaseCombatSkillPack implements SkillPack {
   @Override
   public void register(Consumer<SkillDefinition> registry) {
      registry.accept(new UppercutSkill());
   }
}
