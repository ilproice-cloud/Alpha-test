package com.realmforge.skill.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.realmforge.addon.anim.AnimClient;
import com.realmforge.addon.anim.Clip;
import com.realmforge.skill.entity.SkillPropEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Renders {@link SkillPropEntity} with the original Bedrock geo model + animation for its prop id. */
public final class SkillPropRenderer extends EntityRenderer<SkillPropEntity> {
   private static final int FULL_BRIGHT = 15728880;

   public SkillPropRenderer(EntityRendererProvider.Context ctx) {
      super(ctx);
   }

   @Override
   public boolean shouldRender(SkillPropEntity entity, Frustum frustum, double x, double y, double z) {
      return true; // animated scale can exceed the tiny hitbox
   }

   @Override
   public void render(SkillPropEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
      PropDefs.Prop def = PropDefs.get(e.prop());
      if (def == null) {
         return;
      }

      GeoModel model = PropDefs.model(def);
      if (model == null) {
         return;
      }

      Clip clip = PropDefs.clip(def, e.anim());
      float t = ((float)e.tickCount + partialTick) / 20.0F;
      model.pose(clip, t, AnimClient.POS_SIGN, AnimClient.ROT_SIGN);
      pose.pushPose();
      pose.mulPose(Axis.YP.rotationDegrees(180.0F - yaw));
      pose.scale(-1.0F, -1.0F, 1.0F);
      VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(def.texture(e.variant())));
      model.root.render(pose, vc, def.glow() ? FULL_BRIGHT : light, OverlayTexture.NO_OVERLAY);
      pose.popPose();
      super.render(e, yaw, partialTick, pose, buffers, light);
   }

   @Override
   public ResourceLocation getTextureLocation(SkillPropEntity e) {
      PropDefs.Prop def = PropDefs.get(e.prop());
      return def == null ? ResourceLocation.withDefaultNamespace("textures/misc/white.png") : def.texture(e.variant());
   }
}
