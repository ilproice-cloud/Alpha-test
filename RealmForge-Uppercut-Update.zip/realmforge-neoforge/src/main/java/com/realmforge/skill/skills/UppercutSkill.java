package com.realmforge.skill.skills;

import com.realmforge.data.Stat;
import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.Comparator;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Uppercut: a quick, single-target close-range punch that launches the victim upward.
 * Uses the Base Combat uppercut player animation from Prime Piece, adapted to RealmForge's
 * animation loader and server-authoritative skill helpers.
 */
public final class UppercutSkill implements SkillDefinition {
   @Override
   public String id() {
      return "uppercut";
   }

   @Override
   public String displayName() {
      return "Uppercut";
   }

   @Override
   public String description() {
      return "Deliver a powerful rising punch that launches the enemy into the air.";
   }

   @Override
   public int energyCost() {
      return 8;
   }

   @Override
   public int cooldownTicks() {
      return 60;
   }

   @Override
   public int durationTicks() {
      return 14;
   }

   @Override
   public void execute(SkillContext c) {
      Vec3 look = c.flatLook();
      c.animate("uppercut", 1.0F);
      c.sound("clothwhoosh", 0.75F, 1.05F);
      c.hold(3);
      c.later(5, () -> {
         c.sound("basepunch", 1.0F, 0.95F);
         c.sparks(c.player.position().add(look.scale(1.25)).add(0.0, 1.0, 0.0), 10, 0.25);
         LivingEntity target = c.cone(3.0, 55.0).stream()
            .min(Comparator.comparingDouble(t -> t.distanceToSqr(c.player)))
            .orElse(null);
         if (target != null) {
            // Strength contributes directly because skill hits intentionally bypass the normal melee STR pass.
            double damage = 5.0 + (double)c.data.stat(Stat.STR) * 0.5;
            if (c.hit(target, damage)) {
               c.shove(target, look, 0.28, 0.92);
               c.sparks(target.position().add(0.0, (double)target.getBbHeight() * 0.65, 0.0), 16, 0.35);
            }
         }
      });
   }
}
