package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.List;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Electro Double Scratch: two lightning-clawed swipes (original "pawswipetp" animation) with the original Electro
 * claw model shown on both hands and the original claw-hit / thrash FX on every victim.
 */
public final class ElectroDoubleScratchSkill implements SkillDefinition {
   @Override
   public String id() {
      return "electro_double_scratch";
   }

   @Override
   public String displayName() {
      return "Electro Double Scratch";
   }

   @Override
   public String description() {
      return "Slash twice with crackling electric claws, shredding everything in front of you and slowing those you tear.";
   }

   @Override
   public int energyCost() {
      return 25;
   }

   @Override
   public int cooldownTicks() {
      return 150;
   }

   @Override
   public int durationTicks() {
      return 24;
   }

   @Override
   public List<String> fxNames() {
      return List.of("dash2", "violentthrash", "clawshit", "pgoroimpact1");
   }

   @Override
   public void execute(SkillContext c) {
      Vec3 look = c.flatLook();
      c.animate("pawswipetp");
      c.claws(34);
      c.sound("clothwhoosh", 1.0F, 1.2F);
      c.fx("dash2", 0.0, 1.0, 0.0);
      c.noFall(30);
      c.every(2, 4, i -> c.lunge(look, 0.9));
      c.later(6, () -> swipe(c, look, 4.0, "swordslice2", false));
      c.later(13, () -> swipe(c, look, 5.0, "slishsloch", true));
   }

   private static void swipe(SkillContext c, Vec3 look, double dmg, String sound, boolean thrash) {
      c.sound(sound, 1.0F, 1.0F);
      c.sound("lightpunch", 0.7F, 1.4F);
      if (thrash) {
         c.fx("violentthrash", 0.0, 1.0, 0.0);
      }

      for (LivingEntity t : c.cone(3.2, 70.0)) {
         if (c.hit(t, dmg)) {
            c.shove(t, look, 0.35, 0.1);
            c.fxOn(t, "clawshit", 0.0, -0.6, 0.0, 1.0F, false);
            c.fxOn(t, "pgoroimpact1", 0.0, -0.6, 0.0, 1.0F, false);
            t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1, false, true));
            c.sparks(t.position().add(0.0, (double)t.getBbHeight() * 0.6, 0.0), 10, 0.35);
         }
      }
   }
}
