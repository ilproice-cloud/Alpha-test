package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Electro Dropkick: a blitzing lightning dash into a flying kick (original "lightkick" animation, 1.75s) that hits
 * everything on the way, then slams down in an area burst.
 */
public final class ElectroDropkickSkill implements SkillDefinition {
   @Override
   public String id() {
      return "electro_dropkick";
   }

   @Override
   public String displayName() {
      return "Electro Dropkick";
   }

   @Override
   public String description() {
      return "Blitz forward in a flash of lightning and drive a flying dropkick through your foes, ending in a shockwave on impact.";
   }

   @Override
   public int energyCost() {
      return 30;
   }

   @Override
   public int cooldownTicks() {
      return 200;
   }

   @Override
   public int durationTicks() {
      return 40;
   }

   @Override
   public List<String> fxNames() {
      return List.of("dash3", "gorodash3", "sulongdash", "pikakickup", "sobakick", "bigimpact", "basedownslam", "bigexplode");
   }

   @Override
   public void execute(SkillContext c) {
      Vec3 look = c.flatLook();
      Set<Integer> hit = new HashSet<>();
      c.animate("lightkick");
      c.sound("clothwhoosh", 1.0F, 0.8F);
      c.fx("dash3", 0.0, 1.0, 0.0);
      c.noFall(70);
      c.hold(4);
      // dash + kick: ticks 5..13
      c.later(5, () -> {
         c.sound("lightningboomy2", 1.0F, 1.1F);
         c.fx("gorodash3", 0.0, 1.0, 0.0);
         c.fx("sulongdash", 0.0, 1.0, 0.0);
         c.dash(look, 1.5, 0.18);
      });
      c.every(6, 8, i -> {
         c.lunge(look, 1.35);
         for (LivingEntity t : c.cone(2.6, 50.0)) {
            if (hit.add(t.getId()) && c.hit(t, 8.0)) {
               c.shove(t, look, 1.3, 0.35);
               c.fxOn(t, "pikakickup", 0.0, -0.8, 0.0, 1.0F, false);
               c.fxOn(t, "sobakick", 0.0, -0.8, 0.0, 1.0F, false);
               c.sparks(t.position().add(0.0, (double)t.getBbHeight() * 0.5, 0.0), 12, 0.4);
            }
         }
      });
      // landing slam: area burst
      c.later(15, () -> {
         c.lunge(look, 0.0);
         c.sound("groundslam", 1.2F, 1.0F);
         c.sound("lightningboomy", 1.0F, 0.9F);
         c.fx("basedownslam", 0.0, -1.0, 0.0);
         c.fx("bigimpact", 0.0, 0.0, 0.0);
         c.fx("bigexplode", 0.0, -0.6, 0.0);
         for (LivingEntity t : c.around(c.player.position(), 4.5)) {
            if (c.hit(t, 5.0)) {
               Vec3 away = t.position().subtract(c.player.position());
               c.shove(t, away, 1.1, 0.5);
               c.fxOn(t, "bigimpact", 0.0, -0.8, 0.0, 1.0F, false);
            }
         }

         c.sparks(c.player.position().add(0.0, 0.3, 0.0), 30, 1.5);
      });
   }
}
