package com.realmforge.skill;

import java.util.function.Consumer;
import net.neoforged.bus.api.Event;

/** Posted on the NeoForge event bus while the registry boots, so other mods/addons can register skills too. */
public class RegisterSkillsEvent extends Event {
   private final Consumer<SkillDefinition> sink;

   public RegisterSkillsEvent(Consumer<SkillDefinition> sink) {
      this.sink = sink;
   }

   public void register(SkillDefinition def) {
      this.sink.accept(def);
   }
}
