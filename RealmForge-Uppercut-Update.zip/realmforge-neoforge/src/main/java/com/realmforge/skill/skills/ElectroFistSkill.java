package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import com.realmforge.skill.entity.SkillPropEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Electro Fist: the caster charges (original "kariskill" animation, electro claws on both hands), then the original
 * Ursus shock paw model (geo + animation + texture) slams down ahead and detonates in a lightning shock.
 */
public final class ElectroFistSkill implements SkillDefinition {
   @Override
   public String id() {
      return "electro_fist";
   }

   @Override
   public String displayName() {
      return "Electro Fist";
   }

   @Override
   public String description() {
      return "Gather lightning in your claws, then call down a colossal thunder fist that crushes the ground ahead and detonates.";
   }

   @Override
   public int energyCost() {
      return 35;
   }

   @Override
   public int cooldownTicks() {
      return 250;
   }

   @Override
   public int durationTicks() {
      return 55;
   }

   @Override
   public List<String> fxNames() {
      return List.of("goroaura", "gorotrail", "kaidolightning", "pgororaigostorm149", "bigimpact", "goroburst", "pgorolightinggroundlight1");
   }

   @Override
   public void execute(SkillContext c) {
      Vec3 look = c.flatLook();
      c.animate("kariskill");
      c.claws(60);
      c.hold(24);
      c.sound("clothwhoosh", 0.8F, 0.6F);
      c.fx("goroaura", 0.0, 1.0, 0.0);
      c.fx("gorotrail", 0.0, 1.0, 0.0);
      AtomicReference<SkillPropEntity> paw = new AtomicReference<>();
      // the Ursus paw appears ahead and plays its original "idle" animation (grows, hovers, retreats)
      c.later(18, () -> {
         Vec3 at = c.player.position().add(look.scale(5.0));
         paw.set(c.prop("ursusshock", 0, at, c.player.getYRot(), 70, "idle"));
         c.sound("longlightning", 1.0F, 1.0F);
      });
      c.later(30, () -> {
         Vec3 at = c.player.position().add(look.scale(5.0));
         c.soundAt(at, "ursushockkaboooooommm", 1.6F, 1.0F);
         c.soundAt(at, "lightningboomy", 1.3F, 0.7F);
         // FX are anchored on the paw so they erupt where it lands (fall back to the caster if it is gone)
         net.minecraft.world.entity.Entity anchor = paw.get() != null && paw.get().isAlive() ? paw.get() : c.player;
         c.fxOn(anchor, "kaidolightning", 0.0, 0.0, 0.0, 1.0F, false);
         c.fxOn(anchor, "pgororaigostorm149", 0.0, 0.0, 0.0, 1.0F, false);
         c.fxOn(anchor, "pgorolightinggroundlight1", 0.0, 0.0, 0.0, 1.0F, false);
         c.fxOn(anchor, "bigimpact", 0.0, 0.0, 0.0, 1.0F, false);
         c.bolt(at);
         for (LivingEntity t : c.around(at, 6.5)) {
            if (c.hit(t, 14.0)) {
               c.shove(t, t.position().subtract(at), 1.6, 0.7);
               c.fxOn(t, "goroburst", 0.0, -0.5, 0.0, 1.0F, false);
               c.sparks(t.position().add(0.0, (double)t.getBbHeight() * 0.6, 0.0), 16, 0.5);
            }
         }

         c.sparks(at.add(0.0, 0.5, 0.0), 60, 3.0);
      });
   }
}
