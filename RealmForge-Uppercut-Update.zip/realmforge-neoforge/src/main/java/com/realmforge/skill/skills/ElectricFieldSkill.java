package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.List;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Electric Field: the "countershock". The caster braces (original "countershock" animation), the screen flashes with
 * the original countershock overlay, then a huge shockwave bursts out (original countershock Photon FX) and the field
 * keeps pulsing while the "countershockow" animation plays.
 */
public final class ElectricFieldSkill implements SkillDefinition {
   private static final double RADIUS = 7.5;

   @Override
   public String id() {
      return "electric_field";
   }

   @Override
   public String displayName() {
      return "Electric Field";
   }

   @Override
   public String description() {
      return "Brace yourself, then unleash a huge electric shockwave that hurls enemies away and keeps pulsing around you.";
   }

   @Override
   public int energyCost() {
      return 40;
   }

   @Override
   public int cooldownTicks() {
      return 300;
   }

   @Override
   public int durationTicks() {
      return 60;
   }

   @Override
   public List<String> fxNames() {
      return List.of("goroaura", "countershock", "pgorolightinggroundlight1", "pgorolightinggrounde5", "pgorolightinggroundcloud1", "pgorologia15", "pgoroimpact1");
   }

   @Override
   public void execute(SkillContext c) {
      c.animate("countershock");
      c.hold(15);
      c.sound("clothwhoosh", 0.8F, 0.7F);
      c.fx("goroaura", 0.0, 1.0, 0.0);
      c.flash("textures/screens/countershock1.png", 12);
      c.later(15, () -> {
         c.animate("countershockow");
         c.sound("countershock", 1.3F, 1.0F);
         c.sound("lightningboomy", 1.2F, 0.8F);
         c.fx("countershock", 0.0, 1.0, 0.0);
         c.fx("pgorolightinggrounde5", 0.0, 0.0, 0.0);
         c.fx("pgorolightinggroundlight1", 0.0, 0.0, 0.0);
         c.fx("pgorologia15", 0.0, 0.0, 0.0);
         c.flash("textures/screens/countershockbrr.png", 14);
         pulse(c, 9.0, 1.7, 0.6);
         visualBolts(c);
      });
      for (int i = 0; i < 3; i++) {
         c.later(27 + i * 10, () -> {
            c.sound("smalllightningboomy", 0.9F, 1.2F);
            c.fx("pgorolightinggroundcloud1", 0.0, 0.0, 0.0);
            pulse(c, 2.5, 0.5, 0.1);
         });
      }
   }

   private static void pulse(SkillContext c, double dmg, double push, double up) {
      Vec3 center = c.player.position();
      for (LivingEntity t : c.around(center, RADIUS)) {
         if (c.hit(t, dmg)) {
            c.shove(t, t.position().subtract(center), push, up);
            c.fxOn(t, "pgoroimpact1", 0.0, -0.6, 0.0, 1.0F, false);
            t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2, false, true));
            c.sparks(t.position().add(0.0, (double)t.getBbHeight() * 0.6, 0.0), 8, 0.35);
         }
      }

      c.sparks(center.add(0.0, 1.0, 0.0), 40, 2.5);
   }

   private static void visualBolts(SkillContext c) {
      Vec3 p = c.player.position();
      for (int i = 0; i < 4; i++) {
         double a = Math.PI * 2.0 * (double)i / 4.0 + Math.PI / 4.0;
         c.bolt(p.add(Math.cos(a) * 5.0, 0.0, Math.sin(a) * 5.0));
      }
   }
}
