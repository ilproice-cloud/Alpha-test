package com.realmforge.skill.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: bind skill {@code skillId} to key slot {@code slot} (0=Z, 1=X, 2=C). Validated server-side. */
public record EquipSkillPayload(String skillId, int slot) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<EquipSkillPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("equip_skill"));
   public static final StreamCodec<ByteBuf, EquipSkillPayload> CODEC = StreamCodec.composite(
      ByteBufCodecs.STRING_UTF8, EquipSkillPayload::skillId, ByteBufCodecs.INT, EquipSkillPayload::slot, EquipSkillPayload::new
   );

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
