package com.realmforge.skill.entity;

import com.realmforge.RealmForgeMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
   public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, RealmForgeMod.MOD_ID);
   public static final DeferredHolder<EntityType<?>, EntityType<SkillPropEntity>> SKILL_PROP = ENTITIES.register(
      "skill_prop",
      () -> EntityType.Builder.<SkillPropEntity>of(SkillPropEntity::new, MobCategory.MISC)
         .sized(0.5F, 0.5F)
         .noSave()
         .fireImmune()
         .clientTrackingRange(16)
         .updateInterval(20)
         .build("skill_prop")
   );

   private ModEntities() {
   }
}
