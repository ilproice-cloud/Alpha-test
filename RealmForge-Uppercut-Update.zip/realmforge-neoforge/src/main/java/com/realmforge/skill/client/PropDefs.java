package com.realmforge.skill.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.anim.Clip;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

/**
 * Client-side catalogue of prop models (id -> geo file, textures, animation file). Skills reference props by id
 * through {@code SkillContext.prop(...)}; register new ones here (or from your own client code) to add more.
 */
public final class PropDefs {
   public record Prop(String id, ResourceLocation geo, String texturePattern, String animFile, boolean glow) {
      public ResourceLocation texture(int variant) {
         return RealmForgeMod.id(this.texturePattern.replace("{v}", Integer.toString(variant)));
      }
   }

   private static final Map<String, Prop> PROPS = new HashMap<>();
   private static final Map<String, GeoModel> MODELS = new HashMap<>();
   private static final Map<String, Map<String, Clip>> ANIMS = new HashMap<>();

   static {
      // Electro Barrage: the original Gorobolt lightning bolt (5 texture variants gorobolt1..5)
      register(new Prop("gorobolt", RealmForgeMod.id("geo/gorobolt.geo.json"), "textures/entity/gorobolt{v}.png", null, true));
      // Electro Fist: the original Ursus shock paw
      register(new Prop("ursusshock", RealmForgeMod.id("geo/ursusshock.geo.json"), "textures/entity/ursusshock.png", "ursusshock", true));
   }

   private PropDefs() {
   }

   public static void register(Prop p) {
      PROPS.put(p.id(), p);
   }

   public static Prop get(String id) {
      return PROPS.get(id);
   }

   public static void reload() {
      MODELS.clear();
      ANIMS.clear();
   }

   public static GeoModel model(Prop p) {
      if (!MODELS.containsKey(p.id())) {
         MODELS.put(p.id(), GeoModel.load(p.geo()));
      }

      return MODELS.get(p.id());
   }

   public static Clip clip(Prop p, String animName) {
      if (p.animFile() == null || animName == null || animName.isEmpty()) {
         return null;
      }

      Map<String, Clip> all = ANIMS.computeIfAbsent(p.animFile(), f -> {
         ResourceLocation loc = RealmForgeMod.id("animations/" + f + ".animation.json");
         try {
            var res = Minecraft.getInstance().getResourceManager().getResource(loc).orElse(null);
            if (res == null) {
               RealmForgeMod.LOGGER.error("Prop animation file not found: {}", loc);
               return new HashMap<>();
            }

            try (InputStream in = res.open()) {
               return Clip.parse(in);
            }
         } catch (Throwable t) {
            RealmForgeMod.LOGGER.error("Failed to load prop animation " + loc, t);
            return new HashMap<>();
         }
      });
      return all.get(animName);
   }
}
