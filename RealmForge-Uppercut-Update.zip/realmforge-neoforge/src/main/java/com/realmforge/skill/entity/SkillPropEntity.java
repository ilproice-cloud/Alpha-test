package com.realmforge.skill.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/**
 * Generic, non-colliding visual prop used by skills: it carries the id of a bundled geo model
 * (e.g. "gorobolt", "ursusshock"), a texture variant, an animation name and a lifetime.
 * Clients render it with the original model; the server only owns the lifetime.
 */
public class SkillPropEntity extends Entity {
   private static final EntityDataAccessor<String> PROP = SynchedEntityData.defineId(SkillPropEntity.class, EntityDataSerializers.STRING);
   private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(SkillPropEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<String> ANIM = SynchedEntityData.defineId(SkillPropEntity.class, EntityDataSerializers.STRING);
   private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(SkillPropEntity.class, EntityDataSerializers.INT);

   public SkillPropEntity(EntityType<? extends SkillPropEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public void setup(String prop, int variant, String anim, int life) {
      this.entityData.set(PROP, prop);
      this.entityData.set(VARIANT, variant);
      this.entityData.set(ANIM, anim == null ? "" : anim);
      this.entityData.set(LIFE, Math.max(1, life));
   }

   public String prop() {
      return this.entityData.get(PROP);
   }

   public int variant() {
      return this.entityData.get(VARIANT);
   }

   public String anim() {
      return this.entityData.get(ANIM);
   }

   public int life() {
      return this.entityData.get(LIFE);
   }

   @Override
   protected void defineSynchedData(SynchedEntityData.Builder builder) {
      builder.define(PROP, "");
      builder.define(VARIANT, 0);
      builder.define(ANIM, "");
      builder.define(LIFE, 20);
   }

   @Override
   public void tick() {
      super.tick();
      if (!this.level().isClientSide && this.tickCount >= this.life()) {
         this.discard();
      }
   }

   @Override
   public boolean isPickable() {
      return false;
   }

   @Override
   public boolean shouldBeSaved() {
      return false;
   }

   @Override
   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   @Override
   protected void addAdditionalSaveData(CompoundTag tag) {
   }
}
