package com.realmforge.skill;

import com.realmforge.addon.anim.AnimNet;
import com.realmforge.data.RpgData;
import com.realmforge.logic.DamagePipeline;
import com.realmforge.logic.JjkParticles;
import com.realmforge.skill.entity.ModEntities;
import com.realmforge.skill.entity.SkillPropEntity;
import com.realmforge.skill.net.SkillFxPayload;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Everything a skill may need, shared by all skills: timing, hit detection, damage, knockback, movement,
 * sounds, animation and FX synchronisation. Skills call these helpers instead of talking to the network
 * or the damage pipeline themselves, so behaviour stays consistent and multiplayer-safe.
 */
public final class SkillContext {
   public final ServerPlayer player;
   public final RpgData data;
   public final SkillDefinition def;

   public SkillContext(ServerPlayer player, RpgData data, SkillDefinition def) {
      this.player = player;
      this.data = data;
      this.def = def;
   }

   public ServerLevel level() {
      return this.player.serverLevel();
   }

   // ------------------------------------------------------------------ timing

   /** Runs {@code action} after {@code ticks} server ticks (cancelled automatically if the caster dies or leaves). */
   public void later(int ticks, Runnable action) {
      SkillTasks.later(this.player, ticks, action);
   }

   /** Runs {@code action(i)} on each of the next {@code count} ticks, starting after {@code start} ticks. */
   public void every(int start, int count, IntConsumer action) {
      for (int i = 0; i < count; i++) {
         final int idx = i;
         this.later(start + i, () -> action.accept(idx));
      }
   }

   // ------------------------------------------------------------------ geometry / targets

   /** Caster's horizontal look direction (normalised). */
   public Vec3 flatLook() {
      Vec3 l = this.player.getLookAngle();
      Vec3 f = new Vec3(l.x, 0.0, l.z);
      return f.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : f.normalize();
   }

   public boolean validTarget(LivingEntity t) {
      if (t == this.player || !t.isAlive() || t.isSpectator() || t instanceof ArmorStand) {
         return false;
      }

      if (t instanceof Player other && !this.player.canHarmPlayer(other)) {
         return false;
      }

      return !(t instanceof TamableAnimal pet && pet.isOwnedBy(this.player));
   }

   /** Living targets inside a horizontal cone in front of the caster. */
   public List<LivingEntity> cone(double range, double halfAngleDeg) {
      Vec3 origin = this.player.position();
      Vec3 look = this.flatLook();
      double cos = Math.cos(Math.toRadians(halfAngleDeg));
      List<LivingEntity> out = new ArrayList<>();
      AABB box = this.player.getBoundingBox().inflate(range, 1.5, range);
      for (LivingEntity t : this.level().getEntitiesOfClass(LivingEntity.class, box, this::validTarget)) {
         Vec3 d = new Vec3(t.getX() - origin.x, 0.0, t.getZ() - origin.z);
         double dist = d.length();
         if (dist > range + (double)t.getBbWidth() * 0.5) {
            continue;
         }

         if (dist < 0.6 || d.normalize().dot(look) >= cos) {
            out.add(t);
         }
      }

      return out;
   }

   public List<LivingEntity> around(Vec3 center, double radius) {
      AABB box = new AABB(center, center).inflate(radius, Math.max(2.0, radius * 0.5), radius);
      List<LivingEntity> out = new ArrayList<>();
      for (LivingEntity t : this.level().getEntitiesOfClass(LivingEntity.class, box, this::validTarget)) {
         if (t.position().distanceTo(center) <= radius + (double)t.getBbWidth() * 0.5) {
            out.add(t);
         }
      }

      return out;
   }

   // ------------------------------------------------------------------ damage / movement

   /** Deals {@code base} damage scaled by skill level, perk bonuses and INT. Skill hits bypass the melee STR pass. */
   public boolean hit(LivingEntity target, double base) {
      if (!this.validTarget(target)) {
         return false;
      }

      float amount = (float)(base * this.data.skillDamageMult(this.def.id()));
      DamagePipeline.SKILL.set(true);
      try {
         return target.hurt(this.player.damageSources().playerAttack(this.player), amount);
      } finally {
         DamagePipeline.SKILL.set(false);
      }
   }

   /** Knocks a target away along {@code dir} (horizontal) with an upward kick, respecting knockback resistance. */
   public void shove(LivingEntity target, Vec3 dir, double strength, double up) {
      double resist = 1.0 - Math.min(1.0, target.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE));
      Vec3 h = new Vec3(dir.x, 0.0, dir.z);
      h = h.lengthSqr() < 1.0E-6 ? Vec3.ZERO : h.normalize();
      target.setDeltaMovement(h.x * strength * resist, Math.max(target.getDeltaMovement().y, up * resist), h.z * strength * resist);
      target.hurtMarked = true;
   }

   /** Launches the caster along {@code dir}; the velocity is pushed to the client immediately. */
   public void dash(Vec3 dir, double speed, double up) {
      this.player.setDeltaMovement(dir.x * speed, up, dir.z * speed);
      this.player.hurtMarked = true;
      this.player.fallDistance = 0.0F;
   }

   /** Sets only the caster's horizontal velocity (keeps gravity/vertical motion). */
   public void lunge(Vec3 dir, double speed) {
      Vec3 v = this.player.getDeltaMovement();
      this.player.setDeltaMovement(dir.x * speed, v.y, dir.z * speed);
      this.player.hurtMarked = true;
      this.player.fallDistance = 0.0F;
   }

   /** Keeps the caster still (horizontally) for {@code ticks}, e.g. while charging. */
   public void hold(int ticks) {
      this.every(0, ticks, i -> {
         Vec3 v = this.player.getDeltaMovement();
         this.player.setDeltaMovement(0.0, Math.min(0.0, v.y), 0.0);
         this.player.hurtMarked = true;
      });
   }

   /** Cancels fall damage for {@code ticks} (dashes / jumps). */
   public void noFall(int ticks) {
      this.every(0, ticks, i -> this.player.fallDistance = 0.0F);
   }

   public void busy(int ticks) {
      SkillTasks.setBusy(this.player, ticks);
   }

   // ------------------------------------------------------------------ presentation

   public void animate(String clip, float speed) {
      AnimNet.broadcast(this.player, clip, speed);
   }

   public void animate(String clip) {
      this.animate(clip, 1.0F);
   }

   /** Plays a Photon FX attached to the caster (offset is relative to the eye position, as in Photon). */
   public void fx(String name, double ox, double oy, double oz) {
      this.fxOn(this.player, name, ox, oy, oz, 1.0F, false);
   }

   public void fx(String name) {
      this.fx(name, 0.0, 1.0, 0.0);
   }

   /** Plays a Photon FX attached to any entity (e.g. an impact on a victim). */
   public void fxOn(Entity anchor, String name, double ox, double oy, double oz, float scale, boolean forcedDeath) {
      SkillFxPayload p = new SkillFxPayload(SkillFxPayload.PHOTON, anchor.getId(), name, (float)ox, (float)oy, (float)oz, scale, forcedDeath ? 1 : 0);
      if (anchor instanceof ServerPlayer) {
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(anchor, p);
      } else {
         // the caster is normally tracking the anchor already; make sure they get it exactly once
         PacketDistributor.sendToPlayersTrackingEntity(anchor, p);
      }
   }

   /** Shows the Electro claw model on the caster's hands for {@code ticks}. */
   public void claws(int ticks) {
      SkillFxPayload p = new SkillFxPayload(SkillFxPayload.CLAWS, this.player.getId(), "", 0, 0, 0, 1, ticks);
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(this.player, p);
   }

   /** Full-screen overlay flash for the caster only (texture path inside assets/realmforge/textures). */
   public void flash(String texture, int ticks) {
      PacketDistributor.sendToPlayer(this.player, new SkillFxPayload(SkillFxPayload.FLASH, this.player.getId(), texture, 0, 0, 0, 1, ticks));
   }

   public void sound(String name, float volume, float pitch) {
      this.soundAt(this.player.position(), name, volume, pitch);
   }

   public void soundAt(Vec3 at, String name, float volume, float pitch) {
      SoundEvent ev = ModSounds.get(name);
      if (ev != null) {
         this.level().playSound(null, at.x, at.y, at.z, ev, SoundSource.PLAYERS, volume, pitch);
      } else {
         com.realmforge.RealmForgeMod.LOGGER.warn("Unknown skill sound '{}'", name);
      }
   }

   public void sparks(Vec3 at, int count, double spread) {
      ServerLevel l = this.level();
      l.sendParticles(JjkParticles.BLUE_SPARK.get(), at.x, at.y, at.z, count, spread, spread, spread, 0.05);
      l.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, count, spread, spread, spread, 0.4);
   }

   /** Custom spark-only lightning accent. Never creates a vanilla LightningBolt entity. */
   public void bolt(Vec3 at) {
      this.sparks(at, 24, 0.9);
   }

   /** Spawns a model prop (Gorobolt bolt, Ursus paw ...) that clients render with the original geo model. */
   public SkillPropEntity prop(String propId, int variant, Vec3 at, float yaw, int lifeTicks, String anim) {
      SkillPropEntity e = new SkillPropEntity(ModEntities.SKILL_PROP.get(), this.level());
      e.setup(propId, variant, anim, lifeTicks);
      e.moveTo(at.x, at.y, at.z, yaw, 0.0F);
      this.level().addFreshEntity(e);
      return e;
   }
}
