package com.realmforge.skill;

import java.util.function.Consumer;

/**
 * A group of skills. Packs are discovered automatically through {@link java.util.ServiceLoader}
 * (list the implementing class in {@code META-INF/services/com.realmforge.skill.SkillPack}),
 * so new skills never require touching the executor, the menu or the registry.
 */
public interface SkillPack {
   void register(Consumer<SkillDefinition> registry);
}
