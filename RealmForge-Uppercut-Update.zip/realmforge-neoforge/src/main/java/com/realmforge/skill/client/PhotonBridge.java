package com.realmforge.skill.client;

import com.lowdragmc.photon.client.fx.EntityEffectExecutor;
import com.lowdragmc.photon.client.fx.FX;
import com.lowdragmc.photon.client.fx.FXHelper;
import com.realmforge.RealmForgeMod;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

/**
 * The ONLY class that touches Photon. It is loaded lazily and only when Photon is installed, so RealmForge still
 * starts without it. Written against photon-neoforge-1.21.1 2.2.10: FX live at assets/photon/fx/&lt;name&gt;.fx and an
 * entity-anchored FX sits at the entity's eye position plus the given offset (same convention as /photon fx entity).
 */
public final class PhotonBridge {
   private static final Set<String> WARNED = new HashSet<>();

   private PhotonBridge() {
   }

   private static ResourceLocation id(String name) {
      return ResourceLocation.fromNamespaceAndPath("photon", name);
   }

   public static boolean exists(String name) {
      return Minecraft.getInstance().getResourceManager().getResource(FXHelper.fileLocation(id(name))).isPresent();
   }

   public static void play(ClientLevel level, Entity anchor, String name, float ox, float oy, float oz, float scale, boolean forcedDeath) {
      ResourceLocation id = id(name);
      if (!exists(name)) {
         warnOnce(name, "FX file " + FXHelper.fileLocation(id) + " is missing from the resource packs");
         return;
      }

      FX fx = FXHelper.getFX(id);
      if (fx == null) {
         warnOnce(name, "Photon could not load FX " + id);
         return;
      }

      EntityEffectExecutor ex = new EntityEffectExecutor(fx, level, anchor, EntityEffectExecutor.AutoRotate.NONE);
      ex.setOffset((double)ox, (double)oy, (double)oz);
      if (scale != 1.0F) {
         ex.setScale((double)scale, (double)scale, (double)scale);
      }

      ex.setForcedDeath(forcedDeath);
      ex.setAllowMulti(true);
      ex.start();
   }

   /** Loads FX ahead of time so the first cast does not stall. Missing files are reported once. */
   public static void preload(Collection<String> names) {
      List<ResourceLocation> ids = new ArrayList<>();
      for (String n : names) {
         if (exists(n)) {
            ids.add(id(n));
         } else {
            warnOnce(n, "FX file for '" + n + "' is not present in assets/photon/fx");
         }
      }

      if (!ids.isEmpty()) {
         for (ResourceLocation r : ids) {
            FXHelper.getFX(r);
         }
      }
   }

   private static void warnOnce(String key, String msg) {
      if (WARNED.add(key)) {
         RealmForgeMod.LOGGER.warn("[skills] {}", msg);
      }
   }
}
