package com.realmforge.skill.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillRegistry;
import com.realmforge.skill.net.SkillFxPayload;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.neoforged.fml.ModList;

/** Client-side playback of skill visuals sent by the server (Photon FX, claw model, screen flash). */
public final class SkillFxClient {
   private static final Map<UUID, Long> CLAWS = new HashMap<>();
   private static boolean preloaded;
   public static String flashTexture;
   public static long flashStart;
   public static int flashTicks;

   private SkillFxClient() {
   }

   public static boolean photonLoaded() {
      return ModList.get().isLoaded("photon");
   }

   public static void handle(SkillFxPayload p) {
      Minecraft mc = Minecraft.getInstance();
      ClientLevel level = mc.level;
      if (level == null) {
         return;
      }

      switch (p.kind()) {
         case SkillFxPayload.PHOTON -> {
            Entity e = level.getEntity(p.entityId());
            if (e == null) {
               return;
            }

            if (!photonLoaded()) {
               return;
            }

            PhotonBridge.play(level, e, p.name(), p.ox(), p.oy(), p.oz(), p.scale(), (p.param() & 1) != 0);
         }
         case SkillFxPayload.CLAWS -> {
            Entity e = level.getEntity(p.entityId());
            if (e != null) {
               CLAWS.put(e.getUUID(), level.getGameTime() + (long)p.param());
            }
         }
         case SkillFxPayload.FLASH -> {
            flashTexture = p.name();
            flashStart = level.getGameTime();
            flashTicks = Math.max(1, p.param());
         }
         default -> {
         }
      }
   }

   public static boolean hasClaws(UUID id) {
      Long end = CLAWS.get(id);
      if (end == null) {
         return false;
      }

      ClientLevel level = Minecraft.getInstance().level;
      if (level == null || level.getGameTime() > end) {
         CLAWS.remove(id);
         return false;
      }

      return true;
   }

   /** Preloads every FX declared by registered skills (once per session, when the world is first entered). */
   public static void preloadAll() {
      if (preloaded || !photonLoaded()) {
         return;
      }

      preloaded = true;
      Set<String> names = new HashSet<>();
      for (SkillDefinition d : SkillRegistry.all()) {
         names.addAll(d.fxNames());
      }

      try {
         PhotonBridge.preload(names);
      } catch (Throwable t) {
         RealmForgeMod.LOGGER.error("Photon FX preload failed", t);
      }
   }

   public static void reset() {
      CLAWS.clear();
      preloaded = false;
   }
}
