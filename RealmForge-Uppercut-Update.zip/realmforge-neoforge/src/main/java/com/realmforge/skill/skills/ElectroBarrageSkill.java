package com.realmforge.skill.skills;

import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Electro Barrage: a rush-down flurry (original "rushdownbarrage" player animation, 1.25s). Six rapid cone hits,
 * each with the original Gorobolt lightning-bolt model in front of the caster and a Photon impact on every victim,
 * finished by a heavy blast.
 */
public final class ElectroBarrageSkill implements SkillDefinition {
   private static final int[] HIT_TICKS = {5, 8, 11, 14, 17, 20};

   @Override
   public String id() {
      return "electro_barrage";
   }

   @Override
   public String displayName() {
      return "Electro Barrage";
   }

   @Override
   public String description() {
      return "Rush forward in a storm of lightning-charged punches. Six rapid hits and a final blast, each crackling with a Gorobolt strike.";
   }

   @Override
   public int energyCost() {
      return 15;
   }

   @Override
   public int cooldownTicks() {
      return 100;
   }

   @Override
   public int durationTicks() {
      return 28;
   }

   @Override
   public List<String> fxNames() {
      return List.of("goroaura", "gorotrail", "pgorobolt2", "pgorolighttrail12", "pgoroimpact1", "goroburst");
   }

   @Override
   public void execute(SkillContext c) {
      c.animate("rushdownbarrage");
      c.sound("clothwhoosh", 1.0F, 1.0F);
      c.fx("goroaura", 0.0, 1.0, 0.0);
      c.fx("gorotrail", 0.0, 1.0, 0.0);
      c.noFall(40);
      // short forward drive while the animation winds up
      Vec3 look = c.flatLook();
      c.every(0, 6, i -> c.lunge(look, 0.45));
      for (int i = 0; i < HIT_TICKS.length; i++) {
         final int n = i;
         c.later(HIT_TICKS[i], () -> flurry(c, n));
      }

      c.later(23, () -> finisher(c));
   }

   private static void flurry(SkillContext c, int n) {
      Vec3 look = c.flatLook();
      Vec3 at = c.player.position().add(look.scale(2.2));
      // Original Gorobolt model; variants 2..5 are picked at random like the original spawn procedure did
      c.prop("gorobolt", 2 + ThreadLocalRandom.current().nextInt(4), at, c.player.getYRot(), 6, null);
      c.sound(n % 2 == 0 ? "lightpunch" : "knucklecrack", 0.9F, 0.9F + 0.05F * (float)n);
      c.lunge(look, 0.25);
      for (LivingEntity t : c.cone(3.4, 55.0)) {
         if (c.hit(t, 2.5)) {
            c.shove(t, look, 0.25, 0.05);
            c.fxOn(t, "pgoroimpact1", 0.0, -0.6, 0.0, 1.0F, false);
            c.fxOn(t, "pgorolighttrail12", 0.0, -0.6, 0.0, 1.0F, false);
            c.sparks(t.position().add(0.0, (double)t.getBbHeight() * 0.6, 0.0), 6, 0.3);
         }
      }
   }

   private static void finisher(SkillContext c) {
      Vec3 look = c.flatLook();
      c.sound("lightningboomy", 1.1F, 1.0F);
      c.prop("gorobolt", 5, c.player.position().add(look.scale(2.6)), c.player.getYRot(), 8, null);
      for (LivingEntity t : c.cone(4.2, 70.0)) {
         if (c.hit(t, 6.0)) {
            c.shove(t, look, 1.5, 0.45);
            c.fxOn(t, "goroburst", 0.0, -0.4, 0.0, 1.0F, false);
            c.sparks(t.position().add(0.0, (double)t.getBbHeight() * 0.6, 0.0), 14, 0.5);
         }
      }
   }
}
