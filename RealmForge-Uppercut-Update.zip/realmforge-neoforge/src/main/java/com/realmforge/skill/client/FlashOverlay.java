package com.realmforge.skill.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.realmforge.RealmForgeMod;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/** Fading full-screen texture used by the Electric Field countershock flash (original countershock*.png overlays). */
public final class FlashOverlay {
   private FlashOverlay() {
   }

   /** Pixel sizes of the bundled overlay textures (the blit needs the real texture size). */
   private static int[] size(String path) {
      String n = path.substring(path.lastIndexOf('/') + 1);
      return switch (n) {
         case "countershock1.png" -> new int[]{194, 194};
         case "countershock1two.png" -> new int[]{720, 629};
         case "countershock1three.png" -> new int[]{400, 400};
         case "countershock2.png" -> new int[]{140, 140};
         case "countershock2two.png" -> new int[]{520, 520};
         case "countershock2three.png" -> new int[]{340, 340};
         case "countershockbrr.png" -> new int[]{600, 600};
         default -> new int[]{256, 256};
      };
   }

   public static void render(GuiGraphics g, DeltaTracker delta) {
      Minecraft mc = Minecraft.getInstance();
      if (SkillFxClient.flashTexture == null || mc.level == null) {
         return;
      }

      float age = (float)(mc.level.getGameTime() - SkillFxClient.flashStart) + delta.getGameTimeDeltaPartialTick(false);
      if (age >= (float)SkillFxClient.flashTicks) {
         SkillFxClient.flashTexture = null;
         return;
      }

      float alpha = 1.0F - age / (float)SkillFxClient.flashTicks;
      ResourceLocation tex = RealmForgeMod.id(SkillFxClient.flashTexture);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      g.setColor(1.0F, 1.0F, 1.0F, Math.max(0.0F, alpha * 0.85F));
      int[] size = size(SkillFxClient.flashTexture);
      g.blit(tex, 0, 0, g.guiWidth(), g.guiHeight(), 0.0F, 0.0F, size[0], size[1], size[0], size[1]);
      g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.disableBlend();
   }
}
