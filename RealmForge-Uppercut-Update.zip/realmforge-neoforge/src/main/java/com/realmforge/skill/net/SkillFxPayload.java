package com.realmforge.skill.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server -> client visual cue. Visuals are played on the CLIENT (Photon is a client library), so the server
 * only says what to play and where; this works for every player tracking the caster and needs no op permission.
 */
public record SkillFxPayload(byte kind, int entityId, String name, float ox, float oy, float oz, float scale, int param)
   implements CustomPacketPayload {
   public static final byte PHOTON = 0;
   public static final byte CLAWS = 1;
   public static final byte FLASH = 2;

   public static final CustomPacketPayload.Type<SkillFxPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("skill_fx"));
   public static final StreamCodec<ByteBuf, SkillFxPayload> CODEC = StreamCodec.of(SkillFxPayload::write, SkillFxPayload::read);

   private static void write(ByteBuf raw, SkillFxPayload p) {
      FriendlyByteBuf b = new FriendlyByteBuf(raw);
      b.writeByte(p.kind);
      b.writeVarInt(p.entityId);
      b.writeUtf(p.name, 128);
      b.writeFloat(p.ox);
      b.writeFloat(p.oy);
      b.writeFloat(p.oz);
      b.writeFloat(p.scale);
      b.writeVarInt(p.param);
   }

   private static SkillFxPayload read(ByteBuf raw) {
      FriendlyByteBuf b = new FriendlyByteBuf(raw);
      return new SkillFxPayload(b.readByte(), b.readVarInt(), b.readUtf(128), b.readFloat(), b.readFloat(), b.readFloat(), b.readFloat(), b.readVarInt());
   }

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
