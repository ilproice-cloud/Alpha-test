package com.realmforge;

import com.realmforge.addon.anim.AnimPayload;
import com.realmforge.addon.item.TojiItems;
import com.realmforge.addon.logic.BlockingManager;
import com.realmforge.addon.net.BlockPayload;
import com.realmforge.addon.net.BlockStatePayload;
import com.realmforge.data.Perk;
import com.realmforge.data.Rarity;
import com.realmforge.data.Trait;
import com.realmforge.logic.JjkParticles;
import com.realmforge.logic.SkillExecutor;
import com.realmforge.net.SkillUsePayload;
import com.realmforge.net.SyncPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(RealmForgeMod.MOD_ID)
public class RealmForgeMod {
   public static final String MOD_ID = "realmforge";
   public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

   public RealmForgeMod(IEventBus modBus) {
      Rarity.validate(Trait.values(), "Trait");
      Rarity.validate(Perk.values(), "Perk");
      JjkParticles.PARTICLES.register(modBus);
      com.realmforge.skill.ModSounds.SOUNDS.register(modBus);
      com.realmforge.skill.entity.ModEntities.ENTITIES.register(modBus);
      com.realmforge.skill.SkillRegistry.bootstrap();
      TojiItems.ARMOR_MATERIALS.register(modBus);
      TojiItems.ITEMS.register(modBus);
      LOGGER.info("RealmForge loaded.");
   }

   public static ResourceLocation id(String path) {
      return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
   }

   @EventBusSubscriber(modid = MOD_ID, bus = EventBusSubscriber.Bus.MOD)
   public static final class ModEvents {
      private ModEvents() {
      }

      @SubscribeEvent
      public static void registerPayloads(RegisterPayloadHandlersEvent event) {
         PayloadRegistrar r = event.registrar("1");
         // server -> client (handlers live in a client-only class)
         r.playToClient(SyncPayload.TYPE, SyncPayload.CODEC, com.realmforge.client.ClientHandlers::onSync);
         r.playToClient(AnimPayload.TYPE, AnimPayload.CODEC, com.realmforge.client.ClientHandlers::onAnim);
         r.playToClient(com.realmforge.skill.net.SkillFxPayload.TYPE, com.realmforge.skill.net.SkillFxPayload.CODEC, com.realmforge.client.ClientHandlers::onSkillFx);
         r.playToClient(BlockStatePayload.TYPE, BlockStatePayload.CODEC, com.realmforge.client.ClientHandlers::onBlockState);
         // client -> server
         r.playToServer(
            SkillUsePayload.TYPE,
            SkillUsePayload.CODEC,
            (payload, ctx) -> ctx.enqueueWork(() -> {
               if (ctx.player() instanceof ServerPlayer sp) {
                  SkillExecutor.use(sp, payload.slot());
               }
            })
         );
         r.playToServer(
            com.realmforge.skill.net.EquipSkillPayload.TYPE,
            com.realmforge.skill.net.EquipSkillPayload.CODEC,
            (payload, ctx) -> ctx.enqueueWork(() -> {
               if (ctx.player() instanceof ServerPlayer sp) {
                  com.realmforge.data.RpgData d = com.realmforge.RpgManager.get(sp);
                  if (d.equip(payload.skillId(), payload.slot())) {
                     com.realmforge.RpgManager.sync(sp, -1);
                  }
               }
            })
         );
         r.playToServer(
            BlockPayload.TYPE,
            BlockPayload.CODEC,
            (payload, ctx) -> ctx.enqueueWork(() -> {
               if (ctx.player() instanceof ServerPlayer sp) {
                  BlockingManager.set(sp, payload.active());
               }
            })
         );
      }

      @SubscribeEvent
      public static void creativeTabs(BuildCreativeModeTabContentsEvent event) {
         if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(TojiItems.SHIRT.get());
            event.accept(TojiItems.PANTS.get());
            event.accept(TojiItems.BOOTS.get());
            event.accept(TojiItems.CLOTH.get());
         }
      }
   }
}
