package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import com.realmforge.skill.SkillContext;
import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillRegistry;
import com.realmforge.skill.SkillTasks;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Universal skill executor. It knows nothing about individual skills: it resolves the key slot to a
 * {@link SkillDefinition}, applies the shared rules (unlocked, busy, cooldown, energy) and delegates.
 */
public final class SkillExecutor {
   private SkillExecutor() {
   }

   public static void use(ServerPlayer p, int slot) {
      if (slot < 0 || slot > 2 || !p.isAlive() || p.isSpectator()) {
         return;
      }

      RpgData d = RpgManager.get(p);
      String id = d.slots[slot];
      if (id == null || id.isEmpty()) {
         notice(p, "No skill equipped on " + "ZXC".charAt(slot) + ". Open the Skill Book (N).", ChatFormatting.GRAY);
         return;
      }

      SkillDefinition def = SkillRegistry.get(id);
      if (def == null || !d.hasSkill(id)) {
         notice(p, "That skill is not unlocked.", ChatFormatting.RED);
         return;
      }

      if (SkillTasks.isBusy(p)) {
         return;
      }

      long now = p.serverLevel().getGameTime();
      long end = d.cdEnd.getOrDefault(id, 0L);
      if (now < end) {
         notice(p, def.displayName() + " ready in " + String.format(java.util.Locale.ROOT, "%.1f", (double)(end - now) / 20.0) + "s", ChatFormatting.GRAY);
         return;
      }

      if (d.energy < (float)def.energyCost()) {
         notice(p, "Not enough energy for " + def.displayName() + " (" + def.energyCost() + ").", ChatFormatting.RED);
         return;
      }

      SkillContext ctx = new SkillContext(p, d, def);
      if (!def.canUse(ctx)) {
         return;
      }

      d.energy -= (float)def.energyCost();
      d.cdEnd.put(id, now + (long)def.cooldownTicks());
      d.skillUses.merge(id, 1, Integer::sum);
      d.syncDirty = true;
      ctx.busy(def.durationTicks());
      try {
         def.execute(ctx);
      } catch (Throwable t) {
         com.realmforge.RealmForgeMod.LOGGER.error("Skill {} failed", id, t);
      }

      RpgManager.sync(p, -1);
   }

   private static void notice(ServerPlayer p, String text, ChatFormatting color) {
      p.displayClientMessage(Component.literal(text).withStyle(color), true);
   }
}
