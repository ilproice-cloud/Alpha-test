package com.realmforge.client;

import com.realmforge.data.RpgData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;

public final class ClientRpg {
   public static RpgData data;
   public static long tick;
   public static long recvTick;

   private ClientRpg() {
   }

   public static void accept(String snbt) {
      try {
         CompoundTag n = TagParser.parseTag(snbt);
         data = RpgData.fromSync(n);
         recvTick = tick;
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public static int cooldownLeft(String skillId) {
      return data == null ? 0 : (int)Math.max(0L, (long)data.cdRemain.getOrDefault(skillId, 0) - (tick - recvTick));
   }
}
