package com.realmforge.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.client.BlockingClient;
import com.realmforge.client.particle.JjkAnimatedParticle;
import com.realmforge.logic.JjkParticles;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/** Client-only mod-bus registrations: keys, particles, HUD layer. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class RealmForgeClient {
   private static final String CAT = "key.categories.realmforge";
   public static final KeyMapping OPEN = new KeyMapping("key.realmforge.open", InputConstants.Type.KEYSYM, 77, CAT);
   public static final KeyMapping SKILL_BOOK = new KeyMapping("key.realmforge.skill_book", InputConstants.Type.KEYSYM, 78, CAT);
   public static final KeyMapping[] SKILL_KEYS = new KeyMapping[]{
      new KeyMapping("key.realmforge.skill1", InputConstants.Type.KEYSYM, 90, CAT),
      new KeyMapping("key.realmforge.skill2", InputConstants.Type.KEYSYM, 88, CAT),
      new KeyMapping("key.realmforge.skill3", InputConstants.Type.KEYSYM, 67, CAT)
   };

   private RealmForgeClient() {
   }

   @SubscribeEvent
   public static void registerKeys(RegisterKeyMappingsEvent event) {
      event.register(OPEN);
      event.register(SKILL_BOOK);
      for (KeyMapping k : SKILL_KEYS) {
         event.register(k);
      }

      event.register(BlockingClient.BLOCK);
   }

   @SubscribeEvent
   public static void registerParticles(RegisterParticleProvidersEvent event) {
      event.registerSpriteSet(JjkParticles.BLOOM.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.BF_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.RED_BOOM.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.PURPLE_BOOM.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.BLUE_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.RED_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.PURPLE_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.CE_SPARK.get(), JjkAnimatedParticle.Factory::new);
      event.registerSpriteSet(JjkParticles.BLOOD_SPLASH.get(), JjkAnimatedParticle.Factory::new);
   }

   @SubscribeEvent
   public static void registerHud(RegisterGuiLayersEvent event) {
      event.registerAboveAll(RealmForgeMod.id("hud"), RpgHud::render);
      event.registerAboveAll(RealmForgeMod.id("skill_flash"), com.realmforge.skill.client.FlashOverlay::render);
   }

   @SubscribeEvent
   public static void registerRenderers(net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers event) {
      event.registerEntityRenderer(com.realmforge.skill.entity.ModEntities.SKILL_PROP.get(), com.realmforge.skill.client.SkillPropRenderer::new);
   }

   @SubscribeEvent
   public static void registerLayerDefinitions(net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions event) {
      event.registerLayerDefinition(com.realmforge.skill.client.ClawLayer.LAYER, com.realmforge.skill.client.ClawLayer::createLayer);
   }

   @SubscribeEvent
   public static void addLayers(net.neoforged.neoforge.client.event.EntityRenderersEvent.AddLayers event) {
      for (net.minecraft.client.resources.PlayerSkin.Model skin : event.getSkins()) {
         if (event.getSkin(skin) instanceof net.minecraft.client.renderer.entity.player.PlayerRenderer pr) {
            pr.addLayer(new com.realmforge.skill.client.ClawLayer(pr, event.getEntityModels().bakeLayer(com.realmforge.skill.client.ClawLayer.LAYER)));
         }
      }
   }

   @SubscribeEvent
   public static void registerReloadListeners(net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent event) {
      event.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener)rm -> {
         com.realmforge.addon.anim.AnimClient.reload();
         com.realmforge.skill.client.PropDefs.reload();
      });
   }
}
