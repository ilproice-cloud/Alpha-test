package com.realmforge.client;

import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

public final class RpgHud {
   private RpgHud() {
   }

   public static void render(GuiGraphics g, DeltaTracker tickCounter) {
      Minecraft mc = Minecraft.getInstance();
      RpgData d = ClientRpg.data;
      if (d != null && mc.player != null && !mc.options.hideGui) {
         Font tr = mc.font;
         int screenW = mc.getWindow().getGuiScaledWidth();
         int x = 8;
         int y = 8;
         int w = Math.min(250, Math.max(150, screenW - 16));
         int barH = 9;
         int gap = 12;
         g.fill(x - 3, y - 3, x + w + 3, y + 68, 1694498816);
         Rank r = d.rank();
         g.drawString(tr, Component.literal("[" + r.icon + "] " + mc.player.getName().getString()).withStyle(r.color), x, y, 16777215);
         Component lv = Component.literal("Lv." + d.level).withStyle(ChatFormatting.YELLOW);
         g.drawString(tr, lv, x + w - tr.width(lv), y, 16777215);
         y += 12;
         g.drawString(tr, Component.literal(r.label).withStyle(ChatFormatting.GRAY), x, y, 16777215);
         if (d.points > 0) {
            Component pts = Component.literal("+" + d.points + " pts [M]").withStyle(ChatFormatting.GOLD);
            g.drawString(tr, pts, x + w - tr.width(pts), y, 16777215);
         }

         y += 13;
         float hp = mc.player.getHealth();
         float maxHp = mc.player.getMaxHealth();
         bar(g, tr, x, y, w, barH, hp / Math.max(1.0F, maxHp), -3790808, String.format("HP %.0f/%.0f", hp, maxHp));
         y += gap;
         float maxE = d.maxEnergy();
         bar(g, tr, x, y, w, barH, d.energy / Math.max(1.0F, maxE), -14780206, String.format("EN %.0f/%.0f", d.energy, maxE));
         y += gap;
         boolean max = d.level >= 100;
         bar(
            g,
            tr,
            x,
            y,
            w,
            barH,
            max ? 1.0F : (float)d.exp / (float)Math.max(1L, d.expRequired()),
            -13722049,
            max ? "EXP MAX" : "EXP " + d.exp + "/" + d.expRequired()
         );
         // equipped skills (Z / X / C) with cooldowns
         int sy = 8 + 68 + 6;
         g.fill(x - 3, sy - 3, x + w + 3, sy + 3 * 11 + 1, 1694498816);
         String[] keys = new String[]{"Z", "X", "C"};
         for (int i = 0; i < 3; i++) {
            String id = d.slots[i];
            com.realmforge.skill.SkillDefinition def = id == null || id.isEmpty() ? null : com.realmforge.skill.SkillRegistry.get(id);
            int cd = def == null ? 0 : ClientRpg.cooldownLeft(id);
            String text = keys[i] + "  " + (def == null ? "-" : def.displayName()) + (cd > 0 ? String.format("  %.1fs", (double)cd / 20.0) : "");
            g.drawString(tr, Component.literal(text).withStyle(def == null ? ChatFormatting.DARK_GRAY : (cd > 0 ? ChatFormatting.GRAY : ChatFormatting.AQUA)), x, sy + i * 11, 16777215);
         }
      }
   }

   private static void bar(GuiGraphics g, Font tr, int x, int y, int w, int h, float frac, int color, String label) {
      frac = Math.max(0.0F, Math.min(1.0F, frac));
      g.fill(x, y, x + w, y + h, -14935012);
      g.fill(x, y, x + (int)((float)w * frac), y + h, color);
      g.drawCenteredString(tr, Component.literal(label), x + w / 2, y + 1, 16777215);
   }
}
