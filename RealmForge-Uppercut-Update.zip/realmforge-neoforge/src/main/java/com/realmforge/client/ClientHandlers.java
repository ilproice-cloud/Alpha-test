package com.realmforge.client;

import com.realmforge.addon.anim.AnimPayload;
import com.realmforge.addon.net.BlockStatePayload;
import com.realmforge.net.SyncPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client-side payload handlers. Kept thin: real work is in client-only classes loaded lazily. */
public final class ClientHandlers {
   private ClientHandlers() {
   }

   public static void onSync(SyncPayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> ClientActions.sync(payload.snbt(), payload.openPage()));
   }

   public static void onAnim(AnimPayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> com.realmforge.addon.anim.AnimClient.play(payload.player(), payload.clip(), payload.speed()));
   }

   public static void onSkillFx(com.realmforge.skill.net.SkillFxPayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> com.realmforge.skill.client.SkillFxClient.handle(payload));
   }

   public static void onBlockState(BlockStatePayload payload, IPayloadContext ctx) {
      ctx.enqueueWork(() -> com.realmforge.addon.client.BlockingClient.set(payload.player(), payload.active()));
   }
}
