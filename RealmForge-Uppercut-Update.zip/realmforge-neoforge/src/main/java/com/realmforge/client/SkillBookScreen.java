package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.data.RpgData;
import com.realmforge.skill.SkillDefinition;
import com.realmforge.skill.SkillRegistry;
import com.realmforge.skill.net.EquipSkillPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Skill book. Lists ONLY the skills the player has unlocked (left page); the right page shows the selected skill's
 * name, description, cost and cooldown with an [ EQUIP ] text button that binds it to Z, X or C. Nothing here knows
 * about individual skills: it is driven entirely by {@link SkillRegistry}, so new skills appear automatically.
 */
public final class SkillBookScreen extends Screen {
   private static final ResourceLocation BOOK = RealmForgeMod.id("textures/gui/rpg_book_background.png");
   private static final ResourceLocation EXIT = RealmForgeMod.id("textures/gui/exit_button.png");
   private static final int INK = -14082024;
   private static final int LEFT_CX = 128;
   private static final int RIGHT_CX = 340;
   private static final int ROWS = 11;
   private static final String[] KEYS = new String[]{"Z", "X", "C"};
   private int bx;
   private int by;
   private int bw;
   private int bh;
   private int btnW;
   private int closeX;
   private int closeY;
   private float scale;
   private boolean choosing;
   private String selected;
   private int scroll;
   private final List<Hit> hits = new ArrayList<>();
   private int mx;
   private int my;

   private record Hit(int x, int y, int w, int h, Runnable action) {
   }

   public SkillBookScreen(int page) {
      super(Component.literal("Skill Book"));
   }

   private static List<SkillDefinition> unlocked() {
      List<SkillDefinition> out = new ArrayList<>();
      RpgData d = ClientRpg.data;
      if (d != null) {
         for (SkillDefinition s : SkillRegistry.all()) {
            if (d.hasSkill(s.id())) {
               out.add(s);
            }
         }
      }

      return out;
   }

   @Override
   protected void init() {
      this.clearWidgets();
      this.scale = Math.max(0.25F, Math.min(1.65F, Math.min(((float)this.width - 90.0F) / 463.0F, ((float)this.height - 28.0F) / 301.0F)));
      this.bw = Math.round(463.0F * this.scale);
      this.bh = Math.round(301.0F * this.scale);
      this.bx = (this.width - this.bw) / 2;
      this.by = Math.max(0, (this.height - this.bh) / 2);
      this.btnW = Math.max(22, Math.round(30.0F * this.scale));
      this.closeX = Math.min(this.width - this.btnW, this.bx + this.bw - this.btnW / 2);
      this.closeY = Math.max(0, this.by - this.btnW / 2);
      this.addRenderableWidget(Button.builder(Component.empty(), b -> this.onClose()).bounds(this.closeX, this.closeY, this.btnW, this.btnW).build());
   }

   private void textButton(GuiGraphics g, String label, int cx, int y, boolean selected, Runnable action) {
      int w = this.font.width(label);
      int x = cx - w / 2;
      boolean hover = this.mx >= x - 2 && this.mx <= x + w + 2 && this.my >= y - 2 && this.my <= y + 11;
      ChatFormatting color = selected ? ChatFormatting.GREEN : (hover ? ChatFormatting.GOLD : ChatFormatting.DARK_BLUE);
      MutableComponent c = Component.literal(label).withStyle(color, ChatFormatting.BOLD);
      if (hover) {
         c = c.withStyle(ChatFormatting.UNDERLINE);
      }

      g.drawCenteredString(this.font, c, cx, y, INK);
      this.hits.add(new Hit(x - 2, y - 2, w + 4, 13, action));
   }

   private void centered(GuiGraphics g, Component text, int cx, int y) {
      g.drawCenteredString(this.font, text, cx, y, INK);
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         double lx = (mouseX - (double)this.bx) / (double)this.scale;
         double ly = (mouseY - (double)this.by) / (double)this.scale;
         for (Hit h : new ArrayList<>(this.hits)) {
            if (lx >= (double)h.x && lx <= (double)(h.x + h.w) && ly >= (double)h.y && ly <= (double)(h.y + h.h)) {
               h.action.run();
               return true;
            }
         }
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      int max = Math.max(0, unlocked().size() - ROWS);
      this.scroll = Math.max(0, Math.min(max, this.scroll - (int)Math.signum(scrollY)));
      return true;
   }

   private void select(String id) {
      this.selected = id;
      this.choosing = false;
   }

   /** Binds locally right away (so the page updates immediately) and tells the server, which validates and saves it. */
   private void equip(String id, int slot) {
      RpgData d = ClientRpg.data;
      if (d != null) {
         d.equip(id, slot);
      }

      PacketDistributor.sendToServer(new EquipSkillPayload(id, slot));
      this.choosing = false;
   }

   @Override
   public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
      g.pose().pushPose();
      g.pose().translate((float)this.bx, (float)this.by, 0.0F);
      g.pose().scale(this.scale, this.scale, 1.0F);
      g.blit(BOOK, 0, 0, 0.0F, 0.0F, 463, 301, 463, 301);
      this.hits.clear();
      this.mx = Math.round((float)(mouseX - this.bx) / this.scale);
      this.my = Math.round((float)(mouseY - this.by) / this.scale);
      this.centered(g, Component.literal("SKILL BOOK").withStyle(ChatFormatting.DARK_BLUE), LEFT_CX, 16);
      List<SkillDefinition> list = unlocked();
      RpgData d = ClientRpg.data;
      if (list.isEmpty() || d == null) {
         this.centered(g, Component.literal("No skills unlocked yet.").withStyle(ChatFormatting.DARK_GRAY), LEFT_CX, 130);
      } else {
         if (this.selected == null || list.stream().noneMatch(s -> s.id().equals(this.selected))) {
            this.selected = list.get(0).id();
         }

         this.drawList(g, list, d);
         this.drawDetail(g, SkillRegistry.get(this.selected), d);
         this.drawSlots(g, d);
      }

      g.pose().popPose();
      super.render(g, mouseX, mouseY, delta);
      g.blit(EXIT, this.closeX, this.closeY, 0.0F, 0.0F, this.btnW, this.btnW, this.btnW, this.btnW);
   }

   private void drawList(GuiGraphics g, List<SkillDefinition> list, RpgData d) {
      int end = Math.min(list.size(), this.scroll + ROWS);
      int y = 36;
      for (int i = this.scroll; i < end; i++) {
         SkillDefinition s = list.get(i);
         int slot = slotOf(d, s.id());
         String label = (slot >= 0 ? "[" + KEYS[slot] + "] " : "") + s.displayName();
         this.textButton(g, label, LEFT_CX, y, s.id().equals(this.selected), () -> this.select(s.id()));
         y += 17;
      }

      if (list.size() > ROWS) {
         this.centered(g, Component.literal("scroll for more").withStyle(ChatFormatting.DARK_GRAY), LEFT_CX, 240);
      }
   }

   private void drawDetail(GuiGraphics g, SkillDefinition s, RpgData d) {
      if (s == null) {
         return;
      }

      g.blit(s.icon(), RIGHT_CX - 32, 30, 64, 64, 0.0F, 0.0F, 32, 32, 32, 32);
      this.centered(g, Component.literal(s.displayName()).withStyle(ChatFormatting.DARK_BLUE, ChatFormatting.BOLD), RIGHT_CX, 100);
      this.centered(g, Component.literal("Skill level " + d.skillLevel(s.id())).withStyle(ChatFormatting.BLUE), RIGHT_CX, 112);
      List<FormattedCharSequence> lines = this.font.split(Component.literal(s.description()), 175);
      int n = 0;
      for (FormattedCharSequence line : lines) {
         if (n >= 5) {
            break;
         }

         g.drawString(this.font, line, RIGHT_CX - 88, 128 + n * 11, INK, false);
         n++;
      }

      this.centered(
         g,
         Component.literal("Cost: " + s.energyCost() + " energy  |  Cooldown: " + String.format(java.util.Locale.ROOT, "%.0f", (double)s.cooldownTicks() / 20.0) + "s").withStyle(ChatFormatting.DARK_GRAY),
         RIGHT_CX,
         190
      );
      int slot = slotOf(d, s.id());
      if (slot >= 0) {
         this.centered(g, Component.literal("Equipped on: " + KEYS[slot]).withStyle(ChatFormatting.GREEN), RIGHT_CX, 202);
      }

      if (!this.choosing) {
         this.textButton(g, "[ EQUIP ]", RIGHT_CX, 218, false, () -> this.choosing = true);
      } else {
         this.centered(g, Component.literal("Assign to which key?").withStyle(ChatFormatting.DARK_GRAY), RIGHT_CX, 214);
         for (int i = 0; i < 3; i++) {
            final int k = i;
            this.textButton(g, "[ " + KEYS[i] + " ]", RIGHT_CX - 44 + i * 44, 228, i == slot, () -> this.equip(s.id(), k));
         }
      }
   }

   private void drawSlots(GuiGraphics g, RpgData d) {
      for (int i = 0; i < 3; i++) {
         String id = d.slots[i];
         SkillDefinition s = id == null || id.isEmpty() ? null : SkillRegistry.get(id);
         String name = s == null ? "-" : s.displayName();
         this.centered(g, Component.literal(KEYS[i] + ": " + name).withStyle(s == null ? ChatFormatting.DARK_GRAY : ChatFormatting.DARK_GREEN), RIGHT_CX, 248 + i * 11);
      }
   }

   private static int slotOf(RpgData d, String id) {
      for (int i = 0; i < d.slots.length; i++) {
         if (id.equals(d.slots[i])) {
            return i;
         }
      }

      return -1;
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode != 256 && keyCode != 78) {
         return super.keyPressed(keyCode, scanCode, modifiers);
      }

      this.onClose();
      return true;
   }

   @Override
   public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
