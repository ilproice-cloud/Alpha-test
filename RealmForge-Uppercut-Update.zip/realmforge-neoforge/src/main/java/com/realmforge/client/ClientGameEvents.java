package com.realmforge.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.anim.AnimClient;
import com.realmforge.addon.client.BlockingClient;
import com.realmforge.net.SkillUsePayload;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Client-only game-bus events: key handling each tick and disconnect cleanup. */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, value = Dist.CLIENT)
public final class ClientGameEvents {
   private ClientGameEvents() {
   }

   @SubscribeEvent
   public static void onLogin(ClientPlayerNetworkEvent.LoggingIn event) {
      com.realmforge.skill.client.SkillFxClient.preloadAll();
   }

   /** Client-only debug helper: /rfanim <clip> plays a player animation on yourself (checks axis conventions in game). */
   @SubscribeEvent
   public static void onClientCommands(net.neoforged.neoforge.client.event.RegisterClientCommandsEvent event) {
      event.getDispatcher().register(
         net.minecraft.commands.Commands.literal("rfanim")
            .then(
               net.minecraft.commands.Commands.argument("clip", com.mojang.brigadier.arguments.StringArgumentType.word())
                  .executes(c -> {
                     Minecraft m = Minecraft.getInstance();
                     if (m.player == null) {
                        return 0;
                     }

                     AnimClient.play(m.player.getUUID(), com.mojang.brigadier.arguments.StringArgumentType.getString(c, "clip"), 1.0F);
                     return 1;
                  })
            )
      );
   }

   @SubscribeEvent
   public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
      ClientRpg.data = null;
      AnimClient.clear();
      BlockingClient.clear();
      com.realmforge.skill.client.SkillFxClient.reset();
   }

   @SubscribeEvent
   public static void onClientTick(ClientTickEvent.Post event) {
      Minecraft mc = Minecraft.getInstance();
      ClientRpg.tick++;
      BlockingClient.tick(mc);
      if (mc.player == null) {
         return;
      }

      while (RealmForgeClient.SKILL_BOOK.consumeClick()) {
         if (mc.screen == null) {
            mc.setScreen(new SkillBookScreen(0));
         }
      }

      while (RealmForgeClient.OPEN.consumeClick()) {
         if (mc.screen == null) {
            if (ClientRpg.data == null) {
               mc.player.displayClientMessage(Component.literal("RealmForge data not loaded yet.").withStyle(ChatFormatting.RED), true);
            } else {
               mc.setScreen(RpgBook.screen(0));
            }
         }
      }

      for (int i = 0; i < RealmForgeClient.SKILL_KEYS.length; i++) {
         while (RealmForgeClient.SKILL_KEYS[i].consumeClick()) {
            if (mc.screen == null) {
               PacketDistributor.sendToServer(new SkillUsePayload(i));
            }
         }
      }
   }
}
