package com.realmforge.data;

import java.util.function.ToDoubleFunction;
import net.minecraft.nbt.CompoundTag;

/**
 * Per-player RPG data. This class already contains the changes the Fabric
 * "fused" addon applied to it through mixins (clan, Toji set flag, skill slots,
 * rebalanced HP / energy / regen / dodge / EXP formulas).
 */
public final class RpgData {
   public static final int MAX_LEVEL = 100;
   public static final int POINTS_PER_LEVEL = 3;
   public static final int STARTING_POINTS = 5;
   public static final int BASE_ENERGY = 5;
   public static final int HP_PER_VIT = 4;
   public static final int ENERGY_PER_ENE = 5;
   public static final double EXP_GROWTH = 1.2;
   public static final double BASE_EXP = 100.0;
   public static final double STR_PHYS = 0.02;
   public static final double INT_SKILL = 0.03;
   public static final double AGI_SPEED = 0.01;
   public static final double AGI_DODGE = 0.005;
   public static final double ENE_REGEN = 0.1;
   public int level = 1;
   public long exp = 0L;
   public int points = 5;
   public final int[] base = new int[Stat.values().length];
   public float energy = 5.0F;
   public String traitId = "";
   public String perkId = "";
   public int rankIdx = 0;
   public int kills = 0;
   /** Skill ids the player has unlocked (insertion ordered so the menu is stable). */
   public final java.util.Set<String> unlocked = new java.util.LinkedHashSet<>();
   /** Times each skill was used (drives skill level). */
   public final java.util.Map<String, Integer> skillUses = new java.util.HashMap<>();
   /** Server: absolute game-time at which each skill's cooldown ends. */
   public final java.util.Map<String, Long> cdEnd = new java.util.HashMap<>();
   /** Skill ids bound to the Z / X / C keys ("" = empty). */
   public final String[] slots = new String[]{"", "", ""};
   public int[] equip = new int[Stat.values().length];
   /** Client: remaining cooldown ticks per skill at the moment the last sync arrived. */
   public java.util.Map<String, Integer> cdRemain = new java.util.HashMap<>();
   public boolean syncDirty;

   // ---- addon fields (were mixin-injected) ----
   private String clan;
   private boolean toji;
   private int rolledLevel = -1;
   private final String[] extraSkills = new String[]{"", "", ""};

   public String clan() {
      return this.clan;
   }

   public void setClan(String id) {
      if (this.clan == null || this.clan.isEmpty()) {
         this.clan = id;
      }
   }

   public boolean toji() {
      return this.toji;
   }

   public void setToji(boolean on) {
      this.toji = on;
   }

   public int rolledLevel() {
      return this.rolledLevel;
   }

   public void setRolledLevel(int l) {
      this.rolledLevel = l;
   }

   public String skill(int i) {
      return i >= 0 && i < 3 ? this.extraSkills[i] : "";
   }

   public void setSkill(int i, String s) {
      if (i >= 0 && i < 3) {
         this.extraSkills[i] = s == null ? "" : s;
      }
   }

   private com.realmforge.addon.data.Clan clanType() {
      return com.realmforge.addon.data.Clan.byId(this.clan);
   }

   public Trait trait() {
      return Trait.byId(this.traitId);
   }

   public Perk perk() {
      return Perk.byId(this.perkId);
   }

   public boolean initialized() {
      return this.trait() != null && this.perk() != null;
   }

   public Rank rank() {
      return Rank.values()[Math.min(this.rankIdx, Rank.values().length - 1)];
   }

   public int stat(Stat s) {
      int i = s.ordinal();
      int v = this.base[i] + (i < this.equip.length ? this.equip[i] : 0);
      Trait t = this.trait();
      if (t != null) {
         v += t.effects().stats[i];
      }

      Perk p = this.perk();
      if (p != null) {
         v += p.effects().stats[i];
      }

      return Math.max(0, v);
   }

   public int bonusOf(Stat s) {
      return this.stat(s) - this.base[s.ordinal()];
   }

   private double fx(ToDoubleFunction<Effects> f) {
      double v = 0.0;
      Trait t = this.trait();
      if (t != null) {
         v += f.applyAsDouble(t.effects());
      }

      Perk p = this.perk();
      if (p != null) {
         v += f.applyAsDouble(p.effects());
      }

      return v;
   }

   /** Fused addon: STR no longer gives a % multiplier (it gives flat damage instead, see DamagePipeline). */
   public double physMult() {
      return 1.0;
   }

   public double intSkillMult() {
      return 1.0 + 0.03 * (double)this.stat(Stat.INT);
   }

   public double speedBonus() {
      return Math.min(1.0, 0.01 * (double)this.stat(Stat.AGI));
   }

   public double dodge() {
      double d = Math.max(0.0, 0.005 * (double)this.stat(Stat.AGI) + this.fx(e -> e.dodge));
      return this.toji ? Math.min(1.0, d + 0.2) : Math.min(0.4, d);
   }

   public int maxHealthBonus() {
      return this.stat(Stat.VIT) * 2 + (int)this.fx(e -> (double)e.hp);
   }

   public double dmgOut() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.dmgOut));
   }

   public double dmgIn() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.dmgIn));
   }

   public double expMult() {
      double m = Math.max(0.0, 1.0 + this.fx(e -> e.exp));
      com.realmforge.addon.data.Clan c = this.clanType();
      return c != null ? m * c.expMult : m;
   }

   public double lifesteal() {
      return Math.max(0.0, this.fx(e -> e.lifesteal));
   }

   public double skillBonus() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.skillDmg));
   }

   public float maxEnergy() {
      double m = Math.max(0.1, 1.0 + this.fx(e -> e.energy));
      return (float)Math.max(1.0, (double)(5 + 2 * this.stat(Stat.ENE)) * m);
   }

   public double regenPerSecond() {
      double m = Math.max(0.0, 1.0 + this.fx(e -> e.regen));
      return (1.0 + 0.25 * (double)this.stat(Stat.ENE)) * m;
   }

   public static long expRequired(int level) {
      return Math.round(100.0 * Math.pow(1.2, (double)(level - 1)));
   }

   public long expRequired() {
      return expRequired(this.level);
   }

   /** Fused addon version: clan stat-point multiplier, and +1 to every base stat per level. */
   public int addExp(long amount) {
      if (amount > 0L && this.level < 100) {
         this.exp += amount;
         int gained = 0;
         com.realmforge.addon.data.Clan c = this.clanType();
         int perLevel = (int)Math.round(3.0 * (c == null ? 1.0 : c.statPointMult));

         while (this.level < 100 && this.exp >= expRequired(this.level)) {
            this.exp = this.exp - expRequired(this.level);
            this.level++;
            this.points += perLevel;

            for (int i = 0; i < this.base.length; i++) {
               this.base[i]++;
            }

            gained++;
         }

         if (this.level >= 100) {
            this.exp = 0L;
         }

         this.syncDirty = true;
         return gained;
      } else {
         return 0;
      }
   }

   public boolean spend(Stat s, int n) {
      if (n >= 1 && n <= this.points) {
         this.base[s.ordinal()] += n;
         this.points -= n;
         this.syncDirty = true;
         return true;
      } else {
         return false;
      }
   }

   public boolean hasSkill(String id) {
      return id != null && this.unlocked.contains(id);
   }

   public int skillLevel(String id) {
      return Math.min(10, 1 + this.skillUses.getOrDefault(id, 0) / 20);
   }

   public double skillLevelMult(String id) {
      return 1.0 + 0.05 * (double)(this.skillLevel(id) - 1);
   }

   /** Damage multiplier for a skill: skill level x perk/trait skill bonus x INT scaling. */
   public double skillDamageMult(String id) {
      return this.skillLevelMult(id) * this.skillBonus() * this.intSkillMult();
   }

   /** Binds a skill to a key slot; a skill can only occupy one slot at a time. */
   public boolean equip(String id, int slot) {
      if (slot < 0 || slot >= this.slots.length || !this.hasSkill(id)) {
         return false;
      }

      for (int i = 0; i < this.slots.length; i++) {
         if (id.equals(this.slots[i])) {
            this.slots[i] = "";
         }
      }

      this.slots[slot] = id;
      this.syncDirty = true;
      return true;
   }

   /** Unlocks a skill and, if a key slot is free, binds it there so it is usable immediately. */
   public boolean unlock(String id) {
      boolean added = this.unlocked.add(id);
      if (added) {
         this.syncDirty = true;
      }

      return added;
   }

   public CompoundTag write() {
      CompoundTag n = new CompoundTag();
      n.putInt("level", this.level);
      n.putLong("exp", this.exp);
      n.putInt("points", this.points);
      n.putIntArray("base", this.base);
      n.putFloat("energy", this.energy);
      n.putString("trait", this.traitId);
      n.putString("perk", this.perkId);
      n.putInt("rank", this.rankIdx);
      n.putInt("kills", this.kills);
      CompoundTag uses = new CompoundTag();
      this.skillUses.forEach(uses::putInt);
      n.put("skill_uses", uses);
      CompoundTag cd = new CompoundTag();
      this.cdEnd.forEach(cd::putLong);
      n.put("skill_cd", cd);
      net.minecraft.nbt.ListTag ul = new net.minecraft.nbt.ListTag();
      for (String id : this.unlocked) {
         ul.add(net.minecraft.nbt.StringTag.valueOf(id));
      }

      n.put("skills_unlocked", ul);

      for (int i = 0; i < this.slots.length; i++) {
         n.putString("slot" + i, this.slots[i]);
      }

      n.putString("rf_clan", this.clan == null ? "" : this.clan);

      for (int i = 0; i < 3; i++) {
         n.putString("rf_skill" + i, this.extraSkills[i]);
      }

      return n;
   }

   public static RpgData read(CompoundTag n) {
      RpgData d = new RpgData();
      if (n.contains("level")) {
         d.level = Math.max(1, Math.min(100, n.getInt("level")));
      }

      d.exp = Math.max(0L, n.getLong("exp"));
      if (n.contains("points")) {
         d.points = Math.max(0, n.getInt("points"));
      }

      copy(n.getIntArray("base"), d.base);
      if (n.contains("energy")) {
         d.energy = n.getFloat("energy");
      }

      d.traitId = n.getString("trait");
      d.perkId = n.getString("perk");
      d.rankIdx = Math.max(0, Math.min(Rank.values().length - 1, n.getInt("rank")));
      d.kills = Math.max(0, n.getInt("kills"));
      CompoundTag uses = n.getCompound("skill_uses");
      for (String k : uses.getAllKeys()) {
         d.skillUses.put(k, uses.getInt(k));
      }

      CompoundTag cd = n.getCompound("skill_cd");
      for (String k : cd.getAllKeys()) {
         d.cdEnd.put(k, cd.getLong(k));
      }

      net.minecraft.nbt.ListTag ul = n.getList("skills_unlocked", 8);
      for (int i = 0; i < ul.size(); i++) {
         d.unlocked.add(ul.getString(i));
      }

      for (int i = 0; i < d.slots.length; i++) {
         // legacy saves stored the old enum ids; map them onto the Electro skills
         d.slots[i] = com.realmforge.skill.SkillRegistry.migrateLegacyId(n.getString("slot" + i));
      }

      String c = n.getString("rf_clan");
      if (!c.isEmpty()) {
         d.setClan(c);
      }

      for (int i = 0; i < 3; i++) {
         d.setSkill(i, n.getString("rf_skill" + i));
      }

      return d;
   }

   public CompoundTag toSync(long worldTime) {
      CompoundTag n = this.write();
      n.putIntArray("equip", this.equip);
      CompoundTag rem = new CompoundTag();
      this.cdEnd.forEach((id, end) -> {
         int left = (int)Math.max(0L, end - worldTime);
         if (left > 0) {
            rem.putInt(id, left);
         }
      });
      n.put("cdrem", rem);
      return n;
   }

   public static RpgData fromSync(CompoundTag n) {
      RpgData d = read(n);
      copy(n.getIntArray("equip"), d.equip);
      CompoundTag rem = n.getCompound("cdrem");
      for (String k : rem.getAllKeys()) {
         d.cdRemain.put(k, rem.getInt(k));
      }

      return d;
   }

   private static void copy(int[] src, int[] dst) {
      System.arraycopy(src, 0, dst, 0, Math.min(src.length, dst.length));
   }
}
