package com.realmforge.addon.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.item.TojiItems;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/**
 * Custom 3D model for the Sorcerer Killer armor. One humanoid model per armor piece;
 * the texture is textures/models/armor/sorcerer_killer_layer_{1,2}.png (same image).
 */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class KillerArmorClient {
   public static final ModelLayerLocation CHEST = new ModelLayerLocation(RealmForgeMod.id("sorcerer_killer"), "chest");
   public static final ModelLayerLocation LEGS = new ModelLayerLocation(RealmForgeMod.id("sorcerer_killer"), "legs");
   public static final ModelLayerLocation BOOTS = new ModelLayerLocation(RealmForgeMod.id("sorcerer_killer"), "boots");

   private static final Map<ModelLayerLocation, HumanoidModel<?>> CACHE = new HashMap<>();
   private static EntityModelSet cachedFor;

   private KillerArmorClient() {
   }

   private static PartDefinition skeleton(MeshDefinition mesh) {
      PartDefinition root = mesh.getRoot();
      root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
      root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
      return root;
   }

   private static void empty(PartDefinition root, String... names) {
      for (String n : names) {
         PartPose pose = switch (n) {
            case "right_arm" -> PartPose.offset(-5.0F, 2.0F, 0.0F);
            case "left_arm" -> PartPose.offset(5.0F, 2.0F, 0.0F);
            case "right_leg" -> PartPose.offset(-1.9F, 12.0F, 0.0F);
            case "left_leg" -> PartPose.offset(1.9F, 12.0F, 0.0F);
            default -> PartPose.ZERO;
         };
         root.addOrReplaceChild(n, CubeListBuilder.create(), pose);
      }
   }

   public static LayerDefinition chestLayer() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = skeleton(mesh);
      root.addOrReplaceChild(
         "body",
         CubeListBuilder.create()
            .texOffs(24, 24)
            .addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.1F))
            .texOffs(0, 55)
            .addBox(-4.0F, 0.0F, -2.0F, 8.0F, 16.0F, 4.0F, new CubeDeformation(0.15F)),
         PartPose.ZERO
      );
      root.addOrReplaceChild(
         "right_arm",
         CubeListBuilder.create().texOffs(0, 41).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 9.0F, 4.0F, new CubeDeformation(0.09F)),
         PartPose.offset(-5.0F, 2.0F, 0.0F)
      );
      root.addOrReplaceChild(
         "left_arm",
         CubeListBuilder.create().texOffs(0, 41).mirror().addBox(-1.0F, -2.0F, -2.0F, 4.0F, 9.0F, 4.0F, new CubeDeformation(0.09F)).mirror(false),
         PartPose.offset(5.0F, 2.0F, 0.0F)
      );
      empty(root, "right_leg", "left_leg");
      return LayerDefinition.create(mesh, 128, 128);
   }

   public static LayerDefinition legsLayer() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = skeleton(mesh);
      empty(root, "body", "right_arm", "left_arm");
      root.addOrReplaceChild(
         "right_leg",
         CubeListBuilder.create()
            .texOffs(36, 0)
            .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F, new CubeDeformation(0.1F))
            .texOffs(24, 40)
            .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F, new CubeDeformation(0.25F))
            .texOffs(40, 40)
            .addBox(-2.5F, 3.0F, -2.5F, 5.0F, 6.0F, 5.0F, new CubeDeformation(0.0F))
            .texOffs(40, 51)
            .addBox(-2.5F, 6.0F, -2.5F, 5.0F, 3.0F, 5.0F, new CubeDeformation(0.2F)),
         PartPose.offset(-1.9F, 12.0F, 0.0F)
      );
      root.addOrReplaceChild(
         "left_leg",
         CubeListBuilder.create()
            .mirror()
            .texOffs(36, 0)
            .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F, new CubeDeformation(0.1F))
            .texOffs(24, 40)
            .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F, new CubeDeformation(0.25F))
            .texOffs(40, 40)
            .addBox(-2.5F, 3.0F, -2.5F, 5.0F, 6.0F, 5.0F, new CubeDeformation(0.0F))
            .texOffs(40, 51)
            .addBox(-2.5F, 6.0F, -2.5F, 5.0F, 3.0F, 5.0F, new CubeDeformation(0.2F))
            .mirror(false),
         PartPose.offset(1.9F, 12.0F, 0.0F)
      );
      return LayerDefinition.create(mesh, 128, 128);
   }

   public static LayerDefinition bootsLayer() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = skeleton(mesh);
      empty(root, "body", "right_arm", "left_arm");
      root.addOrReplaceChild(
         "right_leg",
         CubeListBuilder.create()
            .texOffs(36, 10)
            .addBox(-2.0F, 10.0F, -2.0F, 4.0F, 2.0F, 4.0F, new CubeDeformation(0.1F))
            .texOffs(24, 50)
            .addBox(-2.0F, 10.0F, -2.0F, 4.0F, 2.0F, 4.0F, new CubeDeformation(0.25F)),
         PartPose.offset(-1.9F, 12.0F, 0.0F)
      );
      root.addOrReplaceChild(
         "left_leg",
         CubeListBuilder.create()
            .mirror()
            .texOffs(36, 10)
            .addBox(-2.0F, 10.0F, -2.0F, 4.0F, 2.0F, 4.0F, new CubeDeformation(0.1F))
            .texOffs(24, 50)
            .addBox(-2.0F, 10.0F, -2.0F, 4.0F, 2.0F, 4.0F, new CubeDeformation(0.25F))
            .mirror(false),
         PartPose.offset(1.9F, 12.0F, 0.0F)
      );
      return LayerDefinition.create(mesh, 128, 128);
   }

   private static HumanoidModel<?> model(ModelLayerLocation layer) {
      EntityModelSet set = Minecraft.getInstance().getEntityModelSet();
      if (set != cachedFor) {
         CACHE.clear();
         cachedFor = set;
      }

      return CACHE.computeIfAbsent(layer, l -> new HumanoidModel<LivingEntity>(set.bakeLayer(l)));
   }

   private static IClientItemExtensions ext(ModelLayerLocation layer) {
      return new IClientItemExtensions() {
         @Override
         public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
            return model(layer);
         }
      };
   }

   @SubscribeEvent
   public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
      event.registerLayerDefinition(CHEST, KillerArmorClient::chestLayer);
      event.registerLayerDefinition(LEGS, KillerArmorClient::legsLayer);
      event.registerLayerDefinition(BOOTS, KillerArmorClient::bootsLayer);
   }

   @SubscribeEvent
   public static void registerExtensions(RegisterClientExtensionsEvent event) {
      event.registerItem(ext(CHEST), TojiItems.SHIRT.get());
      event.registerItem(ext(LEGS), TojiItems.PANTS.get());
      event.registerItem(ext(BOOTS), TojiItems.BOOTS.get());
   }
}
