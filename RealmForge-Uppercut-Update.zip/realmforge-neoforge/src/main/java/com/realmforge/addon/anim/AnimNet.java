package com.realmforge.addon.anim;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

public final class AnimNet {
   private AnimNet() {
   }

   /** Sends the animation to the player and everyone tracking them. */
   public static void broadcast(ServerPlayer player, String clip, float speed) {
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new AnimPayload(player.getUUID(), clip, speed));
   }
}
