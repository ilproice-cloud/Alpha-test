package com.realmforge.addon.anim;

import com.realmforge.RealmForgeMod;
import java.io.InputStream;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;

/**
 * Plays Blockbench animation clips ({@code assets/realmforge/player_animation/<name>.json}) on player models.
 * Called from HumanoidModelMixin after vanilla poses the model.
 *
 * Clips are read through the resource manager (so resource packs and reloads work) and any failure is logged
 * with the real reason instead of being swallowed.
 */
public final class AnimClient {
   /**
    * Blockbench (Y up, front = -Z) to ModelPart (Y down) axis conventions, the same ones GeckoLib uses:
    * X and Y rotation are negated, Z is kept; X and Y translation are negated.
    * If an animation looks mirrored in game, flip the matching sign here.
    */
   public static final float[] ROT_SIGN = new float[]{-1.0F, -1.0F, 1.0F};
   public static final float[] POS_SIGN = new float[]{-1.0F, -1.0F, 1.0F};
   private static final Map<UUID, Active> ACTIVE = new ConcurrentHashMap<>();
   private static final Map<String, Clip> CACHE = new ConcurrentHashMap<>();
   private static final Clip MISSING = Clip.parse(new java.io.ByteArrayInputStream("{\"animations\":{\"x\":{}}}".getBytes())).get("x");
   /** bone names tried for each model part (some clips call the torso "torso", others "body"). */
   private static final String[][] BONES = new String[][]{
      {"head"}, {"body", "torso"}, {"right_arm"}, {"left_arm"}, {"right_leg"}, {"left_leg"}
   };

   private AnimClient() {
   }

   public static void clear() {
      ACTIVE.clear();
   }

   /** Drops cached clips (resource reload). */
   public static void reload() {
      CACHE.clear();
   }

   public static Clip clip(String name) {
      Clip c = CACHE.get(name);
      if (c == null) {
         c = load(name);
         CACHE.put(name, c == null ? MISSING : c);
      }

      return c == MISSING ? null : c;
   }

   private static Clip load(String name) {
      ResourceLocation loc = RealmForgeMod.id("player_animation/" + name + ".json");
      try {
         Resource res = Minecraft.getInstance().getResourceManager().getResource(loc).orElse(null);
         if (res == null) {
            RealmForgeMod.LOGGER.error("Player animation '{}' not found at {}", name, loc);
            return null;
         }

         try (InputStream in = res.open()) {
            Map<String, Clip> all = Clip.parse(in);
            Clip c = all.get(name);
            if (c == null && !all.isEmpty()) {
               c = all.values().iterator().next();
            }

            RealmForgeMod.LOGGER.info("Loaded player animation '{}' ({}s, {} bone tracks)", name, c == null ? 0 : c.length, c == null ? 0 : c.rot.size() + c.pos.size());
            return c;
         }
      } catch (Throwable t) {
         RealmForgeMod.LOGGER.error("Failed to load player animation '" + name + "'", t);
         return null;
      }
   }

   public static void play(UUID player, String name, float speed) {
      Clip clip = clip(name);
      if (clip != null) {
         ACTIVE.put(player, new Active(clip, System.nanoTime(), speed <= 0.0F ? 1.0F : speed));
      }
   }

   public static boolean isPlaying(UUID player) {
      return ACTIVE.containsKey(player);
   }

   private static ModelPart part(HumanoidModel<?> m, int i) {
      return switch (i) {
         case 0 -> m.head;
         case 1 -> m.body;
         case 2 -> m.rightArm;
         case 3 -> m.leftArm;
         case 4 -> m.rightLeg;
         default -> m.leftLeg;
      };
   }

   public static void apply(HumanoidModel<?> model, UUID player) {
      if (ACTIVE.isEmpty() || player == null) {
         return;
      }

      Active a = ACTIVE.get(player);
      if (a == null) {
         return;
      }

      float t = (float)(System.nanoTime() - a.start) / 1.0E9F * a.speed;
      if (t > a.clip.length) {
         ACTIVE.remove(player, a);
         return;
      }

      float[] v = new float[3];
      for (int i = 0; i < BONES.length; i++) {
         ModelPart p = part(model, i);
         for (String bone : BONES[i]) {
            Clip.Track rot = a.clip.rot.get(bone);
            if (rot != null) {
               rot.sample(t, v);
               p.xRot = (float)Math.toRadians((double)(v[0] * ROT_SIGN[0]));
               p.yRot = (float)Math.toRadians((double)(v[1] * ROT_SIGN[1]));
               p.zRot = (float)Math.toRadians((double)(v[2] * ROT_SIGN[2]));
            }

            Clip.Track pos = a.clip.pos.get(bone);
            if (pos != null) {
               pos.sample(t, v);
               if (i == 1) {
                  // vanilla never resets the body's x/z, so set it absolutely instead of accumulating
                  p.x = v[0] * POS_SIGN[0];
                  p.y = v[1] * POS_SIGN[1];
                  p.z = v[2] * POS_SIGN[2];
               } else {
                  p.x += v[0] * POS_SIGN[0];
                  p.y += v[1] * POS_SIGN[1];
                  p.z += v[2] * POS_SIGN[2];
               }
            }
         }
      }
   }

   private static final class Active {
      final Clip clip;
      final long start;
      final float speed;

      Active(Clip clip, long start, float speed) {
         this.clip = clip;
         this.start = start;
         this.speed = speed;
      }
   }
}
