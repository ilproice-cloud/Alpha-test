package com.realmforge.addon.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A Blockbench / GeckoLib style animation clip: per-bone rotation, position and scale keyframe tracks.
 * Used both for player animations and for prop-model animations (Ursus paw, ...).
 */
public final class Clip {
   public final String name;
   public final float length;
   public final boolean loop;
   public final Map<String, Track> rot = new HashMap<>();
   public final Map<String, Track> pos = new HashMap<>();
   public final Map<String, Track> scale = new HashMap<>();

   private Clip(String name, float length, boolean loop) {
      this.name = name;
      this.length = length;
      this.loop = loop;
   }

   /** Parses every animation in a file. Throws on malformed JSON so callers can log the real reason. */
   public static Map<String, Clip> parse(InputStream in) {
      JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
      Map<String, Clip> out = new LinkedHashMap<>();
      JsonObject anims = root.getAsJsonObject("animations");
      for (Map.Entry<String, JsonElement> e : anims.entrySet()) {
         JsonObject a = e.getValue().getAsJsonObject();
         float len = a.has("animation_length") ? a.get("animation_length").getAsFloat() : 0.0F;
         boolean loop = a.has("loop") && a.get("loop").isJsonPrimitive() && a.get("loop").getAsJsonPrimitive().isBoolean() && a.get("loop").getAsBoolean();
         Clip clip = new Clip(e.getKey(), len, loop);
         if (a.has("bones")) {
            for (Map.Entry<String, JsonElement> b : a.getAsJsonObject("bones").entrySet()) {
               JsonObject bone = b.getValue().getAsJsonObject();
               Track r = track(bone.get("rotation"));
               Track p = track(bone.get("position"));
               Track s = track(bone.get("scale"));
               if (r != null) {
                  clip.rot.put(b.getKey(), r);
               }

               if (p != null) {
                  clip.pos.put(b.getKey(), p);
               }

               if (s != null) {
                  clip.scale.put(b.getKey(), s);
               }
            }
         }

         out.put(e.getKey(), clip);
      }

      return out;
   }

   private static Track track(JsonElement el) {
      if (el == null || el.isJsonNull()) {
         return null;
      }

      if (el.isJsonArray()) {
         return new Track(new float[]{0.0F}, new float[][]{vec(el)});
      }

      JsonObject m = el.getAsJsonObject();
      if (m.has("vector")) {
         return new Track(new float[]{0.0F}, new float[][]{vec(m.get("vector"))});
      }

      List<float[]> keys = new ArrayList<>();
      for (Map.Entry<String, JsonElement> e : m.entrySet()) {
         float time;
         try {
            time = Float.parseFloat(e.getKey());
         } catch (NumberFormatException ex) {
            continue; // lerp_mode etc.
         }

         JsonElement v = e.getValue();
         if (v.isJsonObject()) {
            JsonObject f = v.getAsJsonObject();
            v = f.has("vector") ? f.get("vector") : (f.has("post") ? f.get("post") : f.get("pre"));
         }

         if (v == null || !v.isJsonArray()) {
            continue;
         }

         float[] xyz = vec(v);
         keys.add(new float[]{time, xyz[0], xyz[1], xyz[2]});
      }

      if (keys.isEmpty()) {
         return null;
      }

      keys.sort((x, y) -> Float.compare(x[0], y[0]));
      float[] times = new float[keys.size()];
      float[][] vals = new float[keys.size()][];
      for (int i = 0; i < times.length; i++) {
         float[] k = keys.get(i);
         times[i] = k[0];
         vals[i] = new float[]{k[1], k[2], k[3]};
      }

      return new Track(times, vals);
   }

   private static float[] vec(JsonElement o) {
      JsonArray list = o.getAsJsonArray();
      float[] out = new float[3];
      for (int i = 0; i < 3 && i < list.size(); i++) {
         JsonElement x = list.get(i);
         try {
            out[i] = x.isJsonPrimitive() && x.getAsJsonPrimitive().isNumber() ? x.getAsFloat() : Float.parseFloat(x.getAsString());
         } catch (RuntimeException ex) {
            out[i] = 0.0F; // molang expressions are not supported; treat as 0
         }
      }

      return out;
   }

   public static final class Track {
      final float[] times;
      final float[][] vals;

      Track(float[] times, float[][] vals) {
         this.times = times;
         this.vals = vals;
      }

      public void sample(float t, float[] out) {
         int n = this.times.length;
         if (n == 1 || t <= this.times[0]) {
            copy(this.vals[0], out);
         } else if (t >= this.times[n - 1]) {
            copy(this.vals[n - 1], out);
         } else {
            int i = 0;
            while (i < n - 2 && t >= this.times[i + 1]) {
               i++;
            }

            float span = this.times[i + 1] - this.times[i];
            float f = span <= 0.0F ? 0.0F : (t - this.times[i]) / span;
            for (int k = 0; k < 3; k++) {
               out[k] = this.vals[i][k] + (this.vals[i + 1][k] - this.vals[i][k]) * f;
            }
         }
      }

      private static void copy(float[] src, float[] dst) {
         dst[0] = src[0];
         dst[1] = src[1];
         dst[2] = src[2];
      }
   }
}
