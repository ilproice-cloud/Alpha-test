package com.realmforge.addon.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import com.realmforge.addon.data.Clan;
import com.realmforge.data.Perk;
import com.realmforge.data.Rank;
import com.realmforge.data.RpgData;
import com.realmforge.data.Trait;

public final class BookPages {
   private BookPages() {
   }

   private static MutableComponent t(String var0, Formatting... var1) {
      return Component.literal(var0).withStyle(var1);
   }

   private static Clan clan(RpgData var0) {
      return var0 == null ? null : Clan.byId(var0.clan());
   }

   public static Component player(RpgData var0, String var1) {
      Rank var2 = var0.rank();
      Trait var3 = var0.trait();
      Perk var4 = var0.perk();
      Clan var5 = clan(var0);
      MutableComponent var6 = Component.empty();
      var6.append(t("PLAYER\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      var6.append(t("[" + var2.icon + "] " + var1 + "\n", ChatFormatting.BOLD, ChatFormatting.WHITE));
      var6.append(t("Rank: ", ChatFormatting.DARK_GRAY)).append(t(var2.label + "\n", ChatFormatting.BOLD, var2.bookColor));
      var6.append(t("Level: ", ChatFormatting.DARK_GRAY)).append(t(var0.level + "\n", ChatFormatting.WHITE));
      var6.append(t("EXP: ", ChatFormatting.DARK_GRAY))
         .append(t(var0.level >= 100 ? "MAX\n" : var0.exp + " / " + var0.expRequired() + "\n", ChatFormatting.WHITE));
      Rank var7 = var2.next();
      if (var7 != null) {
         var6.append(
            t("Next: " + var7.label + " (Lv" + var7.minLevel + ", " + var7.minKills + " kills; you: " + var0.kills + ")\n", ChatFormatting.GRAY)
         );
      }

      var6.append(t("\nTrait: ", ChatFormatting.DARK_GRAY));
      if (var3 != null) {
         var6.append(t(var3.displayName(), var3.rarity().bookColor, ChatFormatting.BOLD))
            .append(t(" (" + var3.rarity().label + ")\n", var3.rarity().bookColor));
      }

      var6.append(t("Perk: ", ChatFormatting.DARK_GRAY));
      if (var4 != null) {
         var6.append(t(var4.displayName(), var4.rarity().bookColor, ChatFormatting.BOLD))
            .append(t(" (" + var4.rarity().label + ")\n", var4.rarity().bookColor));
      }

      var6.append(t("Clan: ", ChatFormatting.DARK_GRAY));
      if (var5 != null) {
         var6.append(t(var5.display, var5.rarity.bookColor, ChatFormatting.BOLD))
            .append(t(" (" + var5.rarity.label + ")\n", var5.rarity.bookColor));
      } else {
         var6.append(t("None\n", ChatFormatting.GRAY));
      }

      var6.append(t("\nStat points: ", ChatFormatting.DARK_GRAY))
         .append(t(String.valueOf(var0.points), var0.points > 0 ? ChatFormatting.DARK_GREEN : ChatFormatting.WHITE, ChatFormatting.BOLD));
      return var6;
   }

   public static Component references(RpgData var0) {
      Trait var1 = var0.trait();
      Perk var2 = var0.perk();
      Clan var3 = clan(var0);
      MutableComponent var4 = Component.empty();
      var4.append(t("REFERENCES\n\n", ChatFormatting.BOLD, ChatFormatting.DARK_PURPLE));
      var4.append(t("Use the Information page to browse all traits, perks and your clan.\n\n", ChatFormatting.DARK_AQUA));
      var4.append(t("Your trait:\n", ChatFormatting.DARK_GRAY));
      if (var1 != null) {
         var4.append(t(var1.displayName() + " (" + var1.rarity().label + ")\n\n", var1.rarity().bookColor, ChatFormatting.BOLD));
      }

      var4.append(t("Your perk:\n", ChatFormatting.DARK_GRAY));
      if (var2 != null) {
         var4.append(t(var2.displayName() + " (" + var2.rarity().label + ")\n\n", var2.rarity().bookColor, ChatFormatting.BOLD));
      }

      var4.append(t("Your clan:\n", ChatFormatting.DARK_GRAY));
      if (var3 != null) {
         var4.append(t(var3.display + " (" + var3.rarity.label + ")\n\n", var3.rarity.bookColor, ChatFormatting.BOLD));
      } else {
         var4.append(t("None\n\n", ChatFormatting.GRAY));
      }

      var4.append(t("All are permanent.", ChatFormatting.GRAY));
      return var4;
   }
}

