# RealmForge – NeoForge 1.21.1 port (UNTESTED source)

Port of the Fabric mod `realmforge-fused-1_12_5-no-skills.jar` (RealmForge 1.0.0 + "Fused Update" addon)
to **NeoForge 1.21.1**. Mod id: `realmforge`. The two Fabric mods (core + addon) are merged into one.

## Build
1. Install JDK 21 and Gradle (or open the folder in IntelliJ / Eclipse; it will import `build.gradle`).
2. `gradle wrapper` (once), then `./gradlew build` -> `build/libs/realmforge-neoforge-1.12.5.jar`.
3. Put the jar in a NeoForge 1.21.1 `mods` folder. Photon (optional) plays the `.fx` files in `assets/photon/fx`.

`build.gradle` pins ModDevGradle `2.0.78` and NeoForge `21.1.172` (gradle.properties). If Gradle can't resolve
them, change to any current 21.1.x / ModDevGradle 2.x release.

## IMPORTANT: this was written without being able to compile against Minecraft
The sandbox could not reach the NeoForge / Mojang Maven servers. Plain-Java classes were compile-tested and the
animation loader was run against your real `.json` clips, but everything touching Minecraft/NeoForge APIs has
**not** been compiled. Expect a few compile errors on first build; send them back and they are quick to fix.

Names I had to infer from context (Yarn mappings don't name these constants), worth a glance if behaviour looks off:
- `BlockTags.LOGS` (1 EXP for logs), `ParticleTypes.CLOUD` (dodge puff), `SoundEvents.ARMOR_EQUIP_GENERIC`,
  `SoundEvents.PLAYER_LEVELUP` / `UI_TOAST_CHALLENGE_COMPLETE`, `DamageTypeTags.BYPASSES_INVULNERABILITY`
- `ChatFormatting` colours (derived from usage, e.g. Legend rank = YELLOW / WHITE)

## What changed vs the Fabric jar
- Fabric API events/networking -> NeoForge events and payload registrar (`RegisterPayloadHandlersEvent`).
- Mixins folded into the code they patched (RpgData, DamagePipeline, RpgBook, RpgBookScreen, SkillExecutor).
  Only one client mixin remains (`HumanoidModelMixin`: skill-animation hook + blocking pose).
- Damage: `LivingIncomingDamageEvent` (dodge, Toji fall-cancel, damage scaling, blocking).
- Armor: custom model now uses NeoForge client extensions; textures copied to `textures/models/armor/`.
- Animation player used reflection on obfuscated field names (would silently fail in production on Fabric);
  it now accesses the model fields directly.

## Things you should know about the ORIGINAL jar
- `IceSpikesSkill` is referenced by the jar (skill use + Skill Book screen) but **is not included** (the "no-skills"
  build removed it). On Fabric, pressing a skill key / opening the Skill Book would throw NoClassDefFoundError.
  Here it is a stub: skills do nothing and the Skill Book shows "No skills unlocked yet."
- The three base skills (Electro Barrage / Dropkick / Double Scratch) were cancelled by the addon, so their code
  was not ported. `Combat` (combat regen penalty) was never registered in the jar and is not ported.
- `assets/realmforge/electro/skills.json` and the Electro animations are data only; no Java code ever used them.
- The welcome message says "Press K", but the real keys are M (RPG book), N (skill book), Z/X/C, F (block).

## Electro skills
See CHANGES.md (what changed) and UNVERIFIED.md (what still needs testing). Quick start: put Photon + LDLib2 jars in `libs/`, build, then in game run `/realmforge skill unlock all`, press N, select a skill, click [ EQUIP ] and a key.
