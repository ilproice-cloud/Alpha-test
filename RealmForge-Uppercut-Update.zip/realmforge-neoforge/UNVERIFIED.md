# What could NOT be verified (please read)

**Nothing was compiled or run in game.** My sandbox blocks the NeoForge/Mojang/Gradle-plugin Maven servers, so I could not build against Minecraft, produce a JAR, or launch the game. What I did verify:
- All new/changed Java has no syntax errors (javac parse of every file; only "missing Minecraft symbol" errors remain, as expected without the game jars).
- `PhotonBridge` compiles against the real Photon 2.2.10 + LDLib2 2.2.45 jars.
- `Clip` parser loads all 18 player animations + prop animations (unit-run).
- Every non-vanilla texture referenced by the 68 FX resolves (except `photon:textures/particle/ring.png`, which ships inside Photon).
Expect to fix a handful of compile errors from Minecraft 1.21.1 API details when you first build.

## Missing original art (not in any file you gave me)
- **Original FX files not supplied:** gorocloud, pgoroanimalglow2, varismashvfx, pgoroaura6, pgoroauraex1, drunkrandom, spinblolololo, pikashine, pawpuff, psmokedark1, yellowlightinggamme1, opelightinggamme6, karicharge, karii, pgororingbigggg1. The skills therefore use the closest *supplied* original FX (e.g. goroaura/kaidolightning for the Fist charge/impact). Nothing was invented.
- **Particle textures:** only 4 are original (lightning1, gorolightningtest, hakilightning, hakilightningtest). The rest in `assets/trueprimepiecetwo/textures/particle/` are the **white stand-ins from the earlier build** (see PLACEHOLDERS.txt). Copy the original mod's PNGs over them (same names) for the true look.
- The original skill logic (Forge 1.20.1 MCreator procedures + custom mob effects) was not portable 1:1; timings, damage, ranges and hitboxes are my reconstruction from the original animations, FX/sound names and procedure strings. Compare against your video and tune the numbers at the top of each `skill/skills/*.java`.
- Your video shows different skill names (Electro Claws, Thrash, Raijin Smite, Electric Drop); I could not match it frame-by-frame.

## Needs an in-game check
- **Animation axis signs** (`AnimClient.ROT_SIGN/POS_SIGN`, GeckoLib-style). If a pose looks mirrored, flip the sign; use `/rfanim <clip>` to test fast. Body bones pivot differently in Blockbench vs the vanilla model.
- **Photon FX placement**: offsets are the original ones relative to the entity's eye position (Photon 2.2.10 anchor). Old Photon-1.x FX files go through Photon's own version fixer; I could not confirm every file loads. Watch the log for `[skills]` warnings.
- Gorobolt/Ursus model orientation and size (axis conversion follows GeckoLib conventions).
- Multiplayer: logic is server-authoritative and FX go to tracking players only, but it was not tested with two clients.
- Gradle: `libs/` must contain the Photon and LDLib2 jars; moddev `localRuntime` for dev runs may need the jars in `run/mods` instead.
