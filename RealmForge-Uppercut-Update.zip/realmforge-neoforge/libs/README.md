# libs/

Drop the Photon and LDLib2 jars you play with here (they are compile-time only; they are NOT bundled into the mod):

- `photon-neoforge-1.21.1-2.2.10-all.jar`
- `ldlib2-neoforge-1.21.1-2.2.45-all.jar`

`./gradlew build` fails early with a clear message if this folder has no jars.
For GitHub Actions, either commit the two jars here (check their licences first) or let the workflow download them
from the URLs you put in the repository variables `PHOTON_JAR_URL` and `LDLIB2_JAR_URL`.
