package com.realmforge.addon.client;

import com.realmforge.addon.logic.SkillManager;
import com.realmforge.addon.net.SkillAssignPayload;
import com.realmforge.addon.skill.Skill;
import com.realmforge.client.ClientRpg;
import com.realmforge.data.RpgData;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Skills menu: every unlocked skill on one page (scrolls if there are more than fit). Click a skill to select it,
 * press Quit to reveal the Z / X / C buttons, pick one to assign the selected skill to that key. Assignments are
 * stored server-side in the player's RPG data, so they persist between sessions.
 */
public class SkillScreen extends Screen {
   private static final int ROW_H = 54;
   private static final int ROW_GAP = 4;
   private Button quit;
   private final Button[] keyButtons = new Button[3];
   private String selected;
   private boolean revealed;
   private int scroll;

   public SkillScreen() {
      super(Component.literal("Skills"));
   }

   private List<Skill> unlocked() {
      List<Skill> out = new ArrayList<>();
      RpgData d = ClientRpg.data;
      if (d != null) {
         for (Skill s : Skill.values()) {
            if (d.skills.contains(s.id)) {
               out.add(s);
            }
         }
      }

      return out;
   }

   private int panelW() {
      return Math.min(340, this.width - 20);
   }

   private int listTop() {
      return 36;
   }

   private int listBottom() {
      return this.height - 78;
   }

   @Override
   protected void init() {
      int cx = this.width / 2;
      this.quit = Button.builder(Component.literal("Quit"), b -> this.onQuit()).bounds(cx - 50, this.height - 30, 100, 20).build();
      this.addRenderableWidget(this.quit);

      for (int i = 0; i < 3; i++) {
         final int slot = i;
         Button b = Button.builder(Component.literal(SkillManager.KEY_NAMES[i]), x -> this.assign(slot)).bounds(cx - 66 + i * 46, this.height - 56, 40, 20).build();
         b.visible = this.revealed;
         b.active = this.revealed;
         this.keyButtons[i] = b;
         this.addRenderableWidget(b);
      }
   }

   private void onQuit() {
      if (this.selected != null && !this.revealed) {
         this.revealed = true;
         for (Button b : this.keyButtons) {
            b.visible = true;
            b.active = true;
         }
      } else {
         this.onClose();
      }
   }

   private void assign(int slot) {
      if (this.selected != null) {
         PacketDistributor.sendToServer(new SkillAssignPayload(slot, this.selected));
      }

      this.onClose();
   }

   @Override
   public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
      super.render(g, mouseX, mouseY, partialTick); // background + buttons
      int cx = this.width / 2;
      g.drawCenteredString(this.font, Component.literal("Skills"), cx, 14, 0xFFD700);

      List<Skill> list = this.unlocked();
      int left = cx - this.panelW() / 2;
      int right = cx + this.panelW() / 2;
      int top = this.listTop();
      int bottom = this.listBottom();

      if (list.isEmpty()) {
         g.drawCenteredString(this.font, Component.literal("You haven't unlocked any skills yet."), cx, top + 20, 0xAAAAAA);
      } else {
         int maxScroll = Math.max(0, list.size() * (ROW_H + ROW_GAP) - (bottom - top));
         this.scroll = Math.max(0, Math.min(maxScroll, this.scroll));
         g.enableScissor(left, top, right, bottom);
         RpgData d = ClientRpg.data;
         for (int i = 0; i < list.size(); i++) {
            Skill s = list.get(i);
            int y = top + i * (ROW_H + ROW_GAP) - this.scroll;
            if (y + ROW_H < top || y > bottom) {
               continue;
            }

            boolean sel = s.id.equals(this.selected);
            boolean hover = mouseX >= left && mouseX < right && mouseY >= Math.max(y, top) && mouseY < Math.min(y + ROW_H, bottom);
            g.fill(left, y, right, y + ROW_H, sel ? 0xCC3A3000 : (hover ? 0xCC333333 : 0xCC1A1A1A));
            g.renderOutline(left, y, right - left, ROW_H, sel ? 0xFFFFD700 : 0xFF555555);

            g.drawString(this.font, s.title(), left + 6, y + 5, sel ? 0xFFD700 : 0xFFFFFF);
            String keyText = "Not assigned";
            for (int k = 0; k < 3; k++) {
               if (d != null && s.id.equals(d.skillKeys[k])) {
                  keyText = "[" + SkillManager.KEY_NAMES[k] + "]";
               }
            }

            g.drawString(this.font, keyText, right - 6 - this.font.width(keyText), y + 5, keyText.startsWith("[") ? 0x55FF55 : 0x888888);
            String stats = String.format(Locale.ROOT, "Energy %.0f  |  Cooldown %.1fs  |  Range %.1f", s.energy, s.cooldownSeconds(), s.range);
            g.drawString(this.font, stats, left + 6, y + 17, 0x55FFFF);
            List<FormattedCharSequence> lines = this.font.split(Component.literal(s.description), right - left - 12);
            for (int l = 0; l < Math.min(2, lines.size()); l++) {
               g.drawString(this.font, lines.get(l), left + 6, y + 29 + l * 10, 0xBBBBBB, false);
            }
         }

         g.disableScissor();
      }

      if (this.revealed && this.selected != null) {
         Skill s = Skill.byId(this.selected);
         String name = s == null ? "" : s.display;
         g.drawCenteredString(this.font, Component.literal("Assign " + name + " to:"), cx, this.height - 70, 0xFFFFFF);
      } else if (this.selected != null) {
         g.drawCenteredString(this.font, Component.literal("Press Quit to choose a key for the selected skill"), cx, this.height - 46, 0x888888);
      }
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (super.mouseClicked(mouseX, mouseY, button)) {
         return true;
      }

      if (button == 0) {
         List<Skill> list = this.unlocked();
         int cx = this.width / 2;
         int left = cx - this.panelW() / 2;
         int right = cx + this.panelW() / 2;
         if (mouseX >= left && mouseX < right && mouseY >= this.listTop() && mouseY < this.listBottom()) {
            int idx = (int)((mouseY - this.listTop() + this.scroll) / (ROW_H + ROW_GAP));
            double within = (mouseY - this.listTop() + this.scroll) - idx * (ROW_H + ROW_GAP);
            if (idx >= 0 && idx < list.size() && within <= ROW_H) {
               this.selected = list.get(idx).id;
               return true;
            }
         }
      }

      return false;
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      this.scroll -= (int)(scrollY * 14.0);
      return true;
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
