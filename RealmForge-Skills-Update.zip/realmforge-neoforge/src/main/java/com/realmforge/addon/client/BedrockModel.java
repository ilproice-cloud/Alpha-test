package com.realmforge.addon.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.realmforge.RealmForgeMod;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joml.Matrix4f;

/**
 * Minimal Bedrock geometry (.geo.json, format 1.12) renderer, written to match what GeckoLib did with the Prime Punch
 * models: X is mirrored, X/Y rotations are negated, bone pivots are absolute, and the transform order per bone is
 * translate(position) -> pivot -> rotate Z,Y,X -> scale -> -pivot. Box UVs use the standard Bedrock layout.
 */
public final class BedrockModel {
   private static final class Cube {
      float ox, oy, oz, sx, sy, sz, u, v;
   }

   private static final class Bone {
      String name;
      String parent;
      float[] pivot = new float[3];
      float[] rot = new float[3];
      final List<Cube> cubes = new ArrayList<>();
      final List<Bone> children = new ArrayList<>();
   }

   private int texW = 64;
   private int texH = 64;
   private final List<Bone> roots = new ArrayList<>();

   private BedrockModel() {
   }

   public static BedrockModel load(String classpath) {
      try (InputStream in = BedrockModel.class.getResourceAsStream(classpath)) {
         if (in == null) {
            RealmForgeMod.LOGGER.error("Model file not found: {}", classpath);
            return null;
         }

         JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         JsonObject geo = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
         BedrockModel m = new BedrockModel();
         JsonObject desc = geo.getAsJsonObject("description");
         m.texW = desc.get("texture_width").getAsInt();
         m.texH = desc.get("texture_height").getAsInt();

         Map<String, Bone> byName = new HashMap<>();
         List<Bone> all = new ArrayList<>();
         for (JsonElement be : geo.getAsJsonArray("bones")) {
            JsonObject bo = be.getAsJsonObject();
            Bone b = new Bone();
            b.name = bo.get("name").getAsString();
            b.parent = bo.has("parent") ? bo.get("parent").getAsString() : null;
            if (bo.has("pivot")) {
               b.pivot = arr(bo.getAsJsonArray("pivot"));
            }

            if (bo.has("rotation")) {
               b.rot = arr(bo.getAsJsonArray("rotation"));
            }

            if (bo.has("cubes")) {
               for (JsonElement ce : bo.getAsJsonArray("cubes")) {
                  JsonObject co = ce.getAsJsonObject();
                  if (!co.has("uv") || !co.get("uv").isJsonArray()) {
                     continue; // per-face uv not used by the Prime Punch models
                  }

                  Cube c = new Cube();
                  float[] o = arr(co.getAsJsonArray("origin"));
                  float[] s = arr(co.getAsJsonArray("size"));
                  float[] uv = arr(co.getAsJsonArray("uv"));
                  c.ox = o[0];
                  c.oy = o[1];
                  c.oz = o[2];
                  c.sx = s[0];
                  c.sy = s[1];
                  c.sz = s[2];
                  c.u = uv[0];
                  c.v = uv[1];
                  b.cubes.add(c);
               }
            }

            byName.put(b.name, b);
            all.add(b);
         }

         for (Bone b : all) {
            Bone p = b.parent == null ? null : byName.get(b.parent);
            if (p == null) {
               m.roots.add(b);
            } else {
               p.children.add(b);
            }
         }

         return m;
      } catch (Exception e) {
         RealmForgeMod.LOGGER.error("Failed to load model " + classpath, e);
         return null;
      }
   }

   private static float[] arr(JsonArray a) {
      return new float[] {a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.get(2).getAsFloat()};
   }

   /** Draws the model with the animation sampled at {@code t} seconds. Origin = model origin, -Z = forward. */
   public void render(PoseStack ps, VertexConsumer vc, BedrockAnim anim, float t, int light, int overlay) {
      for (Bone b : this.roots) {
         this.renderBone(b, ps, vc, anim, t, light, overlay);
      }
   }

   private void renderBone(Bone b, PoseStack ps, VertexConsumer vc, BedrockAnim anim, float t, int light, int overlay) {
      float[] pos = anim == null ? null : anim.sample(b.name, "position", t);
      float[] rot = anim == null ? null : anim.sample(b.name, "rotation", t);
      float[] scl = anim == null ? null : anim.sample(b.name, "scale", t);

      ps.pushPose();
      float px = -b.pivot[0];
      float py = b.pivot[1];
      float pz = b.pivot[2];
      if (pos != null) {
         ps.translate(-pos[0] / 16.0F, pos[1] / 16.0F, pos[2] / 16.0F);
      }

      ps.translate(px / 16.0F, py / 16.0F, pz / 16.0F);
      float rx = (float)Math.toRadians(-(b.rot[0] + (rot == null ? 0.0F : rot[0])));
      float ry = (float)Math.toRadians(-(b.rot[1] + (rot == null ? 0.0F : rot[1])));
      float rz = (float)Math.toRadians(b.rot[2] + (rot == null ? 0.0F : rot[2]));
      if (rz != 0.0F) {
         ps.mulPose(Axis.ZP.rotation(rz));
      }

      if (ry != 0.0F) {
         ps.mulPose(Axis.YP.rotation(ry));
      }

      if (rx != 0.0F) {
         ps.mulPose(Axis.XP.rotation(rx));
      }

      if (scl != null) {
         ps.scale(scl[0], scl[1], scl[2]);
      }

      ps.translate(-px / 16.0F, -py / 16.0F, -pz / 16.0F);

      Matrix4f m = ps.last().pose();
      for (Cube c : b.cubes) {
         this.cube(m, vc, c, light, overlay);
      }

      for (Bone child : b.children) {
         this.renderBone(child, ps, vc, anim, t, light, overlay);
      }

      ps.popPose();
   }

   /** Six faces with Bedrock box-UV layout: [east][north][west][south] on the lower row, up/down above. */
   private void cube(Matrix4f m, VertexConsumer vc, Cube c, int light, int overlay) {
      float x0 = c.ox;
      float x1 = c.ox + c.sx;
      float y0 = c.oy;
      float y1 = c.oy + c.sy;
      float z0 = c.oz;
      float z1 = c.oz + c.sz;
      float w = c.sx;
      float h = c.sy;
      float d = c.sz;
      float u = c.u;
      float v = c.v;

      // north (-Z, front)
      this.face(m, vc, light, overlay, u + d, v + d, w, h, x1, y1, z0, x0, y1, z0, x0, y0, z0, x1, y0, z0);
      // south (+Z, back) - this is the side you see from behind the player, where the ring texture is
      this.face(m, vc, light, overlay, u + d + w + d, v + d, w, h, x0, y1, z1, x1, y1, z1, x1, y0, z1, x0, y0, z1);
      // east (+X)
      this.face(m, vc, light, overlay, u, v + d, d, h, x1, y1, z1, x1, y1, z0, x1, y0, z0, x1, y0, z1);
      // west (-X)
      this.face(m, vc, light, overlay, u + d + w, v + d, d, h, x0, y1, z0, x0, y1, z1, x0, y0, z1, x0, y0, z0);
      // up (+Y)
      this.face(m, vc, light, overlay, u + d, v, w, d, x1, y1, z1, x0, y1, z1, x0, y1, z0, x1, y1, z0);
      // down (-Y)
      this.face(m, vc, light, overlay, u + d + w, v, w, d, x1, y0, z0, x0, y0, z0, x0, y0, z1, x1, y0, z1);
   }

   /** Corners in order top-left, top-right, bottom-right, bottom-left of the uv region (ru, rv, rw, rh). */
   private void face(
      Matrix4f m, VertexConsumer vc, int light, int overlay, float ru, float rv, float rw, float rh,
      float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float dx, float dy, float dz
   ) {
      if (rw <= 0.0F || rh <= 0.0F) {
         return; // degenerate face (e.g. the side of a flat plane)
      }

      float u0 = ru / this.texW;
      float u1 = (ru + rw) / this.texW;
      float v0 = rv / this.texH;
      float v1 = (rv + rh) / this.texH;
      // draw each quad twice with opposite winding so it shows from both sides regardless of culling
      this.vertex(m, vc, ax, ay, az, u0, v0, light, overlay);
      this.vertex(m, vc, bx, by, bz, u1, v0, light, overlay);
      this.vertex(m, vc, cx, cy, cz, u1, v1, light, overlay);
      this.vertex(m, vc, dx, dy, dz, u0, v1, light, overlay);
      this.vertex(m, vc, dx, dy, dz, u0, v1, light, overlay);
      this.vertex(m, vc, cx, cy, cz, u1, v1, light, overlay);
      this.vertex(m, vc, bx, by, bz, u1, v0, light, overlay);
      this.vertex(m, vc, ax, ay, az, u0, v0, light, overlay);
   }

   private void vertex(Matrix4f m, VertexConsumer vc, float x, float y, float z, float u, float v, int light, int overlay) {
      // file coordinates -> render coordinates: X mirrored, pixels -> blocks
      vc.addVertex(m, -x / 16.0F, y / 16.0F, z / 16.0F).setColor(255, 255, 255, 255).setUv(u, v).setOverlay(overlay).setLight(light).setNormal(0.0F, 1.0F, 0.0F);
   }
}
