package com.realmforge.addon.skill;

import com.realmforge.RealmForgeMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** The non-Photon rock debris particles from the Prime Punch zip (used on Heavy Punch / Uppercut impacts). */
public final class SkillParticles {
   public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, RealmForgeMod.MOD_ID);
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> ROCK = PARTICLES.register("rock_particles", () -> new SimpleParticleType(false));
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> BIG_ROCK = PARTICLES.register("big_rock_particles", () -> new SimpleParticleType(false));

   private SkillParticles() {
   }
}
