package com.realmforge.addon.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Falling rock debris using the Prime Punch rock particle sprites. */
public class RockParticle extends TextureSheetParticle {
   private RockParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites, float size, int life) {
      super(level, x, y, z);
      this.xd = vx;
      this.yd = vy + 0.1;
      this.zd = vz;
      this.quadSize = size;
      this.lifetime = life + this.random.nextInt(8);
      this.gravity = 0.9F;
      this.friction = 0.96F;
      this.hasPhysics = true;
      this.pickSprite(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   /** small debris */
   public static ParticleProvider<SimpleParticleType> small(SpriteSet sprites) {
      return (type, level, x, y, z, vx, vy, vz) -> new RockParticle(level, x, y, z, vx, vy, vz, sprites, 0.04F + level.random.nextFloat() * 0.03F, 16);
   }

   /** big chunks */
   public static ParticleProvider<SimpleParticleType> big(SpriteSet sprites) {
      return (type, level, x, y, z, vx, vy, vz) -> new RockParticle(level, x, y, z, vx, vy, vz, sprites, 0.08F + level.random.nextFloat() * 0.05F, 22);
   }
}
