package com.realmforge.addon.skill;

import net.minecraft.network.chat.Component;

/**
 * The skills a player can unlock, assign to Z / X / C and use. Resource names point at the files copied
 * from the Prime Punch zip (assets/realmforge/skills/...). Tune the numbers here.
 */
public enum Skill {
   //     id            name           description                                                                  res          tex          energy cooldown range dmg    strFactor dur  needsTarget
   BARRAGE("barrage", "Barrage", "A rapid flurry of punches that hammers the closest enemy in front of you.", "barrage", "barrage", 4.0F, 200, 4.0, 1.5F, 0.2, 20, true),
   HEAVY_PUNCH("heavy_punch", "Heavy Punch", "One crushing punch with huge impact that sends enemies flying back.", "heavypunch", "heavypunch", 3.0F, 160, 3.5, 10.0F, 1.5, 9, false),
   UPPERCUT("uppercut", "Uppercut", "A powerful upward punch that launches enemies into the air.", "uppercut", "heavypunch", 2.0F, 120, 3.5, 8.0F, 1.0, 15, false);

   public final String id;
   public final String display;
   public final String description;
   /** base name of the geo / animation / player-animation files */
   public final String resource;
   /** texture under assets/realmforge/textures/entities/ (Uppercut reuses heavypunch, like the original VFX entity) */
   public final String texture;
   public final float energy;
   public final int cooldownTicks;
   /** reach in blocks (horizontal, measured to the edge of the target) */
   public final double range;
   /** base damage per hit before Realm Forge scaling (trait / perk damage-out) */
   public final float damage;
   /** multiplier on the flat STR damage (see DamagePipeline). Multi-hit skills use a small value per hit. */
   public final double strFactor;
   /** how long the skill locks the player, in ticks (matches the original animation length) */
   public final int durationTicks;
   /** true: needs an enemy in range to start (no energy spent / no cooldown otherwise) */
   public final boolean needsTarget;

   Skill(String id, String display, String description, String resource, String texture, float energy, int cooldownTicks, double range, float damage, double strFactor, int durationTicks, boolean needsTarget) {
      this.id = id;
      this.display = display;
      this.description = description;
      this.resource = resource;
      this.texture = texture;
      this.energy = energy;
      this.cooldownTicks = cooldownTicks;
      this.range = range;
      this.damage = damage;
      this.strFactor = strFactor;
      this.durationTicks = durationTicks;
      this.needsTarget = needsTarget;
   }

   public Component title() {
      return Component.literal(this.display);
   }

   public double cooldownSeconds() {
      return this.cooldownTicks / 20.0;
   }

   public static Skill byId(String id) {
      if (id == null || id.isEmpty()) {
         return null;
      }

      for (Skill s : values()) {
         if (s.id.equals(id)) {
            return s;
         }
      }

      return null;
   }
}
