package com.realmforge.addon.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.realmforge.RealmForgeMod;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal Bedrock / Blockbench animation player (the format used by the Prime Punch .animation.json and
 * player_animation .json files). Supports rotation / position / scale tracks, "vector" and plain-array keyframes,
 * static (non keyframed) values, and the common easing names (linear, step, easeIn/Out/InOut Sine..Circ).
 * No GeckoLib needed.
 */
public final class BedrockAnim {
   public final float length;
   private final Map<String, Track> tracks = new HashMap<>();

   private static final class Key {
      float time;
      float[] value;
      String easing = "linear";
      float[] args = new float[0];
   }

   private static final class Track {
      final List<Key> keys = new ArrayList<>();
      float[] fixed;
   }

   private BedrockAnim(float length) {
      this.length = length;
   }

   /** Loads the first animation of a classpath json file, or null if it can't be read. */
   public static BedrockAnim load(String classpath) {
      try (InputStream in = BedrockAnim.class.getResourceAsStream(classpath)) {
         if (in == null) {
            RealmForgeMod.LOGGER.error("Animation file not found: {}", classpath);
            return null;
         }

         JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         JsonObject all = root.getAsJsonObject("animations");
         String first = all.keySet().iterator().next();
         return parse(all.getAsJsonObject(first));
      } catch (Exception e) {
         RealmForgeMod.LOGGER.error("Failed to load animation " + classpath, e);
         return null;
      }
   }

   static BedrockAnim parse(JsonObject a) {
      BedrockAnim r = new BedrockAnim(a.has("animation_length") ? a.get("animation_length").getAsFloat() : 1.0F);
      if (!a.has("bones")) {
         return r;
      }

      JsonObject bones = a.getAsJsonObject("bones");
      for (String bone : bones.keySet()) {
         JsonObject b = bones.getAsJsonObject(bone);
         for (String channel : new String[] {"rotation", "position", "scale"}) {
            if (!b.has(channel)) {
               continue;
            }

            Track t = new Track();
            JsonElement el = b.get(channel);
            if (el.isJsonObject()) {
               JsonObject ch = el.getAsJsonObject();
               if (ch.has("vector") && !isTimeKeyed(ch)) {
                  t.fixed = vec(ch.get("vector"));
               } else {
                  for (String time : ch.keySet()) {
                     Key k = new Key();
                     try {
                        k.time = Float.parseFloat(time);
                     } catch (NumberFormatException ex) {
                        continue;
                     }

                     JsonElement v = ch.get(time);
                     if (v.isJsonObject()) {
                        JsonObject vo = v.getAsJsonObject();
                        JsonElement vv = vo.has("vector") ? vo.get("vector") : vo.get("post");
                        k.value = vec(vv);
                        if (vo.has("easing")) {
                           k.easing = vo.get("easing").getAsString();
                        }

                        if (vo.has("easingArgs") && vo.get("easingArgs").isJsonArray()) {
                           JsonArray ea = vo.getAsJsonArray("easingArgs");
                           k.args = new float[ea.size()];
                           for (int i = 0; i < ea.size(); i++) {
                              k.args[i] = num(ea.get(i));
                           }
                        }
                     } else {
                        k.value = vec(v);
                     }

                     if (k.value != null) {
                        t.keys.add(k);
                     }
                  }

                  t.keys.sort((x, y) -> Float.compare(x.time, y.time));
               }
            } else {
               t.fixed = vec(el);
            }

            if (t.fixed != null || !t.keys.isEmpty()) {
               r.tracks.put(bone + "/" + channel, t);
            }
         }
      }

      return r;
   }

   /** a channel object whose keys are all times (digits) vs. a single {"vector": [...]} value */
   private static boolean isTimeKeyed(JsonObject ch) {
      for (String k : ch.keySet()) {
         try {
            Float.parseFloat(k);
            return true;
         } catch (NumberFormatException ignored) {
         }
      }

      return false;
   }

   private static float[] vec(JsonElement e) {
      if (e == null) {
         return null;
      }

      if (e.isJsonArray() && e.getAsJsonArray().size() >= 3) {
         JsonArray a = e.getAsJsonArray();
         return new float[] {num(a.get(0)), num(a.get(1)), num(a.get(2))};
      }

      if (e.isJsonPrimitive()) {
         float n = num(e);
         return new float[] {n, n, n};
      }

      return null;
   }

   private static float num(JsonElement e) {
      try {
         return e.getAsFloat();
      } catch (Exception ex) {
         return 0.0F; // molang expressions are not supported
      }
   }

   /** Value of a bone channel ("rotation" / "position" / "scale") at time t seconds, or null if the bone has no such channel. */
   public float[] sample(String bone, String channel, float t) {
      Track tr = this.tracks.get(bone + "/" + channel);
      if (tr == null) {
         return null;
      }

      if (tr.fixed != null) {
         return tr.fixed.clone();
      }

      List<Key> k = tr.keys;
      Key first = k.get(0);
      if (t <= first.time) {
         return first.value.clone();
      }

      for (int i = 1; i < k.size(); i++) {
         Key b = k.get(i);
         if (t <= b.time) {
            Key a = k.get(i - 1);
            float f = (t - a.time) / Math.max(1.0E-5F, b.time - a.time);
            f = ease(b.easing, b.args, f); // the easing of the keyframe being arrived at shapes the segment
            return new float[] {
               a.value[0] + (b.value[0] - a.value[0]) * f, a.value[1] + (b.value[1] - a.value[1]) * f, a.value[2] + (b.value[2] - a.value[2]) * f
            };
         }
      }

      return k.get(k.size() - 1).value.clone();
   }

   // ------------------------------------------------------------------ easing

   static float ease(String name, float[] args, float f) {
      if (name == null || name.equals("linear")) {
         return f;
      }

      if (name.equals("step")) {
         float n = args.length > 0 ? args[0] : 0.0F;
         return n > 0.0F ? (float)Math.floor(f * n) / n : (f < 0.5F ? 0.0F : 1.0F);
      }

      String kind;
      String family;
      if (name.startsWith("easeInOut")) {
         kind = "inout";
         family = name.substring(9);
      } else if (name.startsWith("easeIn")) {
         kind = "in";
         family = name.substring(6);
      } else if (name.startsWith("easeOut")) {
         kind = "out";
         family = name.substring(7);
      } else {
         return f;
      }

      return switch (kind) {
         case "in" -> easeIn(family, f);
         case "out" -> 1.0F - easeIn(family, 1.0F - f);
         default -> f < 0.5F ? easeIn(family, 2.0F * f) / 2.0F : 1.0F - easeIn(family, 2.0F * (1.0F - f)) / 2.0F;
      };
   }

   private static float easeIn(String family, float f) {
      return switch (family) {
         case "Sine" -> 1.0F - (float)Math.cos(f * Math.PI / 2.0);
         case "Quad" -> f * f;
         case "Cubic" -> f * f * f;
         case "Quart" -> f * f * f * f;
         case "Quint" -> f * f * f * f * f;
         case "Expo" -> f <= 0.0F ? 0.0F : (float)Math.pow(2.0, 10.0 * f - 10.0);
         case "Circ" -> 1.0F - (float)Math.sqrt(Math.max(0.0F, 1.0F - f * f));
         default -> f;
      };
   }
}
