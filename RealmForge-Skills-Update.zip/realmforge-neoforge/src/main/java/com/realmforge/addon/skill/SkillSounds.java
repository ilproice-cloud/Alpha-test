package com.realmforge.addon.skill;

import com.realmforge.RealmForgeMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Sound events backed by the original Prime Punch .ogg files (see assets/realmforge/sounds.json). */
public final class SkillSounds {
   public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, RealmForgeMod.MOD_ID);
   public static final DeferredHolder<SoundEvent, SoundEvent> HEAVY_PUNCH = reg("skill.heavy_punch");
   public static final DeferredHolder<SoundEvent, SoundEvent> UPPERCUT = reg("skill.uppercut");
   public static final DeferredHolder<SoundEvent, SoundEvent> BARRAGE = reg("skill.barrage");

   private SkillSounds() {
   }

   private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
      return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(RealmForgeMod.id(name)));
   }

   public static SoundEvent of(Skill s) {
      return switch (s) {
         case BARRAGE -> BARRAGE.get();
         case HEAVY_PUNCH -> HEAVY_PUNCH.get();
         case UPPERCUT -> UPPERCUT.get();
      };
   }
}
