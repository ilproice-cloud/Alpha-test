package com.realmforge.addon.logic;

import com.realmforge.RpgManager;
import com.realmforge.addon.net.SkillEffectPayload;
import com.realmforge.addon.skill.Skill;
import com.realmforge.addon.skill.SkillParticles;
import com.realmforge.addon.skill.SkillSounds;
import com.realmforge.data.RpgData;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Server side of the skill system: unlocking, Z/X/C assignment, activation checks (unlocked, cooldown, energy,
 * target in range, not already mid-skill) and the actual hits.
 *
 * Every hit is a normal player-attack ({@code playerAttack} damage source), so it goes through DamagePipeline and
 * scales with trait / perk damage-out, STR (incl. rank, clan stat points, Toji set) like any other melee hit.
 */
public final class SkillManager {
   public static final String[] KEY_NAMES = {"Z", "X", "C"};
   /** tick (after activation) on which Heavy Punch / Uppercut land: ~0.15 s, where the arm snaps forward/up in the original animation */
   private static final int STRIKE_TICK = 3;
   /** minimum cosine between the punch direction and the direction to the target (~70 degree half cone) */
   private static final double CONE_DOT = 0.35;
   private static final double HEAVY_PUSH = 1.6;
   private static final double UPPERCUT_LAUNCH = 0.95;

   private static final Map<UUID, Run> RUNNING = new HashMap<>();
   private static final Map<UUID, Map<Skill, Long>> COOLDOWNS = new HashMap<>();
   /** skill currently dealing damage (read by DamagePipeline for the STR factor) */
   private static Skill active;

   private SkillManager() {
   }

   private static final class Run {
      final Skill skill;
      int tick;
      UUID target;
      final double fx;
      final double fz;

      Run(Skill skill, ServerPlayer p, LivingEntity target) {
         this.skill = skill;
         this.target = target == null ? null : target.getUUID();
         double yaw = Math.toRadians(p.getYRot());
         this.fx = -Math.sin(yaw);
         this.fz = Math.cos(yaw);
      }
   }

   // ------------------------------------------------------------------ DamagePipeline hook

   /** The skill whose hit is being applied right now, or null for ordinary damage. */
   public static Skill activeSkill() {
      return active;
   }

   // ------------------------------------------------------------------ unlock / assign

   public static boolean unlock(ServerPlayer p, Skill s) {
      RpgData d = RpgManager.get(p);
      if (!d.skills.add(s.id)) {
         return false;
      }

      d.syncDirty = true;
      RpgManager.sync(p, -1);
      p.displayClientMessage(
         Component.literal("Skill unlocked: ").withStyle(ChatFormatting.GOLD).append(s.title().copy().withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD)), false
      );
      p.displayClientMessage(Component.literal("Open the Skills menu (default J) to assign it to Z, X or C.").withStyle(ChatFormatting.GRAY), false);
      return true;
   }

   public static boolean lock(ServerPlayer p, Skill s) {
      RpgData d = RpgManager.get(p);
      if (!d.skills.remove(s.id)) {
         return false;
      }

      for (int i = 0; i < d.skillKeys.length; i++) {
         if (s.id.equals(d.skillKeys[i])) {
            d.skillKeys[i] = "";
         }
      }

      d.syncDirty = true;
      RpgManager.sync(p, -1);
      return true;
   }

   /** Assign an unlocked skill to slot 0/1/2 (Z/X/C). Empty / unknown id clears the slot. A skill sits on one key only. */
   public static void assign(ServerPlayer p, int slot, String skillId) {
      if (slot < 0 || slot >= KEY_NAMES.length) {
         return;
      }

      RpgData d = RpgManager.get(p);
      Skill s = Skill.byId(skillId);
      if (s == null) {
         d.skillKeys[slot] = "";
      } else {
         if (!d.skills.contains(s.id)) {
            p.displayClientMessage(Component.literal("You haven't unlocked " + s.display + " yet.").withStyle(ChatFormatting.RED), true);
            return;
         }

         for (int i = 0; i < d.skillKeys.length; i++) {
            if (s.id.equals(d.skillKeys[i])) {
               d.skillKeys[i] = "";
            }
         }

         d.skillKeys[slot] = s.id;
         p.displayClientMessage(
            Component.literal(s.display + " assigned to " + KEY_NAMES[slot] + ".").withStyle(ChatFormatting.GREEN), true
         );
      }

      d.syncDirty = true;
      RpgManager.sync(p, -1);
   }

   // ------------------------------------------------------------------ activation

   public static void use(ServerPlayer p, int slot) {
      if (slot < 0 || slot >= KEY_NAMES.length || !p.isAlive() || p.isSpectator() || p.isSleeping() || p.isPassenger()) {
         return;
      }

      RpgData d = RpgManager.get(p);
      Skill s = Skill.byId(d.skillKeys[slot]);
      if (s == null) {
         bar(p, "No skill assigned to " + KEY_NAMES[slot] + ". Open the Skills menu (J).", ChatFormatting.GRAY);
         return;
      }

      if (!d.skills.contains(s.id)) {
         bar(p, "You haven't unlocked " + s.display + ".", ChatFormatting.RED);
         return;
      }

      if (RUNNING.containsKey(p.getUUID())) {
         return;
      }

      long now = p.serverLevel().getGameTime();
      long ready = COOLDOWNS.getOrDefault(p.getUUID(), new EnumMap<>(Skill.class)).getOrDefault(s, 0L);
      if (ready > now) {
         bar(p, s.display + " is on cooldown (" + String.format(Locale.ROOT, "%.1f", (ready - now) / 20.0) + "s).", ChatFormatting.RED);
         return;
      }

      // Range / target requirement (checked before anything is spent)
      LivingEntity target = null;
      if (s.needsTarget) {
         Run probe = new Run(s, p, null);
         List<LivingEntity> found = targets(p, probe, s.range);
         if (found.isEmpty()) {
            bar(p, "No target in range for " + s.display + ".", ChatFormatting.RED);
            return;
         }

         target = found.get(0);
      }

      if (d.initialized()) {
         if (d.energy < s.energy) {
            bar(p, "Not enough energy for " + s.display + " (" + Math.round(d.energy) + "/" + Math.round(s.energy) + ").", ChatFormatting.RED);
            return;
         }

         d.energy -= s.energy;
         d.syncDirty = true;
      }

      COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new EnumMap<>(Skill.class)).put(s, now + s.cooldownTicks);
      RUNNING.put(p.getUUID(), new Run(s, p, target));
      p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SkillSounds.of(s), SoundSource.PLAYERS, 1.0F, 1.0F);
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(p, new SkillEffectPayload(p.getUUID(), s.id, p.getYRot(), p.getXRot()));
   }

   private static void bar(ServerPlayer p, String text, ChatFormatting color) {
      p.displayClientMessage(Component.literal(text).withStyle(color), true);
   }

   // ------------------------------------------------------------------ timeline

   /** Called every server tick. */
   public static void tick(MinecraftServer server) {
      if (RUNNING.isEmpty()) {
         return;
      }

      Iterator<Map.Entry<UUID, Run>> it = RUNNING.entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry<UUID, Run> e = it.next();
         ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
         Run r = e.getValue();
         if (p == null || !p.isAlive()) {
            it.remove();
            continue;
         }

         r.tick++;
         switch (r.skill) {
            case HEAVY_PUNCH -> {
               if (r.tick == STRIKE_TICK) {
                  strike(p, r, false);
               }
            }
            case UPPERCUT -> {
               if (r.tick == STRIKE_TICK) {
                  strike(p, r, true);
               }
            }
            case BARRAGE -> {
               // roughly every 2 ticks: 9 hits over the 1 second animation
               if (r.tick >= 2 && r.tick <= 18 && r.tick % 2 == 0) {
                  barrageHit(p, r);
               }
            }
         }

         if (r.tick >= r.skill.durationTicks) {
            it.remove();
         }
      }
   }

   /** Player left / died: drop any running skill. */
   public static void clear(UUID id) {
      RUNNING.remove(id);
   }

   /** New world / server start: forget everything (cooldowns use world game time). */
   public static void reset() {
      RUNNING.clear();
      COOLDOWNS.clear();
      active = null;
   }

   // ------------------------------------------------------------------ hits

   private static void strike(ServerPlayer p, Run r, boolean upward) {
      ServerLevel level = p.serverLevel();
      for (LivingEntity t : targets(p, r, r.skill.range)) {
         if (!hurt(p, t, r.skill)) {
            continue;
         }

         if (upward) {
            // launch: keep a little of the existing sideways motion, big upward velocity
            push(t, t.getDeltaMovement().x * 0.3 + r.fx * 0.1, UPPERCUT_LAUNCH, t.getDeltaMovement().z * 0.3 + r.fz * 0.1);
            debris(level, t, 10, 0);
         } else {
            push(t, r.fx * HEAVY_PUSH, 0.35, r.fz * HEAVY_PUSH);
            debris(level, t, 12, 3);
         }
      }
   }

   private static void barrageHit(ServerPlayer p, Run r) {
      ServerLevel level = p.serverLevel();
      LivingEntity t = null;
      if (r.target != null && level.getEntity(r.target) instanceof LivingEntity le && valid(p, le) && le.distanceTo(p) <= r.skill.range + 2.0) {
         t = le;
      }

      if (t == null) {
         // target died / escaped: lock onto the next enemy in front, otherwise the barrage just whiffs
         List<LivingEntity> found = targets(p, r, r.skill.range + 1.0);
         t = found.isEmpty() ? null : found.get(0);
         r.target = t == null ? null : t.getUUID();
      }

      if (t == null || !hurt(p, t, r.skill)) {
         return;
      }

      debris(level, t, 2, 0);
      if (r.tick >= 18) {
         push(t, r.fx * 0.9, 0.3, r.fz * 0.9); // final hit shoves them back
      } else {
         // pin the target in front of the fists instead of letting each hit knock it away
         push(t, r.fx * 0.03, Math.max(0.0, t.getDeltaMovement().y), r.fz * 0.03);
      }
   }

   private static boolean hurt(ServerPlayer p, LivingEntity t, Skill s) {
      active = s;
      try {
         t.invulnerableTime = 0; // skills ignore the post-hit invulnerability window (multi-hit / right after a normal hit)
         return t.hurt(p.damageSources().playerAttack(p), s.damage);
      } finally {
         active = null;
      }
   }

   private static void push(LivingEntity t, double x, double y, double z) {
      double res = 1.0 - Math.min(1.0, Math.max(0.0, t.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE)));
      t.setDeltaMovement(x * res, y * res, z * res);
      t.hurtMarked = true;
   }

   private static void debris(ServerLevel level, LivingEntity t, int small, int big) {
      double x = t.getX();
      double y = t.getY() + t.getBbHeight() * 0.5;
      double z = t.getZ();
      level.sendParticles(SkillParticles.ROCK.get(), x, y, z, small, 0.3, 0.3, 0.3, 0.12);
      if (big > 0) {
         level.sendParticles(SkillParticles.BIG_ROCK.get(), x, y, z, big, 0.3, 0.3, 0.3, 0.1);
      }
   }

   // ------------------------------------------------------------------ targeting

   private static boolean valid(ServerPlayer p, LivingEntity t) {
      if (t == p || !t.isAlive() || t.isSpectator() || t instanceof ArmorStand || t.isAlliedTo(p) || !p.canAttack(t)) {
         return false;
      }

      if (t instanceof TamableAnimal pet && pet.isOwnedBy(p)) {
         return false;
      }

      return p.hasLineOfSight(t);
   }

   /** Valid living entities in front of the player within {@code range} blocks, nearest first. */
   private static List<LivingEntity> targets(ServerPlayer p, Run r, double range) {
      ServerLevel level = p.serverLevel();
      double fx = r.fx;
      double fz = r.fz;
      if (fx == 0.0 && fz == 0.0) {
         double yaw = Math.toRadians(p.getYRot());
         fx = -Math.sin(yaw);
         fz = Math.cos(yaw);
      }

      List<LivingEntity> out = new ArrayList<>();
      for (LivingEntity t : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range + 1.0, 1.5, range + 1.0), x -> valid(p, x))) {
         double dx = t.getX() - p.getX();
         double dz = t.getZ() - p.getZ();
         double flat = Math.sqrt(dx * dx + dz * dz);
         if (flat - t.getBbWidth() * 0.5 > range) {
            continue;
         }

         if (flat > 0.6 && (dx * fx + dz * fz) / flat < CONE_DOT) {
            continue;
         }

         out.add(t);
      }

      out.sort(Comparator.comparingDouble(t -> t.distanceToSqr(p)));
      return out;
   }
}
