package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> clients: this player started a skill (play the player animation + VFX). yaw/pitch = view angles at the start. */
public record SkillEffectPayload(UUID player, String skill, float yaw, float pitch) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<SkillEffectPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("skill_effect"));
   public static final StreamCodec<ByteBuf, SkillEffectPayload> CODEC = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC,
      SkillEffectPayload::player,
      ByteBufCodecs.STRING_UTF8,
      SkillEffectPayload::skill,
      ByteBufCodecs.FLOAT,
      SkillEffectPayload::yaw,
      ByteBufCodecs.FLOAT,
      SkillEffectPayload::pitch,
      SkillEffectPayload::new
   );

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
