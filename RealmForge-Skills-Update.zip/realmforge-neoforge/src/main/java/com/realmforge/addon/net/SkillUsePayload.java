package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: key slot 0/1/2 (Z/X/C) was pressed. */
public record SkillUsePayload(int slot) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<SkillUsePayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("skill_use"));
   public static final StreamCodec<ByteBuf, SkillUsePayload> CODEC = StreamCodec.composite(ByteBufCodecs.VAR_INT, SkillUsePayload::slot, SkillUsePayload::new);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
