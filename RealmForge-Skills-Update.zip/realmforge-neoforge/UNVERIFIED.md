# Build and test status

The source archive has been cleaned of the skill subsystem and its leftover assets/documentation. The retained RPG progression, stats, traits, perks, ranks, clan data, equipment bonuses, Sorcerer Killer armor, RPG book/HUD, and blocking system are intended to remain.

**This archive has not been compiled or launched in Minecraft in this environment.** Treat it as an edited source ZIP, not a tested JAR. Run the included GitHub Actions build and test the resulting JAR in Minecraft 1.21.1 with the matching NeoForge version.

## Skills system (Barrage / Heavy Punch / Uppercut) - not compiled or run in-game when written
Checked offline only: all JSON valid, brace/import cross-references, and a Python port of the animation sampler + bone transforms run on the real files (effects point forward / up, fists travel forward / up). NOT checked: Java compile against NeoForge 1.21.1, rendering (RenderLevelStageEvent stage, emissive render type), player-pose sign conventions (`POS_SIGN` / `ROT_SIGN` in SkillPlayerAnim), hit feel and balance. Test in game: unlock with `/realmforge admin skill unlockall @s`, open the menu with J, assign, press Z / X / C.
