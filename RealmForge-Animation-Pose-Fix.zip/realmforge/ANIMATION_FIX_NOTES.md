# Uppercut animation stability patch — notes

This patch changes `AnimClient.apply` so Blockbench player animation tracks are applied as offsets to the vanilla HumanoidModel pose instead of replacing limb rotations. This preserves the base leg/arm pose (including normal locomotion pose) while the skill animation is layered on top. Position tracks are also applied as offsets, and `body`/`torso` aliases are guarded so a model part cannot receive both tracks twice.

The active animation is removed at its end time. The model is then free to return to its next vanilla pose.

## Important source limitation

The archived source ZIP used for this patch contains five Electro skills and a legacy mapping where `uppercut` maps to `electro_dropkick`. It does **not** contain a standalone Uppercut skill implementation or an Uppercut animation clip. Therefore this patch deliberately does not delete or rewrite the skill registry: doing so against this archive could remove the only current mapping for the requested move. A later Uppercut-enabled source archive is needed to safely remove the unwanted Electro skills while preserving the actual Uppercut implementation.

Compilation and in-game animation testing have not been performed in this environment.
