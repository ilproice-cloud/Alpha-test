package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: this player started the uppercut animation. */
public record UppercutAnimPayload(UUID player) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<UppercutAnimPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("uppercut_anim"));
   public static final StreamCodec<ByteBuf, UppercutAnimPayload> CODEC = UUIDUtil.STREAM_CODEC.map(UppercutAnimPayload::new, UppercutAnimPayload::player);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
