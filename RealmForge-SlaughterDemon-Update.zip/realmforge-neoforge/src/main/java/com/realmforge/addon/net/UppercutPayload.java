package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: the Uppercut key (Z) was pressed. */
public record UppercutPayload() implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<UppercutPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("uppercut"));
   public static final StreamCodec<RegistryFriendlyByteBuf, UppercutPayload> CODEC = StreamCodec.unit(new UppercutPayload());

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
