package com.realmforge.addon.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.InputConstants;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.net.UppercutPayload;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.Util;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Plays assets/realmforge/animations/uppercut.json (Blockbench / Bedrock animation format) on the
 * player model, and owns the Z key.
 */
public final class UppercutClient {
   /** Press Z (default) to uppercut. */
   public static final KeyMapping KEY = new KeyMapping("key.realmforge.uppercut", InputConstants.Type.KEYSYM, 90, "key.categories.realmforge");

   /*
    * Bedrock/Blockbench -> Java model space: Y is up in Bedrock and down in Java, and the model front is +Z in Bedrock
    * and -Z in Java. That flips Y and Z for positions, and Y and Z for rotations. If the animation ever looks
    * mirrored in game, flip the matching sign here.
    */
   private static final float[] POS_SIGN = {1.0F, -1.0F, -1.0F};
   private static final float[] ROT_SIGN = {1.0F, -1.0F, -1.0F};

   private static final Map<UUID, Long> PLAYING = new ConcurrentHashMap<>();
   private static Anim anim;
   private static boolean loaded;

   private UppercutClient() {
   }

   // ------------------------------------------------------------------ input / state

   public static void tick(Minecraft mc) {
      while (KEY.consumeClick()) {
         if (mc.player != null && mc.screen == null) {
            PacketDistributor.sendToServer(new UppercutPayload());
         }
      }
   }

   public static void start(UUID id) {
      load();
      if (anim != null) {
         PLAYING.put(id, Util.getMillis());
      }
   }

   public static void clear() {
      PLAYING.clear();
   }

   public static boolean isPlaying(UUID id) {
      Long start = PLAYING.get(id);
      if (start == null) {
         return false;
      }

      if (anim == null || (Util.getMillis() - start) / 1000.0F > anim.length) {
         PLAYING.remove(id);
         return false;
      }

      return true;
   }

   // ------------------------------------------------------------------ pose

   /** Called from the HumanoidModel mixin after vanilla posed the model. */
   public static void apply(HumanoidModel<?> m, UUID id) {
      Long start = PLAYING.get(id);
      if (start == null || anim == null) {
         return;
      }

      float t = (Util.getMillis() - start) / 1000.0F;

      // vanilla pose (positions double as the default pivots)
      float[] bodyPos = {m.body.x, m.body.y, m.body.z};
      float[] bodyRotV = {m.body.xRot, m.body.yRot, m.body.zRot};

      float[] bOff = pos(anim.sample("body", "position", t), new float[3]);
      float[] bRot = rot(anim.sample("body", "rotation", t), bodyRotV);
      double[][] rb = matrix(bRot);

      m.body.x = bodyPos[0] + bOff[0];
      m.body.y = bodyPos[1] + bOff[1];
      m.body.z = bodyPos[2] + bOff[2];
      m.body.xRot = bRot[0];
      m.body.yRot = bRot[1];
      m.body.zRot = bRot[2];

      // head and arms are children of the body in the animation (they follow its twist/lean)
      child(m.head, "head", t, bodyPos, bOff, rb);
      child(m.rightArm, "right_arm", t, bodyPos, bOff, rb);
      child(m.leftArm, "left_arm", t, bodyPos, bOff, rb);

      // legs are independent
      leg(m.rightLeg, "right_leg", t);
      leg(m.leftLeg, "left_leg", t);
      m.hat.copyFrom(m.head);
   }

   private static void child(ModelPart part, String bone, float t, float[] bodyPos, float[] bOff, double[][] rb) {
      float[] rel = {part.x - bodyPos[0], part.y - bodyPos[1], part.z - bodyPos[2]};
      float[] own = pos(anim.sample(bone, "position", t), new float[3]);
      float[] cr = rot(anim.sample(bone, "rotation", t), new float[] {part.xRot, part.yRot, part.zRot});

      double[] p = mul(rb, new double[] {rel[0] + own[0], rel[1] + own[1], rel[2] + own[2]});
      part.x = bodyPos[0] + bOff[0] + (float)p[0];
      part.y = bodyPos[1] + bOff[1] + (float)p[1];
      part.z = bodyPos[2] + bOff[2] + (float)p[2];

      double[] e = euler(mul(rb, matrix(cr)));
      part.xRot = (float)e[0];
      part.yRot = (float)e[1];
      part.zRot = (float)e[2];
   }

   private static void leg(ModelPart part, String bone, float t) {
      float[] off = pos(anim.sample(bone, "position", t), new float[3]);
      float[] r = rot(anim.sample(bone, "rotation", t), new float[] {part.xRot, part.yRot, part.zRot});
      part.x += off[0];
      part.y += off[1];
      part.z += off[2];
      part.xRot = r[0];
      part.yRot = r[1];
      part.zRot = r[2];
   }

   /** Animation position (pixels, Bedrock axes) -> Java offset. {@code null} (no channel) -> {@code fallback}. */
   private static float[] pos(float[] v, float[] fallback) {
      return v == null ? fallback : new float[] {v[0] * POS_SIGN[0], v[1] * POS_SIGN[1], v[2] * POS_SIGN[2]};
   }

   /** Animation rotation (degrees, Bedrock) -> Java radians. {@code null} (no channel) -> {@code fallback} (vanilla radians). */
   private static float[] rot(float[] v, float[] fallback) {
      if (v == null) {
         return fallback;
      }

      return new float[] {
         (float)Math.toRadians(v[0] * ROT_SIGN[0]), (float)Math.toRadians(v[1] * ROT_SIGN[1]), (float)Math.toRadians(v[2] * ROT_SIGN[2])
      };
   }

   // ------------------------------------------------------------------ small rotation math (ZYX, same order as ModelPart)

   private static double[][] matrix(float[] r) {
      double cx = Math.cos(r[0]), sx = Math.sin(r[0]);
      double cy = Math.cos(r[1]), sy = Math.sin(r[1]);
      double cz = Math.cos(r[2]), sz = Math.sin(r[2]);
      double[][] rx = {{1, 0, 0}, {0, cx, -sx}, {0, sx, cx}};
      double[][] ry = {{cy, 0, sy}, {0, 1, 0}, {-sy, 0, cy}};
      double[][] rz = {{cz, -sz, 0}, {sz, cz, 0}, {0, 0, 1}};
      return mul(rz, mul(ry, rx));
   }

   private static double[][] mul(double[][] a, double[][] b) {
      double[][] o = new double[3][3];
      for (int i = 0; i < 3; i++) {
         for (int j = 0; j < 3; j++) {
            o[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j];
         }
      }

      return o;
   }

   private static double[] mul(double[][] a, double[] v) {
      return new double[] {
         a[0][0] * v[0] + a[0][1] * v[1] + a[0][2] * v[2],
         a[1][0] * v[0] + a[1][1] * v[1] + a[1][2] * v[2],
         a[2][0] * v[0] + a[2][1] * v[1] + a[2][2] * v[2]
      };
   }

   /** Rotation matrix -> {xRot, yRot, zRot} for R = Rz * Ry * Rx. */
   private static double[] euler(double[][] r) {
      double y = Math.asin(Math.max(-1.0, Math.min(1.0, -r[2][0])));
      if (Math.abs(r[2][0]) < 0.99999) {
         return new double[] {Math.atan2(r[2][1], r[2][2]), y, Math.atan2(r[1][0], r[0][0])};
      }

      return new double[] {Math.atan2(-r[1][2], r[1][1]), y, 0.0};
   }

   // ------------------------------------------------------------------ animation file

   private static void load() {
      if (loaded) {
         return;
      }

      loaded = true;
      String path = "/assets/" + RealmForgeMod.MOD_ID + "/animations/uppercut.json";
      try (InputStream in = UppercutClient.class.getResourceAsStream(path)) {
         if (in == null) {
            RealmForgeMod.LOGGER.error("Uppercut animation not found: {}", path);
            return;
         }

         JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         JsonObject all = root.getAsJsonObject("animations");
         JsonObject a = all.has("uppercut") ? all.getAsJsonObject("uppercut") : all.getAsJsonObject(all.keySet().iterator().next());
         anim = Anim.parse(a);
      } catch (Exception e) {
         RealmForgeMod.LOGGER.error("Failed to load uppercut animation", e);
      }
   }

   private static final class Anim {
      float length;
      /** key = bone + "/" + channel */
      final Map<String, List<float[]>> tracks = new HashMap<>();

      static Anim parse(JsonObject a) {
         Anim r = new Anim();
         r.length = a.has("animation_length") ? a.get("animation_length").getAsFloat() : 0.5F;
         JsonObject bones = a.getAsJsonObject("bones");
         for (String bone : bones.keySet()) {
            JsonObject b = bones.getAsJsonObject(bone);
            for (String channel : new String[] {"rotation", "position"}) {
               if (!b.has(channel) || !b.get(channel).isJsonObject()) {
                  continue;
               }

               List<float[]> keys = new ArrayList<>();
               JsonObject ch = b.getAsJsonObject(channel);
               for (String time : ch.keySet()) {
                  JsonElement el = ch.get(time);
                  JsonElement vec = el.isJsonObject() ? (el.getAsJsonObject().has("vector") ? el.getAsJsonObject().get("vector") : el.getAsJsonObject().get("post")) : el;
                  if (vec == null || !vec.isJsonArray() || vec.getAsJsonArray().size() < 3) {
                     continue;
                  }

                  keys.add(new float[] {Float.parseFloat(time), num(vec, 0), num(vec, 1), num(vec, 2)});
               }

               keys.sort((x, y) -> Float.compare(x[0], y[0]));
               if (!keys.isEmpty()) {
                  r.tracks.put(bone + "/" + channel, keys);
               }
            }
         }

         return r;
      }

      private static float num(JsonElement vec, int i) {
         JsonElement e = vec.getAsJsonArray().get(i);
         try {
            return e.getAsFloat();
         } catch (Exception ex) {
            return 0.0F;
         }
      }

      /** Linear interpolation; holds the first/last keyframe outside the range. Null if the bone has no such channel. */
      float[] sample(String bone, String channel, float t) {
         List<float[]> k = this.tracks.get(bone + "/" + channel);
         if (k == null) {
            return null;
         }

         if (t <= k.get(0)[0]) {
            return new float[] {k.get(0)[1], k.get(0)[2], k.get(0)[3]};
         }

         for (int i = 1; i < k.size(); i++) {
            float[] b = k.get(i);
            if (t <= b[0]) {
               float[] a = k.get(i - 1);
               float f = (t - a[0]) / Math.max(1.0E-5F, b[0] - a[0]);
               return new float[] {a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f, a[3] + (b[3] - a[3]) * f};
            }
         }

         float[] last = k.get(k.size() - 1);
         return new float[] {last[1], last[2], last[3]};
      }
   }
}
