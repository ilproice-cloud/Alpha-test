package com.realmforge.addon.logic;

import com.realmforge.RpgManager;
import com.realmforge.addon.item.WeaponItems;
import com.realmforge.addon.net.UppercutAnimPayload;
import com.realmforge.data.RpgData;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Server side of the Uppercut (Z). The hit is a normal player-attack hit, so it goes through
 * {@code DamagePipeline} and scales with STR, trait, perk, rank (via stats), the Toji set, etc.
 */
public final class UppercutManager {
   /** Set to false to allow Z with any item in hand. */
   public static final boolean REQUIRE_WEAPON = true;
   public static final float ENERGY_COST = 1.0F;
   public static final int COOLDOWN_TICKS = 30;
   /** Tick (after the key press) at which the hit lands; the arm swing peaks around tick 3-5. */
   public static final int HIT_DELAY_TICKS = 4;
   public static final double RANGE = 3.5;
   /** Weapon attack damage multiplier for the uppercut hit. */
   public static final float DAMAGE_MULT = 1.5F;
   public static final double LAUNCH_Y = 0.85;

   private static final Map<UUID, Integer> PENDING = new HashMap<>();
   private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

   private UppercutManager() {
   }

   public static void tryStart(ServerPlayer p) {
      if (!p.isAlive() || p.isSpectator() || PENDING.containsKey(p.getUUID())) {
         return;
      }

      if (REQUIRE_WEAPON && !p.getMainHandItem().is(WeaponItems.SLAUGHTER_DEMON.get())) {
         p.displayClientMessage(Component.literal("Hold the Slaughter Demon to use Uppercut.").withStyle(ChatFormatting.RED), true);
         return;
      }

      long now = p.serverLevel().getGameTime();
      if (COOLDOWN.getOrDefault(p.getUUID(), 0L) > now) {
         return;
      }

      RpgData d = RpgManager.get(p);
      if (d.initialized()) {
         if (d.energy < ENERGY_COST) {
            p.displayClientMessage(Component.literal("Not enough energy!").withStyle(ChatFormatting.RED), true);
            return;
         }

         d.energy -= ENERGY_COST;
         d.syncDirty = true;
      }

      COOLDOWN.put(p.getUUID(), now + COOLDOWN_TICKS);
      PENDING.put(p.getUUID(), HIT_DELAY_TICKS);
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(p, new UppercutAnimPayload(p.getUUID()));
   }

   /** Called every server tick. */
   public static void tick(MinecraftServer server) {
      if (PENDING.isEmpty()) {
         return;
      }

      Iterator<Map.Entry<UUID, Integer>> it = PENDING.entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry<UUID, Integer> e = it.next();
         ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
         if (p == null || !p.isAlive()) {
            it.remove();
            continue;
         }

         int left = e.getValue() - 1;
         if (left > 0) {
            e.setValue(left);
         } else {
            it.remove();
            hit(p);
         }
      }
   }

   public static void clear(UUID id) {
      PENDING.remove(id);
      COOLDOWN.remove(id);
   }

   private static void hit(ServerPlayer p) {
      ServerLevel level = p.serverLevel();
      Vec3 look = p.getLookAngle();
      Vec3 flat = new Vec3(look.x, 0.0, look.z);
      flat = flat.lengthSqr() < 1.0E-4 ? Vec3.ZERO : flat.normalize();
      Vec3 origin = p.position();
      List<LivingEntity> targets = level.getEntitiesOfClass(
         LivingEntity.class, p.getBoundingBox().inflate(RANGE, 1.5, RANGE), t -> t != p && t.isAlive() && !t.isAlliedTo(p) && p.canAttack(t)
      );

      // Same base as a normal swing (weapon attribute, includes the main-hand modifier) x multiplier.
      float base = (float)p.getAttributeValue(Attributes.ATTACK_DAMAGE) * DAMAGE_MULT;
      int hits = 0;
      for (LivingEntity t : targets) {
         Vec3 to = t.position().subtract(origin);
         Vec3 toFlat = new Vec3(to.x, 0.0, to.z);
         double dist = toFlat.length();
         if (dist > RANGE) {
            continue;
         }

         // roughly in front of the player (~120 degree cone); very close targets always count
         if (dist > 0.8 && flat != Vec3.ZERO && toFlat.normalize().dot(flat) < 0.5) {
            continue;
         }

         // playerAttack => direct entity is the player => DamagePipeline scales it (STR, trait, perk, rank, toji...)
         if (t.hurt(p.damageSources().playerAttack(p), base)) {
            hits++;
            Vec3 m = t.getDeltaMovement();
            t.setDeltaMovement(m.x * 0.4 + flat.x * 0.15, LAUNCH_Y, m.z * 0.4 + flat.z * 0.15);
            t.hurtMarked = true;
            t.fallDistance = 0.0F;
         }
      }

      Vec3 fx = origin.add(flat.scale(1.2)).add(0.0, 1.0, 0.0);
      level.sendParticles(ParticleTypes.SWEEP_ATTACK, fx.x, fx.y, fx.z, 1, 0.0, 0.0, 0.0, 0.0);
      level.playSound(null, p.blockPosition(), hits > 0 ? SoundEvents.PLAYER_ATTACK_STRONG : SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 0.9F);
   }
}
