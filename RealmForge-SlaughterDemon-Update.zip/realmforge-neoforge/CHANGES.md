# RealmForge – skills subsystem removal

Removed all skill-related content from this source project:
- Skill implementations, registries, executors, schedulers, and skill context classes
- Skill book screen, skill HUD/keybinds, skill commands, and skill slot/save/sync handling
- Skill-specific network payloads, projectiles, entities, renderers, and animation hooks
- Uppercut and Electro skill icons and imported combat visuals
- Old combat-skill sounds, Photon effects, Prime Piece animation/effect assets, and related dependencies
- Unused skill-only damage bypass flag and skill-specific stat constant

Retained the RPG progression/stat systems, traits, perks, ranks, clans, equipment bonuses, Sorcerer Killer armor, RPG book/HUD, and blocking pose/system.


## Segmented HUD update (2026-11-09)
- Replaced the old solid HP, energy, and EXP bars with individually rendered image segments.
- Added the supplied 11-piece HP, 7-piece energy, 6-piece hunger, and 5-piece EXP textures.
- Each segment fills progressively from left to right; partial progress is clipped by darkening only the unfilled portion.
- Hunger reads Minecraft's player food level.
- The supplied full GUI and full-health-bar references are included under the GUI reference texture folder.

## New HUD panel + rank system update (2026-11-10)
- Replaced `main_hud_background.png` with the new 790x316 parchment panel (transparent background, faint edge pixels cleaned). HUD layout re-measured for it: face, HP (11), energy (7), EXP (5) and hunger (6) tracks. Empty segments now show the panel's own empty slots.
- EXP readout is `current / max` with compact numbers: under 10,000 shown in full, then truncated to one decimal (12450 -> 12.4k, 10000 -> 10k, also m/b for millions/billions). Shows MAX at level 100.
- Rank system: every rank-up (Novice = 0 ... Legend = 7) gives +10% EXP gained, +10% to all stats (applied to the final stat total, rounded) and -7.5% dodge chance (final dodge x (1 - 0.075 x ranks), never below 0). Values are constants at the top of `Rank.java`.
- Rank-ups now re-apply max HP / speed immediately and print the new bonus in chat.
- Book: new `[ RANK UP ]` text button on the Information page opens 6 pages (overview + progress, bonuses per rank, buffs, debuffs, rank requirements, more info). `RankPage.java`.
- Book buttons (Traits / Perks / Clan / Rank Up) now find their row from the real wrapped text instead of fixed line numbers.
- Fixed `Formatting` (Yarn name) -> `ChatFormatting` in `RpgBook`, `BookPages`, `EffectsPage` (would not compile with Mojang mappings).

## Slaughter Demon weapon + Uppercut (Z) (2026-11-10)
- New item `realmforge:slaughter_demon` (Combat tab): netherite-tier sword, 9 attack damage, 3D in-hand model with a flat 16x16 inventory icon (`neoforge:separate_transforms`).
- Damage scaling: it is a normal melee weapon, so hits go through `DamagePipeline` (trait/perk damage dealt, flat STR damage, rank via the +10%/rank stat bonus, Toji set). While held it also gives +5 STR (`EquipmentBonuses`) and the flat STR damage is x1.5 (`WeaponItems.STR_SCALING`). Clan affects damage through its stat-point multiplier (more points into STR); there is no direct clan damage multiplier.
- Press **Z** (rebindable, "Uppercut") while holding the weapon: client sends `UppercutPayload`, server checks cooldown (1.5 s) and energy (1.0), tells nearby players to play the animation, and 4 ticks later hits every living entity in front (3.5 blocks) for 1.5x the weapon's attack damage as a player attack (full RPG scaling) and launches them upward. Tunables are constants at the top of `UppercutManager`.
- Animation: `assets/realmforge/animations/uppercut.json` (Blockbench/Bedrock format) is played on the third-person player model by `UppercutClient` through `HumanoidModelMixin`; other players see it too. Head and arms follow the body twist. Axis signs for the Bedrock->Java conversion are `POS_SIGN` / `ROT_SIGN` in `UppercutClient`.
