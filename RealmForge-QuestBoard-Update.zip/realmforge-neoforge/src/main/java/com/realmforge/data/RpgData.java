package com.realmforge.data;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.ToDoubleFunction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;

/**
 * Per-player RPG data. This class already contains the changes the Fabric
 * fused addon data (clan, Toji set flag and rebalanced RPG formulas).
 */
public final class RpgData {
   public static final int MAX_LEVEL = 100;
   public static final int POINTS_PER_LEVEL = 3;
   public static final int STARTING_POINTS = 5;
   public static final int BASE_ENERGY = 5;
   public static final int HP_PER_VIT = 4;
   public static final int ENERGY_PER_ENE = 5;
   public static final double EXP_GROWTH = 1.2;
   public static final double BASE_EXP = 100.0;
   public static final double STR_PHYS = 0.02;
   public static final double AGI_SPEED = 0.01;
   public static final double AGI_DODGE = 0.005;
   public static final double ENE_REGEN = 0.1;
   public int level = 1;
   public long exp = 0L;
   public int points = 5;
   public final int[] base = new int[Stat.values().length];
   public float energy = 5.0F;
   public String traitId = "";
   public String perkId = "";
   public int rankIdx = 0;
   public int kills = 0;
   public int[] equip = new int[Stat.values().length];
   public boolean syncDirty;

   // ---- skill system ----
   /** ids of the skills this player has unlocked */
   public final Set<String> skills = new LinkedHashSet<>();
   /** skill id assigned to Z, X, C ("" = empty) */
   public final String[] skillKeys = {"", "", ""};

   // ---- quest board ----
   /** which 2-minute window (worldTime / 2400) the progress below belongs to; -1 = never */
   public long questEpoch = -1L;
   public int questProgress;
   public boolean questClaimed;

   // ---- addon fields (were mixin-injected) ----
   private String clan;
   private boolean toji;
   private int rolledLevel = -1;

   public String clan() {
      return this.clan;
   }

   public void setClan(String id) {
      if (this.clan == null || this.clan.isEmpty()) {
         this.clan = id;
      }
   }

   public boolean toji() {
      return this.toji;
   }

   public void setToji(boolean on) {
      this.toji = on;
   }

   public int rolledLevel() {
      return this.rolledLevel;
   }

   public void setRolledLevel(int l) {
      this.rolledLevel = l;
   }





   private com.realmforge.addon.data.Clan clanType() {
      return com.realmforge.addon.data.Clan.byId(this.clan);
   }

   public Trait trait() {
      return Trait.byId(this.traitId);
   }

   public Perk perk() {
      return Perk.byId(this.perkId);
   }

   public boolean initialized() {
      return this.trait() != null && this.perk() != null;
   }

   public Rank rank() {
      return Rank.values()[Math.min(this.rankIdx, Rank.values().length - 1)];
   }

   public int stat(Stat s) {
      int i = s.ordinal();
      int v = this.base[i] + (i < this.equip.length ? this.equip[i] : 0);
      Trait t = this.trait();
      if (t != null) {
         v += t.effects().stats[i];
      }

      Perk p = this.perk();
      if (p != null) {
         v += p.effects().stats[i];
      }

      v = Math.max(0, v);
      // Rank bonus: every stat is increased by 10% per rank-up (applied to the final total).
      return (int)Math.round((double)v * (1.0 + this.rank().statBonus()));
   }

   public int bonusOf(Stat s) {
      return this.stat(s) - this.base[s.ordinal()];
   }

   private double fx(ToDoubleFunction<Effects> f) {
      double v = 0.0;
      Trait t = this.trait();
      if (t != null) {
         v += f.applyAsDouble(t.effects());
      }

      Perk p = this.perk();
      if (p != null) {
         v += f.applyAsDouble(p.effects());
      }

      return v;
   }

   /** Fused addon: STR no longer gives a % multiplier (it gives flat damage instead, see DamagePipeline). */
   public double physMult() {
      return 1.0;
   }

   public double intMagicMult() {
      return 1.0 + 0.03 * (double)this.stat(Stat.INT);
   }

   public double speedBonus() {
      return Math.min(1.0, 0.01 * (double)this.stat(Stat.AGI));
   }

   public double dodge() {
      double d = Math.max(0.0, 0.005 * (double)this.stat(Stat.AGI) + this.fx(e -> e.dodge));
      double chance = this.toji ? Math.min(1.0, d + 0.2) : Math.min(0.4, d);
      // Rank penalty: dodge chance is reduced by 7.5% per rank-up (multiplicative on the final chance).
      return Math.max(0.0, chance * (1.0 - this.rank().dodgePenalty()));
   }

   public int maxHealthBonus() {
      return this.stat(Stat.VIT) * 2 + (int)this.fx(e -> (double)e.hp);
   }

   public double dmgOut() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.dmgOut));
   }

   public double dmgIn() {
      return Math.max(0.1, 1.0 + this.fx(e -> e.dmgIn));
   }

   public double expMult() {
      // Rank bonus: +10% EXP per rank-up, stacked additively with the trait/perk EXP modifiers.
      double m = Math.max(0.0, 1.0 + this.fx(e -> e.exp) + this.rank().expBonus());
      com.realmforge.addon.data.Clan c = this.clanType();
      return c != null ? m * c.expMult : m;
   }

   public double lifesteal() {
      return Math.max(0.0, this.fx(e -> e.lifesteal));
   }



   public float maxEnergy() {
      double m = Math.max(0.1, 1.0 + this.fx(e -> e.energy));
      return (float)Math.max(1.0, (double)(5 + 2 * this.stat(Stat.ENE)) * m);
   }

   public double regenPerSecond() {
      double m = Math.max(0.0, 1.0 + this.fx(e -> e.regen));
      return (1.0 + 0.25 * (double)this.stat(Stat.ENE)) * m;
   }

   public static long expRequired(int level) {
      return Math.round(100.0 * Math.pow(1.2, (double)(level - 1)));
   }

   public long expRequired() {
      return expRequired(this.level);
   }

   /** Fused addon version: clan stat-point multiplier, and +1 to every base stat per level. */
   public int addExp(long amount) {
      if (amount > 0L && this.level < 100) {
         this.exp += amount;
         int gained = 0;
         com.realmforge.addon.data.Clan c = this.clanType();
         int perLevel = (int)Math.round(3.0 * (c == null ? 1.0 : c.statPointMult));

         while (this.level < 100 && this.exp >= expRequired(this.level)) {
            this.exp = this.exp - expRequired(this.level);
            this.level++;
            this.points += perLevel;

            for (int i = 0; i < this.base.length; i++) {
               this.base[i]++;
            }

            gained++;
         }

         if (this.level >= 100) {
            this.exp = 0L;
         }

         this.syncDirty = true;
         return gained;
      } else {
         return 0;
      }
   }

   public boolean spend(Stat s, int n) {
      if (n >= 1 && n <= this.points) {
         this.base[s.ordinal()] += n;
         this.points -= n;
         this.syncDirty = true;
         return true;
      } else {
         return false;
      }
   }







   public CompoundTag write() {
      CompoundTag n = new CompoundTag();
      n.putInt("level", this.level);
      n.putLong("exp", this.exp);
      n.putInt("points", this.points);
      n.putIntArray("base", this.base);
      n.putFloat("energy", this.energy);
      n.putString("trait", this.traitId);
      n.putString("perk", this.perkId);
      n.putInt("rank", this.rankIdx);
      n.putInt("kills", this.kills);
      n.putString("rf_clan", this.clan == null ? "" : this.clan);

      ListTag sl = new ListTag();
      for (String s : this.skills) {
         sl.add(StringTag.valueOf(s));
      }

      n.put("rf_skills", sl);
      ListTag kl = new ListTag();
      for (String k : this.skillKeys) {
         kl.add(StringTag.valueOf(k));
      }

      n.put("rf_skill_keys", kl);
      n.putLong("rf_q_epoch", this.questEpoch);
      n.putInt("rf_q_prog", this.questProgress);
      n.putBoolean("rf_q_claimed", this.questClaimed);
      return n;
   }

   public static RpgData read(CompoundTag n) {
      RpgData d = new RpgData();
      if (n.contains("level")) {
         d.level = Math.max(1, Math.min(100, n.getInt("level")));
      }

      d.exp = Math.max(0L, n.getLong("exp"));
      if (n.contains("points")) {
         d.points = Math.max(0, n.getInt("points"));
      }

      copy(n.getIntArray("base"), d.base);
      if (n.contains("energy")) {
         d.energy = n.getFloat("energy");
      }

      d.traitId = n.getString("trait");
      d.perkId = n.getString("perk");
      d.rankIdx = Math.max(0, Math.min(Rank.values().length - 1, n.getInt("rank")));
      d.kills = Math.max(0, n.getInt("kills"));
      String c = n.getString("rf_clan");
      if (!c.isEmpty()) {
         d.setClan(c);
      }

      ListTag sl = n.getList("rf_skills", 8);
      for (int i = 0; i < sl.size(); i++) {
         d.skills.add(sl.getString(i));
      }

      ListTag kl = n.getList("rf_skill_keys", 8);
      for (int i = 0; i < Math.min(kl.size(), d.skillKeys.length); i++) {
         d.skillKeys[i] = kl.getString(i);
      }

      d.questEpoch = n.contains("rf_q_epoch") ? n.getLong("rf_q_epoch") : -1L;
      d.questProgress = n.getInt("rf_q_prog");
      d.questClaimed = n.getBoolean("rf_q_claimed");
      return d;
   }

   public CompoundTag toSync(long worldTime) {
      CompoundTag n = this.write();
      n.putIntArray("equip", this.equip);
      return n;
   }

   public static RpgData fromSync(CompoundTag n) {
      RpgData d = read(n);
      copy(n.getIntArray("equip"), d.equip);


      return d;
   }

   private static void copy(int[] src, int[] dst) {
      System.arraycopy(src, 0, dst, 0, Math.min(src.length, dst.length));
   }
}
