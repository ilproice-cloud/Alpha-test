package com.realmforge.addon.quest;

import com.realmforge.RealmForgeMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class QuestBlocks {
   public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RealmForgeMod.MOD_ID);
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RealmForgeMod.MOD_ID);
   public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, RealmForgeMod.MOD_ID);

   public static final DeferredBlock<QuestBoardBlock> QUEST_BOARD = BLOCKS.register(
      "quest_board",
      () -> new QuestBoardBlock(
         BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).instrument(NoteBlockInstrument.BASS).sound(SoundType.WOOD).strength(1.0F, 10.0F).noOcclusion()
      )
   );
   public static final DeferredItem<BlockItem> QUEST_BOARD_ITEM = ITEMS.registerSimpleBlockItem("quest_board", QUEST_BOARD);
   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<QuestBoardBlockEntity>> QUEST_BOARD_BE = BLOCK_ENTITIES.register(
      "quest_board", () -> BlockEntityType.Builder.of(QuestBoardBlockEntity::new, QUEST_BOARD.get()).build(null)
   );

   private QuestBlocks() {
   }
}
