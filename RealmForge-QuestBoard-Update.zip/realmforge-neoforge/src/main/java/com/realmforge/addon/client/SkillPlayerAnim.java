package com.realmforge.addon.client;

import com.realmforge.addon.skill.Skill;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.Util;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;

/**
 * Plays the original Prime Punch player animations (assets/realmforge/skills/player/*.json) on the player model.
 * Called from HumanoidModelMixin after vanilla (and blocking) posing, so it overrides them while it plays.
 */
public final class SkillPlayerAnim {
   /*
    * Axis conversion from the animation files (Blockbench, Y up) to the Java model (Y down). Rotations carry over as is
    * (negative X raises an arm forward in both, positive Y turns right in both); only the vertical position flips.
    * If a pose ever looks mirrored in game, flip the matching sign here.
    */
   private static final float[] POS_SIGN = {1.0F, -1.0F, 1.0F};
   private static final float[] ROT_SIGN = {1.0F, 1.0F, 1.0F};

   /** Set to true to play the Prime Punch player-body animations (arm / body poses) while a skill is used. */
   public static final boolean ENABLED = false;

   private static final Map<Skill, BedrockAnim> CACHE = new EnumMap<>(Skill.class);
   private static final Map<UUID, Run> PLAYING = new ConcurrentHashMap<>();

   private record Run(BedrockAnim anim, long start) {
   }

   private SkillPlayerAnim() {
   }

   public static void start(UUID id, Skill skill) {
      if (!ENABLED) {
         return;
      }

      BedrockAnim a = CACHE.computeIfAbsent(skill, s -> BedrockAnim.load("/assets/realmforge/skills/player/" + s.resource + ".json"));
      if (a != null) {
         PLAYING.put(id, new Run(a, Util.getMillis()));
      }
   }

   public static void clear() {
      PLAYING.clear();
   }

   public static boolean isPlaying(UUID id) {
      Run r = PLAYING.get(id);
      if (r == null) {
         return false;
      }

      if ((Util.getMillis() - r.start) / 1000.0F > r.anim.length) {
         PLAYING.remove(id);
         return false;
      }

      return true;
   }

   public static void apply(HumanoidModel<?> m, UUID id) {
      Run run = PLAYING.get(id);
      if (run == null) {
         return;
      }

      BedrockAnim anim = run.anim;
      float t = (Util.getMillis() - run.start) / 1000.0F;

      // vanilla pose: current positions double as the default pivots
      float[] bodyPos = {m.body.x, m.body.y, m.body.z};
      float[] bOff = pos(anim.sample("body", "position", t), new float[3]);
      float[] bRot = rot(anim.sample("body", "rotation", t), new float[] {m.body.xRot, m.body.yRot, m.body.zRot});
      double[][] rb = matrix(bRot);

      m.body.x = bodyPos[0] + bOff[0];
      m.body.y = bodyPos[1] + bOff[1];
      m.body.z = bodyPos[2] + bOff[2];
      m.body.xRot = bRot[0];
      m.body.yRot = bRot[1];
      m.body.zRot = bRot[2];

      // head and arms are children of the body in the animation: they follow its twist and lean
      child(anim, m.head, "head", t, bodyPos, bOff, rb);
      child(anim, m.rightArm, "right_arm", t, bodyPos, bOff, rb);
      child(anim, m.leftArm, "left_arm", t, bodyPos, bOff, rb);

      // legs are independent
      leg(anim, m.rightLeg, "right_leg", t);
      leg(anim, m.leftLeg, "left_leg", t);
      m.hat.copyFrom(m.head);
   }

   private static void child(BedrockAnim anim, ModelPart part, String bone, float t, float[] bodyPos, float[] bOff, double[][] rb) {
      float[] rel = {part.x - bodyPos[0], part.y - bodyPos[1], part.z - bodyPos[2]};
      float[] own = pos(anim.sample(bone, "position", t), new float[3]);
      float[] cr = rot(anim.sample(bone, "rotation", t), new float[] {part.xRot, part.yRot, part.zRot});

      double[] p = mul(rb, new double[] {rel[0] + own[0], rel[1] + own[1], rel[2] + own[2]});
      part.x = bodyPos[0] + bOff[0] + (float)p[0];
      part.y = bodyPos[1] + bOff[1] + (float)p[1];
      part.z = bodyPos[2] + bOff[2] + (float)p[2];

      double[] e = euler(mul(rb, matrix(cr)));
      part.xRot = (float)e[0];
      part.yRot = (float)e[1];
      part.zRot = (float)e[2];
   }

   private static void leg(BedrockAnim anim, ModelPart part, String bone, float t) {
      float[] off = pos(anim.sample(bone, "position", t), new float[3]);
      float[] r = rot(anim.sample(bone, "rotation", t), new float[] {part.xRot, part.yRot, part.zRot});
      part.x += off[0];
      part.y += off[1];
      part.z += off[2];
      part.xRot = r[0];
      part.yRot = r[1];
      part.zRot = r[2];
   }

   private static float[] pos(float[] v, float[] fallback) {
      return v == null ? fallback : new float[] {v[0] * POS_SIGN[0], v[1] * POS_SIGN[1], v[2] * POS_SIGN[2]};
   }

   private static float[] rot(float[] v, float[] fallbackRad) {
      if (v == null) {
         return fallbackRad;
      }

      return new float[] {
         (float)Math.toRadians(v[0] * ROT_SIGN[0]), (float)Math.toRadians(v[1] * ROT_SIGN[1]), (float)Math.toRadians(v[2] * ROT_SIGN[2])
      };
   }

   // ------------------------------------------------------------------ rotation math (ZYX, same order as ModelPart)

   static double[][] matrix(float[] r) {
      double cx = Math.cos(r[0]), sx = Math.sin(r[0]);
      double cy = Math.cos(r[1]), sy = Math.sin(r[1]);
      double cz = Math.cos(r[2]), sz = Math.sin(r[2]);
      double[][] rx = {{1, 0, 0}, {0, cx, -sx}, {0, sx, cx}};
      double[][] ry = {{cy, 0, sy}, {0, 1, 0}, {-sy, 0, cy}};
      double[][] rz = {{cz, -sz, 0}, {sz, cz, 0}, {0, 0, 1}};
      return mul(rz, mul(ry, rx));
   }

   static double[][] mul(double[][] a, double[][] b) {
      double[][] o = new double[3][3];
      for (int i = 0; i < 3; i++) {
         for (int j = 0; j < 3; j++) {
            o[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j];
         }
      }

      return o;
   }

   static double[] mul(double[][] a, double[] v) {
      return new double[] {
         a[0][0] * v[0] + a[0][1] * v[1] + a[0][2] * v[2],
         a[1][0] * v[0] + a[1][1] * v[1] + a[1][2] * v[2],
         a[2][0] * v[0] + a[2][1] * v[1] + a[2][2] * v[2]
      };
   }

   /** Rotation matrix -> {xRot, yRot, zRot} for R = Rz * Ry * Rx. */
   static double[] euler(double[][] r) {
      double y = Math.asin(Math.max(-1.0, Math.min(1.0, -r[2][0])));
      if (Math.abs(r[2][0]) < 0.99999) {
         return new double[] {Math.atan2(r[2][1], r[2][2]), y, Math.atan2(r[1][0], r[0][0])};
      }

      return new double[] {Math.atan2(-r[1][2], r[1][1]), y, 0.0};
   }
}
