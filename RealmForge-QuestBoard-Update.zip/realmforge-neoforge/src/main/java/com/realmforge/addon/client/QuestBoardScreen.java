package com.realmforge.addon.client;

import com.realmforge.RealmForgeMod;
import com.realmforge.addon.net.QuestClaimPayload;
import com.realmforge.addon.quest.QuestBoardInfo;
import com.realmforge.client.ClientRpg;
import com.realmforge.data.RpgData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Quest Board screen: the original chalkboard + parchment card artwork with the single quest drawn on it
 * (Mine 5 Iron Ore, 273 EXP, refreshes every 2 minutes).
 */
public class QuestBoardScreen extends Screen {
   private static final ResourceLocation BOARD = RealmForgeMod.id("textures/screens/questboard2.png");
   private static final ResourceLocation CARD = RealmForgeMod.id("textures/screens/questbutton.png");
   private static final int BOARD_W = 427;
   private static final int BOARD_H = 298;
   private static final int CARD_W = 100;
   private static final int CARD_H = 132;
   private final BlockPos pos;
   private Button claim;

   public QuestBoardScreen(BlockPos pos) {
      super(Component.literal("Quest Board"));
      this.pos = pos;
   }

   private float scale() {
      return Math.min(1.0F, Math.min((this.width - 16) / (float)BOARD_W, (this.height - 16) / (float)BOARD_H));
   }

   private int boardLeft() {
      return (int)(this.width / 2 - BOARD_W * this.scale() / 2.0F);
   }

   private int boardTop() {
      return (int)(this.height / 2 - BOARD_H * this.scale() / 2.0F);
   }

   @Override
   protected void init() {
      float s = this.scale();
      int cx = this.width / 2;
      int top = this.boardTop();
      this.claim = Button.builder(Component.literal("Claim Reward"), b -> PacketDistributor.sendToServer(new QuestClaimPayload(this.pos)))
         .bounds(cx - 52, top + (int)(190 * s), 104, 20)
         .build();
      this.addRenderableWidget(this.claim);
      this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose()).bounds(cx - 30, top + (int)(218 * s), 60, 20).build());
   }

   /** Quest state as the player would see it right now (a stale epoch means the board already refreshed). */
   private int progress(RpgData d, boolean current) {
      return d == null || !current ? 0 : Math.min(QuestBoardInfo.TARGET, d.questProgress);
   }

   @Override
   public void tick() {
      RpgData d = ClientRpg.data;
      long gt = this.minecraft == null || this.minecraft.level == null ? 0L : this.minecraft.level.getGameTime();
      boolean current = d != null && d.questEpoch == QuestBoardInfo.epoch(gt);
      this.claim.active = current && !d.questClaimed && d.questProgress >= QuestBoardInfo.TARGET;
   }

   @Override
   public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
      super.renderBackground(g, mouseX, mouseY, partialTick);
      Minecraft mc = Minecraft.getInstance();
      RpgData d = ClientRpg.data;
      long gt = mc.level == null ? 0L : mc.level.getGameTime();
      boolean current = d != null && d.questEpoch == QuestBoardInfo.epoch(gt);
      int prog = this.progress(d, current);
      boolean claimed = current && d.questClaimed;
      int secs = QuestBoardInfo.ticksLeft(gt) / 20;

      float s = this.scale();
      g.pose().pushPose();
      g.pose().translate(this.boardLeft(), this.boardTop(), 0.0F);
      g.pose().scale(s, s, 1.0F);

      g.blit(BOARD, 0, 0, 0.0F, 0.0F, BOARD_W, BOARD_H, BOARD_W, BOARD_H);
      this.centered(g, "Quest Board", BOARD_W / 2, 14, 0xFFE8C0);
      this.centered(g, String.format("Refreshes in %d:%02d", secs / 60, secs % 60), BOARD_W / 2, 28, 0xBBBBBB);

      int cardX = (BOARD_W - CARD_W) / 2;
      int cardY = 46;
      g.blit(CARD, cardX, cardY, 0.0F, 0.0F, CARD_W, CARD_H, CARD_W, CARD_H);
      int mid = BOARD_W / 2;
      int ink = 0x3B2A1A;
      this.centered(g, QuestBoardInfo.TITLE, mid, cardY + 24, ink);

      g.pose().pushPose();
      g.pose().translate(mid - 16, cardY + 40, 0.0F);
      g.pose().scale(2.0F, 2.0F, 1.0F);
      g.renderItem(new ItemStack(Items.IRON_ORE), 0, 0);
      g.pose().popPose();

      this.centered(g, prog + " / " + QuestBoardInfo.TARGET, mid, cardY + 78, ink);
      this.centered(g, "Reward: " + QuestBoardInfo.REWARD_EXP + " EXP", mid, cardY + 92, 0x6B3F00);
      if (d == null) {
         this.centered(g, "Loading...", mid, cardY + 108, ink);
      } else if (claimed) {
         this.centered(g, "Claimed", mid, cardY + 108, 0x1F6B1F);
      } else if (prog >= QuestBoardInfo.TARGET) {
         this.centered(g, "Ready to claim!", mid, cardY + 108, 0x1F6B1F);
      } else {
         this.centered(g, "In progress", mid, cardY + 108, 0x7A1F1F);
      }

      g.pose().popPose();
   }

   private void centered(GuiGraphics g, String text, int cx, int y, int color) {
      g.drawString(this.font, text, cx - this.font.width(text) / 2, y, color, false);
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
