package com.realmforge.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.skill.Skill;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * The original Prime Punch VFX models (barrage / heavypunch / uppercut geo + animation + texture), drawn with
 * {@link BedrockModel}. In the original they were entities riding the player; here an effect follows the player's
 * interpolated position at chest height (a rider sits at 75% of the vehicle's height) and keeps the facing it started with.
 */
public final class SkillVfx {
   /** chest height: a passenger rides at 0.75 x the 1.8 block player height */
   private static final double RIDE_HEIGHT = 1.35;

   private static final class Def {
      final BedrockModel model;
      final BedrockAnim anim;
      final ResourceLocation texture;
      final boolean usePitch;

      Def(BedrockModel model, BedrockAnim anim, ResourceLocation texture, boolean usePitch) {
         this.model = model;
         this.anim = anim;
         this.texture = texture;
         this.usePitch = usePitch;
      }
   }

   private static final class Fx {
      final UUID player;
      final Def def;
      final float yaw;
      final float pitch;
      final long start;

      Fx(UUID player, Def def, float yaw, float pitch) {
         this.player = player;
         this.def = def;
         this.yaw = yaw;
         this.pitch = pitch;
         this.start = Util.getMillis();
      }
   }

   private static final Map<Skill, Def> DEFS = new EnumMap<>(Skill.class);
   private static final List<Fx> ACTIVE = new ArrayList<>();

   private SkillVfx() {
   }

   private static Def def(Skill s) {
      return DEFS.computeIfAbsent(s, k -> {
         BedrockModel m = BedrockModel.load("/assets/realmforge/skills/geo/" + k.resource + ".geo.json");
         BedrockAnim a = BedrockAnim.load("/assets/realmforge/skills/anim/" + k.resource + ".animation.json");
         if (m == null) {
            return null;
         }

         ResourceLocation tex = RealmForgeMod.id("textures/entities/" + k.texture + ".png");
         // barrage follows where you look (up/down); the punches stay horizontal, like their hit cones
         return new Def(m, a, tex, k == Skill.BARRAGE);
      });
   }

   public static void start(UUID player, Skill s, float yaw, float pitch) {
      Def d = def(s);
      if (d != null) {
         ACTIVE.add(new Fx(player, d, yaw, pitch));
      }
   }

   public static void clear() {
      ACTIVE.clear();
   }

   public static void render(RenderLevelStageEvent event) {
      if (ACTIVE.isEmpty() || event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
         return;
      }

      Minecraft mc = Minecraft.getInstance();
      ClientLevel level = mc.level;
      if (level == null) {
         ACTIVE.clear();
         return;
      }

      float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);
      Vec3 cam = event.getCamera().getPosition();
      PoseStack ps = event.getPoseStack();
      MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
      long now = Util.getMillis();

      Iterator<Fx> it = ACTIVE.iterator();
      while (it.hasNext()) {
         Fx fx = it.next();
         float t = (now - fx.start) / 1000.0F;
         float len = fx.def.anim == null ? 0.5F : fx.def.anim.length;
         Player pl = level.getPlayerByUUID(fx.player);
         if (pl == null || t > len + 0.05F) {
            it.remove();
            continue;
         }

         Vec3 pos = pl.getPosition(pt);
         RenderType type = RenderType.entityTranslucentEmissive(fx.def.texture);
         VertexConsumer vc = buffers.getBuffer(type);
         ps.pushPose();
         ps.translate(pos.x - cam.x, pos.y + RIDE_HEIGHT - cam.y, pos.z - cam.z);
         ps.mulPose(Axis.YP.rotationDegrees(180.0F - fx.yaw)); // model -Z points where the player faced
         if (fx.def.usePitch) {
            ps.mulPose(Axis.XP.rotationDegrees(-fx.pitch));
         }

         fx.def.model.render(ps, vc, fx.def.anim, Math.min(t, len), LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, true);
         ps.popPose();
         buffers.endBatch(type);
      }
   }
}
