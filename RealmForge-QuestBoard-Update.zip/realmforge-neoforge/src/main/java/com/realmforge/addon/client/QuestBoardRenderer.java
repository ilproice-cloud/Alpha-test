package com.realmforge.addon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.realmforge.RealmForgeMod;
import com.realmforge.addon.quest.QuestBoardBlock;
import com.realmforge.addon.quest.QuestBoardBlockEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;

/** Draws the Quest Board's original model (static, no animation) with the original texture. */
public class QuestBoardRenderer implements BlockEntityRenderer<QuestBoardBlockEntity> {
   private static final ResourceLocation TEXTURE = RealmForgeMod.id("textures/block/quest_boardtextrure.png");
   private static BedrockModel model;
   private static boolean loaded;

   public QuestBoardRenderer(BlockEntityRendererProvider.Context context) {
   }

   private static BedrockModel model() {
      if (!loaded) {
         loaded = true;
         model = BedrockModel.load("/assets/realmforge/skills/geo/quest_board.geo.json");
      }

      return model;
   }

   @Override
   public void render(QuestBoardBlockEntity be, float partialTick, PoseStack ps, MultiBufferSource buffer, int light, int overlay) {
      BedrockModel m = model();
      if (m == null) {
         return;
      }

      Direction facing = be.getBlockState().getValue(QuestBoardBlock.FACING);
      ps.pushPose();
      ps.translate(0.5, 0.0, 0.5);
      ps.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot())); // model front (-Z) faces the way the block faces
      m.render(ps, buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)), null, 0.0F, light, overlay, false);
      ps.popPose();
   }

   public AABB getRenderBoundingBox(QuestBoardBlockEntity be) {
      return be.getRenderBoundingBox();
   }
}
