package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: claim the quest reward at the board at {@code pos}. */
public record QuestClaimPayload(BlockPos pos) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<QuestClaimPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("quest_claim"));
   public static final StreamCodec<ByteBuf, QuestClaimPayload> CODEC = StreamCodec.composite(BlockPos.STREAM_CODEC, QuestClaimPayload::pos, QuestClaimPayload::new);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
