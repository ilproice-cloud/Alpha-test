package com.realmforge.addon.quest;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** No data of its own: it only exists so the model can be drawn by a block entity renderer. */
public class QuestBoardBlockEntity extends BlockEntity {
   public QuestBoardBlockEntity(BlockPos pos, BlockState state) {
      super(QuestBlocks.QUEST_BOARD_BE.get(), pos, state);
   }

   /** the model is ~2.5 blocks wide and ~2 blocks tall: keep it from being culled when the block itself is off screen */
   public AABB getRenderBoundingBox() {
      return new AABB(this.getBlockPos()).inflate(2.0, 1.5, 2.0);
   }
}
