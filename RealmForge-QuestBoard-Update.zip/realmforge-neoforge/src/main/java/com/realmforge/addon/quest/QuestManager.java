package com.realmforge.addon.quest;

import com.realmforge.RealmForgeMod;
import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;

/**
 * Server logic for the Quest Board's single quest: mine {@link QuestBoardInfo#TARGET} iron ore, claim
 * {@link QuestBoardInfo#REWARD_EXP} EXP. Progress lives in the player's RpgData. The quest resets for everyone every
 * {@link QuestBoardInfo#REFRESH_TICKS} ticks of world time (the player's saved epoch no longer matches the current one).
 */
@EventBusSubscriber(modid = RealmForgeMod.MOD_ID)
public final class QuestManager {
   private static final TagKey<Block> IRON_ORES = TagKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath("c", "ores/iron"));

   private QuestManager() {
   }

   private static boolean isIronOre(BlockState s) {
      return s.is(Blocks.IRON_ORE) || s.is(Blocks.DEEPSLATE_IRON_ORE) || s.is(IRON_ORES);
   }

   /** Applies the 2-minute reset if it is due. Returns true if the quest was reset. */
   private static boolean normalize(ServerPlayer p, RpgData d) {
      long epoch = QuestBoardInfo.epoch(p.serverLevel().getGameTime());
      if (d.questEpoch == epoch) {
         return false;
      }

      d.questEpoch = epoch;
      d.questProgress = 0;
      d.questClaimed = false;
      d.syncDirty = true;
      return true;
   }

   /** Called when a player opens the board: reset if due, then send fresh data. */
   public static void refresh(ServerPlayer p) {
      RpgData d = RpgManager.get(p);
      normalize(p, d);
      RpgManager.sync(p, -1);
   }

   @SubscribeEvent(priority = EventPriority.LOWEST)
   public static void onBreak(BlockEvent.BreakEvent event) {
      if (event.isCanceled() || !(event.getPlayer() instanceof ServerPlayer sp) || sp.isCreative() || sp.isSpectator()) {
         return;
      }

      if (!isIronOre(event.getState())) {
         return;
      }

      RpgData d = RpgManager.get(sp);
      normalize(sp, d);
      if (d.questClaimed || d.questProgress >= QuestBoardInfo.TARGET) {
         return;
      }

      d.questProgress++;
      d.syncDirty = true;
      if (d.questProgress >= QuestBoardInfo.TARGET) {
         sp.displayClientMessage(
            Component.literal("Quest complete: " + QuestBoardInfo.TITLE + "! Claim your reward at the Quest Board.").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false
         );
         sp.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 1.0F);
      } else {
         sp.displayClientMessage(
            Component.literal("Quest: " + QuestBoardInfo.TITLE + " (" + d.questProgress + "/" + QuestBoardInfo.TARGET + ")").withStyle(ChatFormatting.YELLOW), true
         );
      }

      RpgManager.sync(sp, -1);
   }

   /** Claim button pressed at the board at {@code boardPos}. */
   public static void claim(ServerPlayer p, BlockPos boardPos) {
      // must actually be standing at a Quest Board
      if (!p.serverLevel().getBlockState(boardPos).is(QuestBlocks.QUEST_BOARD.get()) || p.distanceToSqr(boardPos.getCenter()) > 64.0) {
         return;
      }

      RpgData d = RpgManager.get(p);
      normalize(p, d);
      if (d.questClaimed) {
         p.displayClientMessage(Component.literal("You already claimed this quest. A new one comes when the board refreshes.").withStyle(ChatFormatting.RED), true);
      } else if (d.questProgress < QuestBoardInfo.TARGET) {
         p.displayClientMessage(Component.literal("Quest not finished yet (" + d.questProgress + "/" + QuestBoardInfo.TARGET + ").").withStyle(ChatFormatting.RED), true);
      } else {
         d.questClaimed = true;
         d.syncDirty = true;
         RpgManager.award(p, d, QuestBoardInfo.REWARD_EXP);
         p.displayClientMessage(Component.literal("Quest reward: +" + QuestBoardInfo.REWARD_EXP + " EXP").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), false);
         p.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0F, 1.0F);
      }

      RpgManager.sync(p, -1);
   }
}
