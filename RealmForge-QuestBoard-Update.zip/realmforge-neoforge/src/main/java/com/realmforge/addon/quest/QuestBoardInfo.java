package com.realmforge.addon.quest;

/** The one quest on the Quest Board. Shared by server logic and the client screen (no server imports here). */
public final class QuestBoardInfo {
   /** iron ore blocks to mine */
   public static final int TARGET = 5;
   /** exact EXP granted on claim (no clan / perk multiplier) */
   public static final long REWARD_EXP = 273L;
   /** the quest resets for everyone on this fixed clock: every 2 minutes of world time */
   public static final int REFRESH_TICKS = 2400;
   public static final String TITLE = "Mine 5 Iron Ore";

   private QuestBoardInfo() {
   }

   public static long epoch(long gameTime) {
      return gameTime / REFRESH_TICKS;
   }

   public static int ticksLeft(long gameTime) {
      return REFRESH_TICKS - (int)(gameTime % REFRESH_TICKS);
   }
}
