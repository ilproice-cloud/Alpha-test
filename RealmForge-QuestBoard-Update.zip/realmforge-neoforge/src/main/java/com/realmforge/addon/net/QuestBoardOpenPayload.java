package com.realmforge.addon.net;

import com.realmforge.RealmForgeMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: open the Quest Board screen for the board at {@code pos}. */
public record QuestBoardOpenPayload(BlockPos pos) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<QuestBoardOpenPayload> TYPE = new CustomPacketPayload.Type<>(RealmForgeMod.id("quest_board_open"));
   public static final StreamCodec<ByteBuf, QuestBoardOpenPayload> CODEC = StreamCodec.composite(BlockPos.STREAM_CODEC, QuestBoardOpenPayload::pos, QuestBoardOpenPayload::new);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
